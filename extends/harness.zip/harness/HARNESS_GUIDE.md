# Harness 使用说明

本 `harness` 目录用于沉淀 `shop-trade` 项目的 AI 协作规则、阅读路径、质量门禁和长期可复用经验。

它不是业务代码仓，也不是 CI/CD 配置目录。业务代码仍以各子项目目录为准。

## 当前用途

- 给 Codex、Claude 等 AI 工具提供统一入口。
- 聚合 `shop-trade` 多子项目的阅读顺序。
- 把跨项目规则放在一处，减少不同子项目说明互相冲突。
- 沉淀 SQL 清理、前后端验证、文档分类等长期规则。

## 目录说明

- `AGENTS.md`：Codex 入口文件。
- `docs/index.md`：文档地图，按任务类型给出阅读路径。
- `docs/architecture.md`：项目结构和跨项目关系。
- `docs/conventions.md`：通用协作、命名、文档和 SQL 规范。
- `docs/stack.md`：技术栈、命令和环境约束。
- `docs/rules/**`：前端、Java、通用规则。
- `docs/rules/common/api-page-method.md`：分页查询统一使用 `POST` 的规则入口。
- `docs/qa/**`：验证和质量门禁。
- `docs/runbooks/**`：启动和排查手册。
- `docs/experience/**`：可长期复用的处理经验。

## 维护规则

- 子项目专属规则优先维护在 `docs/applications/<子项目>/CLAUDE.md`。
- 原子项目目录下的 `README.md` 保留原位，不纳入迁移清理。
- 跨项目通用规则维护在本 harness。
- 分页接口方法规范维护在 `docs/rules/common/api-page-method.md`，按应用的落地说明维护在 `docs/applications/*/30-接口与协议/page-query-convention.md`。
- 临时过程材料不要写入 `docs/index.md`。
- 如果后续新增子项目，先更新 `docs/index.md`，再补充对应规则。
