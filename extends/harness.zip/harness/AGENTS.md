# Shop Trade AI 协作入口

本目录是 `shop-trade` 项目的 AI 协作文档骨架，不是 Harness CI/CD 平台配置。

每次任务开始前，先读本文件，再按任务类型读取 `docs/index.md` 指向的文档和对应子项目归档入口。

## 项目边界

`shop-trade` 当前包含六个主要子项目：

- `../shop-trade-service-system`：系统管理、基础设施、网关、框架与初始化 SQL。
- `../shop-trade-service-business`：业务模块，包含 business API 与 server。
- `../shop-trade-service-ai`：AI 大模型服务模块。
- `../shop-trade-service-ui`：Vue 3 管理后台前端。
- `../shop-trade-service-material`：独立素材库应用。
- `../shop-trade-service-portal`：面向外部用户的 Nuxt 3 前台门户应用。

## 阅读顺序

1. 读本文件。
2. 读 `docs/index.md` 判断任务入口。
3. 涉及具体子项目时，读 `docs/applications/<子项目>/CLAUDE.md`。
4. 再读原子项目目录下保留的 `README.md`、`pom.xml` 或 `package.json`。
5. 最后读取相关源码、配置、SQL 和测试。

## 信息优先级

1. 当前代码、SQL、构建文件和配置。
2. `docs/applications/<子项目>/CLAUDE.md`。
3. 原子项目 README、POM、package.json。
4. 本 harness 文档。
5. 历史报告、草稿和临时分析。

如果文档和代码冲突，以当前代码为准，并在需要时同步更新文档。

## 强制工作规则

- PowerShell 读取中文文档时使用 `Get-Content -Encoding UTF8`。
- 搜索文件和文本优先用 `rg` 或 `rg --files`。
- 不回滚用户已有改动，不随意清理工作区。
- SQL 清理相关工作以 `shop-trade-service-system/sql/mysql/retain-red-box-data.sql` 的最新状态为基准。
- 前端任务默认使用 `pnpm`，不要切换到 npm。
- 后端任务默认使用 Java 17、Maven 和现有多模块结构。
- 只读分析不需要改文件；一旦改文件，必须在最终回复中列出文件和验证结果。
- 涉及分页查询接口时，先读 `docs/rules/common/api-page-method.md`。

## 任务类型入口

- 后端功能、接口、数据库：读 `docs/rules/java/patterns.md` 和对应 `docs/applications/<后端子项目>/CLAUDE.md`。
- 管理后台前端页面、路由、请求：读 `docs/rules/web/patterns.md` 和 `docs/applications/shop-trade-service-ui/CLAUDE.md`。
- Portal 前台页面、SEO、SSR、聚合接口对接：读 `docs/applications/shop-trade-service-portal/CLAUDE.md`。
- 分页接口或分页请求改造：先读 `docs/rules/common/api-page-method.md`，再读对应应用下的 `30-接口与协议/page-query-convention.md`。
- SQL 清理、初始化数据：读 `docs/experience/sql-cleanup-retention.md`。
- 验证、测试、发布前检查：读 `docs/qa/quality-gates.md`。
- 本地启动、环境排查：读 `docs/runbooks/local-dev.md`。
