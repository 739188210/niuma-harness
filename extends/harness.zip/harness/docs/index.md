# 文档地图

本文件只说明“什么时候读哪里”，不替代具体文档内容。

## 核心入口

- `../AGENTS.md`：AI 协作入口。
- `architecture.md`：项目结构和模块关系。
- `conventions.md`：跨项目通用规范。
- `stack.md`：技术栈、命令、环境约束。
- `applications/README.md`：已迁移应用材料总览。
- `qa/quality-gates.md`：验证和完成标准。
- `rules/common/api-page-method.md`：分页查询统一使用 `POST` 的规则。

## 默认阅读优先级

除非任务非常局部，否则默认按以下顺序阅读：

1. 全局规则文件（`rules/**`）
2. 应用级入口说明（`applications/<应用>/CLAUDE.md`）
3. 原子项目事实文件（`README.md`、`pom.xml`、`package.json`、`nuxt.config.ts` 等）
4. 具体源码、SQL、测试、配置

如果文档和代码冲突，以当前代码和构建配置为准，再回写修正文档。

## 子项目入口

### `../../shop-trade-service-system`

系统管理、基础设施、网关、框架、初始化 SQL。

阅读入口：

1. `applications/shop-trade-service-system/CLAUDE.md`
2. `../../shop-trade-service-system/README.md`
3. `../../shop-trade-service-system/pom.xml`
4. `applications/shop-trade-service-system/docs/**`
5. `../../shop-trade-service-system/sql/mysql/**`

### `../../shop-trade-service-business`

业务模块，包含 `business-api` 与 `business-server`。

阅读入口：

1. `applications/shop-trade-service-business/CLAUDE.md`
2. `../../shop-trade-service-business/README.md`
3. `../../shop-trade-service-business/pom.xml`
4. `applications/shop-trade-service-business/docs/**`

### `../../shop-trade-service-ai`

AI 大模型服务模块。

阅读入口：

1. `applications/shop-trade-service-ai/CLAUDE.md`
2. `../../shop-trade-service-ai/README.md`
3. `../../shop-trade-service-ai/pom.xml`
4. `applications/shop-trade-service-ai/docs/**`

### `../../shop-trade-service-ui`

Vue 3 管理后台前端。

阅读入口：

1. `applications/shop-trade-service-ui/CLAUDE.md`
2. `../../shop-trade-service-ui/README.md`
3. `../../shop-trade-service-ui/package.json`
4. `../../shop-trade-service-ui/vite.config.ts`
5. 路由、权限、请求相关源码

### `../../shop-trade-service-material`

独立素材库应用。

阅读入口：

1. `applications/shop-trade-service-material/CLAUDE.md`
2. `../../shop-trade-service-material/README.md`
3. `../../shop-trade-service-material/pom.xml`
4. `applications/shop-trade-service-material/docs/**`
5. `../../shop-trade-service-material/sql/**`

### `../../shop-trade-service-portal`

Nuxt 3 前台门户应用。

阅读入口：

1. `applications/shop-trade-service-portal/CLAUDE.md`
2. `../../shop-trade-service-portal/README.md`
3. `../../shop-trade-service-portal/package.json`
4. `../../shop-trade-service-portal/nuxt.config.ts`
5. 页面、布局、server/api、composables、types 相关源码

## 推荐阅读路径

### 后端改动

`AGENTS.md` -> 本文件 -> `rules/common/api-page-method.md`（如涉及分页接口） -> `rules/java/patterns.md` -> `applications/<后端子项目>/CLAUDE.md` -> `pom.xml` -> 相关源码、SQL、测试。

### 管理后台前端改动

`AGENTS.md` -> 本文件 -> `rules/common/api-page-method.md`（如涉及分页接口） -> `rules/web/patterns.md` -> `applications/shop-trade-service-ui/CLAUDE.md` -> `package.json` -> 相关页面、路由、store、api。

### Portal 前台改动

`AGENTS.md` -> 本文件 -> `applications/shop-trade-service-portal/CLAUDE.md` -> `package.json` -> `nuxt.config.ts` -> 相关 pages、components、server/api、composables。

### SQL 清理或初始化数据

`AGENTS.md` -> 本文件 -> `experience/sql-cleanup-retention.md` -> `../../shop-trade-service-system/sql/mysql/retain-red-box-data.sql` -> 相关初始化 SQL。

### QA 和验证

`AGENTS.md` -> 本文件 -> `qa/quality-gates.md` -> `applications/<子项目>/CLAUDE.md` 的命令说明 -> 实际命令输出。

### 文档更新

`AGENTS.md` -> 本文件 -> `conventions.md` -> 对应应用入口文档 -> 相关专题文档。
