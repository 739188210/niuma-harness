# 决策记录：分页查询统一使用 POST

## 背景

`shop-trade` 历史上同时存在两种分页查询风格：

- `GET /page + query params`
- `POST /page + request body`

这种混用会带来几个问题：

- 前后端分页请求方式不一致，容易出现 `Request method not supported`
- 查询条件复杂时，URL 参数过长且不稳定
- RPC / Feign 分页 DTO 有的走 query string，有的走 body，维护成本高

## 决策

在 `shop-trade` 中统一约定：

- 分页查询接口使用 `POST`
- 分页参数对象使用请求体传输
- 前端 API 层统一使用 `request.post({ url, data })`
- Feign / RPC 分页接口统一使用 `@PostMapping + @RequestBody`

## 影响

- 新增分页接口时不再使用 `GET /page`
- 历史分页接口逐步迁移为 `POST`
- QA 需要补充静态扫描检查，避免规则回退

## 不在本规则内的内容

- `/get`、`/list`、`/simple-list` 等非分页接口是否使用 `GET`
- 导出、下载、回调等特殊接口的方法选择
