# 决策记录：初始化 shop-trade harness

## 背景

`shop-trade` 已有多个子项目，各子项目原本分散维护 `CLAUDE.md`、docs、README、POM 或 package 配置。需要一套独立的 AI 协作文档入口，统一阅读路径和跨项目规则。

## 决策

在 `shop-trade/harness/` 下创建 AI 协作文档骨架。

该目录只用于 AI 协作，不代表 Harness CI/CD 平台，也不承载业务代码。

## 规则

- 子项目专属规则迁移到 `docs/applications/<子项目>/CLAUDE.md`，原子项目 `README.md` 保留原位。
- 跨项目规则放在 `harness/docs/`。
- SQL 清理相关经验单独沉淀到 `docs/experience/sql-cleanup-retention.md`。
- 后续新增子项目或文档入口时，先更新 `docs/index.md`。
