# 通用规范

## 文档规范

- 子项目专属 Markdown 放在对应子项目 `docs/` 下。
- 跨项目 AI 协作规则放在 `harness/docs/` 下。
- 后端子项目文档沿用编号中文目录结构，例如 `00-项目总览`、`20-设计与架构`、`50-测试与质量`。
- AI 生成的长期文档要写明完整路径、用途、当前状态和后续维护规则。
- 临时过程材料放入 `_drafts`、`_temp` 或 harness 的 `docs/experience`，不要混进根目录。

## SQL 规范

- 业务表优先遵循 `applications/shop-trade-service-business/CLAUDE.md` 中的 P0 规范。
- 主键使用 `bigint AUTO_INCREMENT`。
- 基础字段包含 `creator`、`create_time`、`updater`、`update_time`、`deleted`、`tenant_id`。
- 需要数据权限的业务表包含 `dept_id`、`user_id`。
- SQL 变更脚本要有文件头、事务、回滚脚本。
- 数据清理脚本要明确保留范围、关联表同步、主键自增规划。

## 代码规范

- 后端 Controller 不写业务逻辑，业务逻辑放 Service。
- MyBatis-Plus DO 遵循 `TenantBaseDO`、Lombok、`@TableName`、`@TableId(type = IdType.AUTO)` 等现有模式。
- 跨模块调用优先走已有 API、Feign 或 framework 封装。
- 分页查询接口统一使用 `POST`，参见 `rules/common/api-page-method.md`。
- 前端接口封装放 `src/api/**`，页面放 `src/views/**`，复用组件放 `src/components/**`。
- 前端路由、权限、菜单改动必须检查后端菜单数据和 `routerHelper` 映射。

## 协作规范

- 不重写无关文件。
- 不回滚用户手动修改。
- 修改现有文件前先读取最新内容。
- 涉及 SQL 清理时，以 `retain-red-box-data.sql` 当前文件状态为准。
- 无法运行验证时，在最终回复中说明原因和替代检查。
