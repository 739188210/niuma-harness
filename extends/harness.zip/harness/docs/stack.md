# 技术栈与命令

## 后端

- Java 17
- Spring Boot 3.5.9
- Spring Cloud 2025.0.0
- Maven 多模块
- MyBatis-Plus
- Nacos Config / Discovery
- Redis / Redisson
- MySQL 8.0+
- Lombok + MapStruct

## 前端

- Vue 3.5
- Vite 5
- TypeScript 5
- Element Plus 2.11
- Pinia
- Vue Router
- UnoCSS
- pnpm

## 常用命令

### 前端

在 `shop-trade-service-ui` 下执行：

```bash
pnpm install
pnpm dev
pnpm ts:check
pnpm lint:eslint
pnpm lint:style
pnpm build:dev
```

当前前端没有标准单元测试脚本，默认使用类型检查、lint 和受影响功能手动验证。

### system 后端

在 `shop-trade-service-system` 下执行：

```bash
mvn clean compile
mvn test
mvn clean package -DskipTests
```

指定模块时使用 `-pl <module> -am`。

### business 后端

在 `shop-trade-service-business` 下执行：

```bash
mvn clean compile
mvn test
mvn -pl shop-trade-service-module-business-server -am spring-boot:run
```

### AI 后端

在 `shop-trade-service-ai` 下执行：

```bash
mvn clean compile -DskipTests
mvn clean package -DskipTests
mvn test
```

## 环境约束

- 后端本地环境可能依赖内网 Nexus、Nacos、MySQL、Redis。
- `NACOS_GROUP` 不能设置为 `DEFAULT_GROUP`。
- Maven 私服地址出现在 POM 中，离线或无内网时构建可能失败。
- PowerShell 读取中文文件必须显式 `-Encoding UTF8`。

