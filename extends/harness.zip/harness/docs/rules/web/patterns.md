# 前端模式

## 技术和命令

- 使用 `pnpm`。
- 不把日常开发切换到 `npm`。
- 类型检查优先 `pnpm ts:check`。
- 当前没有标准单元测试脚本。

## 路由和权限

前端采用后端菜单驱动的动态路由。修改以下内容时必须联动检查：

- `src/permission.ts`
- `src/store/modules/user.ts`
- `src/store/modules/permission.ts`
- `src/utils/routerHelper.ts`
- 后端 `system_menu` 数据

后端菜单的 `component` 字段必须能映射到 `src/views/**` 下的实际文件。

## 请求层

接口封装放 `src/api/**`。共享请求逻辑优先检查：

- `src/config/axios/service.ts`
- `src/config/axios/config.ts`
- `src/utils/auth.ts`

不要把 token、租户头、错误处理等通用逻辑散落到业务页面。

## 状态和缓存

登录态、菜单、租户和字典缓存同时受 Pinia 与 `useCache` 影响。权限异常不要只检查 store，也要检查浏览器缓存。

## Vue 文件主题兼容

生成的 Vue 文件要兼容 Element Plus 的暗黑模式。

## Vue3 + Element Plus 企业后台规则

### 技术栈约束

- 默认前端页面、组件、弹窗、抽屉、表单、表格统一使用：
  - `Vue3`
  - `TypeScript`
  - `script setup`
  - `Element Plus`
- 不新增以下技术到业务页面实现中：
  - `jQuery`
  - `Options API`
  - `Tailwind CSS`

### 页面目录结构

业务页面目录默认采用以下结构：

- `index.vue`
- `constant.ts`
- `utils.ts`
- `hooks.ts`
- `components/`
- 类型文件统一单独维护，优先使用固定命名并在项目内保持一致，不要同一项目混用 `type.ts` 和 `types.ts`

页面实现不要把以下内容全部堆在 `index.vue`：

- 常量
- 工具方法
- 类型定义
- 大段表单校验
- 复杂弹窗逻辑

### API 与页面解耦

- 接口请求统一放在 `src/api/**`
- 页面通过导入 API 方法调用接口
- 页面中不直接内嵌请求实现
- API 相关类型优先和 API 文件同目录维护，或按当前项目既有结构统一管理
- 不要把 token、tenant-id、错误处理等通用逻辑散落到业务页面

### Dialog / Drawer 规范

弹窗、抽屉类组件统一放在页面目录下的 `components/` 中。

统一交互方式：

- 子组件通过 `defineExpose({ open })` 对外暴露打开方法
- 父组件通过 `ref.open(...)` 调用
- `open()` 内部负责：
  - 初始化状态
  - 重置表单
  - 按需加载详情
- 保存成功后统一通过 `emit('success')` 通知父组件刷新列表

禁止父组件直接修改子组件内部 `visible`、`formData` 等状态。

### 表单规范

- 表单 `rules` 统一抽到 `constant.ts`
- 自定义校验器统一抽到 `utils.ts`
- 提交前统一执行：
  - `await formRef.value?.validate()`
- 重置逻辑统一封装为：
  - `resetForm()`
- 复杂业务表单必须显式区分：
  - 默认值
  - 重置逻辑
  - 编辑回填逻辑

### 表格与分页规范

列表页默认应具备以下结构：

- 查询区
- 表格区
- 分页区

通用规则：

- 表格必须显式控制高度，优先使用 `height` 或 `max-height`
- 表格空状态统一使用 `el-empty`
- 列表查询时必须重置回第一页
- 分页参数统一沿用项目现有约定，当前 shop 项目前端优先使用：
  - `pageNo`
  - `pageSize`

不要在同一个项目里混用多套分页字段命名。

### ID 类型处理规范

- 不强制要求所有 ID 一律用 `string`
- 统一原则是：跟随当前模块既有类型风格，前后链路保持一致
- 不要无意义地在页面中来回做：
  - `Number(id)`
  - `String(id)`
  - `id + ''`
  - `parseInt(id)`
- 如果接口层已经约定 `number`，前端直接按 `number` 使用
- 如果接口层已经约定 `string`，前端直接按 `string` 使用

### 交互反馈规范

- 异步查询、保存、删除、发布、同步等操作必须有对应 `loading` 状态
- 成功操作必须有明确提示
- 删除、下架、覆盖、同步等高风险操作必须二次确认
- 页面默认错误由全局请求拦截器处理
- 只有在以下场景，才允许在页面内做局部错误处理：
  - 业务特定提示
  - 局部降级
  - 状态回滚
  - 轮询终止
  - 文件上传特殊反馈

不要写无意义的 `try/catch` 把错误吞掉。

### 页面 UI 风格约束

后台页面必须符合企业后台风格：

- 简洁
- 高效
- 适合长时间办公
- 信息密度适中
- 与现有系统风格一致

不新增以下风格到后台业务页面：

- Landing Page 风格
- 营销页风格
- 大屏展示风格
- 夸张动效
- 大面积无意义留白

### 命名规范

- 页面目录：`PascalCase` 或遵循当前项目既有规则，但同一业务域保持一致
- 组件文件：`PascalCase`
- `css/scss` 类名：`kebab-case`
- 变量、方法名：语义化命名
- 禁止使用无意义命名：
  - `data1`
  - `flag`
  - `temp`
  - `test`
  - `doSomething`

### 注释规范

以下内容必须加注释：

- 对外暴露的方法
- 复杂业务方法
- 状态轮询逻辑
- 数据转换逻辑
- 特殊交互逻辑
- 与后端约定强相关的逻辑

简单 UI 点击事件、简单显示切换可不强制写注释。
