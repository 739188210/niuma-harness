# Java 后端模式

## 模块边界

- `api` 模块放跨模块接口、DTO、枚举、常量。
- `server` 模块放 Controller、Service、DAL、配置、启动类。
- Controller 不写业务逻辑。
- Service 不绕过 Mapper 和已有 framework 封装。
- 跨模块调用优先复用现有 API 或 Feign 客户端。

## 数据库和实体

- 业务表主键使用 `bigint AUTO_INCREMENT`。
- 业务表包含基础审计字段、逻辑删除、多租户字段。
- 需要权限隔离的表包含 `dept_id` 和 `user_id`。
- DO 继承 `TenantBaseDO`，使用 `@TableName`、`@TableId(type = IdType.AUTO)` 和 Lombok 注解。

## 数据权限

新增业务表时必须判断是否需要数据权限：

- 订单、客户、日程、沟通记录、方案等按部门 / 用户隔离。
- 线索池、知识库等已有规则明确可全公司共享时，要在代码或文档中说明原因。

## SQL 变更

- business 模块 SQL 变更遵循 `sql/mysql/migration/{版本}/` 和 `rollback/` 规范。
- system 初始化或清理 SQL 要保护用户、角色、部门、岗位、租户之间的关联一致性。

## 菜单权限与 SQL 产物

### 适用范围

当新增、修改或下线 shop 项目的后台功能时，只要涉及以下任一内容，必须同步处理菜单权限配置：

- 后台新增页面
- 后台新增按钮操作
- 后台新增接口权限控制
- 页面路由调整
- 页面复用已有权限
- 菜单层级、排序、显隐、缓存策略调整

### 权限标识确定原则

- 菜单权限标识不能只参考已有菜单 SQL，必须以**后端 Controller 中实际使用的 `@PreAuthorize("@ss.hasPermission(...)")`** 为准。
- 执行时必须同时核对：
  - 前端页面和路由
  - 后端 Controller 权限注解
  - 现有菜单 SQL 文件
  - 是否存在“后端已使用但菜单未配置”的权限差异
- 如果存在差异，必须在产物中明确说明。

### 产物要求

后续新增功能时，如果涉及菜单或权限，必须同步输出以下产物：

1. 菜单 SQL 文件
2. 本次新增权限标识清单
3. 本次复用权限标识清单
4. 是否存在权限差异说明
5. 如未新增 SQL，必须明确说明原因

### 菜单 SQL 输出要求

菜单 SQL 必须覆盖以下内容：

- 目录
- 菜单
- 按钮权限
- 父子层级
- 排序
- 路由地址
- 组件地址
- 组件名称 `component_name`
- 菜单图标
- 显隐状态
- 缓存状态
- 权限标识 `permission`

如果页面为隐藏页、弹窗页、工作台页或复用页，也必须明确说明其权限归属。

### 复用权限规则

如果某个页面或接口不新增独立权限，而是复用已有权限，必须明确写出：

- 当前功能名称
- 复用的权限标识
- 复用原因
- 是否需要新增菜单 SQL

禁止只写“复用已有权限”而不说明具体标识。

### SQL 文件目录规范

- 菜单 SQL 文件统一放在：`shop-trade-service-business/sql/mysql/menu/`
- 文件命名统一建议为：`YYYY-MM-DD_<topic>_menu.sql`

例如：

- `2026-07-09_product_publish_status_menu.sql`
- `2026-07-09_material_library_menu.sql`

### 当前项目已知菜单权限基线

#### 基础配置

- 产品类目
  - `business:product-category:query`
  - `business:product-category:create`
  - `business:product-category:update`
  - `business:product-category:delete`

- 产品属性模板
  - `business:product-attr-template:query`
  - `business:product-attr-template:create`
  - `business:product-attr-template:update`
  - `business:product-attr-template:delete`

#### 映射中心

- 类目映射
  - `business:mapping-center:category-mapping:query`
  - `business:mapping-center:category-mapping:save`

- 字段映射
  - `business:mapping-center:field-mapping:query`
  - `business:mapping-center:field-mapping:save`

- 上游分类
  - `business:mapping-center:upstream-category:query`

#### 产品管理

- 产品数据
  - `business:product-external-raw:query`
  - `business:product-external-raw:create`
  - `business:product-external-raw:update`
  - `business:product-external-raw:delete`

- 产品列表
  - `business:product:query`
  - `business:product:create`
  - `business:product:update`
  - `business:product:delete`

- 货币与汇率
  - `business:exchange-rate:query`
  - `business:exchange-rate:update`
  - `business:exchange-rate:sync`

#### 商城装修

- 品类页装修
  - `business:product-category-decoration:query`
  - `business:product-category-decoration:create`
  - `business:product-category-decoration:update`
  - `business:product-category-decoration:delete`

- 装修工作台
  - 当前复用：
    - `business:product:query`

#### 素材库

- 素材分类
  - `material-category:query`
  - `material-category:create`
  - `material-category:update`
  - `material-category:delete`

- 素材管理
  - `material:query`
  - `material:create`
  - `material:update`
  - `material:delete`
  - `material:publish`

- 素材引用
  - `material-reference:query`
  - 当前写操作复用：
    - `material:update`

#### 已知复用权限场景

- 产品清洗相关页面
  - 复用：
    - `business:product-external-raw:query`
    - `business:product-external-raw:update`

- 产品场景关联
  - 复用：
    - `business:product:query`

- 产品发布状态批量查询
  - 复用：
    - `business:product:query`

- 素材引用绑定 / 解绑
  - 复用：
    - `material:update`

### 输出格式要求

当后续功能涉及菜单权限时，输出内容必须至少包含以下结构：

1. 功能名称
2. 是否新增菜单 SQL
3. 新增权限标识
4. 复用权限标识
5. 菜单层级关系
6. SQL 文件路径
7. 风险说明或差异说明

### 禁止事项

禁止出现以下情况：

- 只改后端权限注解，不补菜单 SQL
- 只补菜单 SQL，不核对后端权限注解
- 新增按钮操作但不补按钮权限
- 页面复用权限但不说明复用关系
- 输出菜单 SQL 时缺失排序、层级、路由、组件信息
- 仅依据旧 SQL 推断权限，不核对当前代码

## 工具类使用

- 新生 Java 代码做字符串判空时，统一使用 Hutool `StrUtil`：
  - 有实际文本内容：`StrUtil.isNotBlank(value)`
  - 空或空白：`StrUtil.isBlank(value)`
  - 只判断非空字符串、不要求去空白时：`StrUtil.isNotEmpty(value)`
- 新生 Java 代码做断言校验时，统一使用 Hutool `Assert`：
  - 对象非空：`Assert.notNull(value, "提示信息")`
  - 字符串非空白：`Assert.notBlank(value, "提示信息")`
  - 字符串非空：`Assert.notEmpty(value, "提示信息")`
  - 条件成立：`Assert.isTrue(condition, "提示信息")`
- 不再新增 `org.springframework.util.StringUtils`、`org.springframework.util.Assert` 的 import。
- 不再新增项目自定义 `hasText(...)` 方法；已有判空逻辑优先直接替换为 Hutool。
- 机械替换时保持原语义：
  - `StringUtils.hasText(value)` -> `StrUtil.isNotBlank(value)`
  - `!StringUtils.hasText(value)` -> `StrUtil.isBlank(value)`
  - `Assert.hasText(value, msg)` -> `Assert.notBlank(value, msg)`
  - `Assert.hasLength(value, msg)` -> `Assert.notEmpty(value, msg)`
