# **Harness 文档规范标准**

## **1. 适用范围**

本规范用于 `harness/docs/**` 下长期维护的 Markdown 文档，也适用于各子项目迁移到 harness 的规范、接口协议、质量门禁和经验沉淀文档。

子项目内部临时说明、一次性排查记录不强制套用本规范；进入 harness 后必须按本规范整理。

## **2. 文件位置**

- 跨项目通用规范放在 `harness/docs/rules/common/`。
- 前端专项规范放在 `harness/docs/rules/web/`。
- Java 后端专项规范放在 `harness/docs/rules/java/`。
- 子项目专属材料放在 `harness/docs/applications/<子项目>/`。
- 可复用经验放在 `harness/docs/experience/`。
- 临时过程材料不要写入 `harness/docs/index.md`。

## **3. 标题规范**

- 文档主标题使用 `# **文档名称**`，必须加粗并作为页面最大标题。
- 一级章节使用 `## **章节名称**`，必须加粗放大，作为页面主要分区。
- 二级说明使用 `### **小节名称**`，仅在内容需要继续拆分时使用。
- 标题不写句号，不使用空泛标题，例如“说明”“其他”“备注”。
- 接口返回格式标题必须说明业务位置和用途，例如 `## **分类类目（顶部找产品 / 找配件返回格式一致）**`。

标准写法：

```md
# **接口返回格式规范**

## **分类类目（顶部找产品 / 找配件返回格式一致）**

### **字段说明**
```

## **4. 代码块规范**

- 所有代码、接口返回、SQL、命令必须使用 fenced code block，不使用截图替代文本。
- 代码块必须声明语言，例如 `js`、`json`、`ts`、`java`、`sql`、`bash`。
- 接口返回示例如果需要中文注释，使用 `js`；无需注释且要求严格 JSON 时，使用 `json`。
- 缩进统一使用 2 个空格。
- 对象和数组必须换行展示，避免压成单行。
- 字段名使用英文，字符串值使用单引号或双引号保持全文一致。
- 枚举值必须在字段旁边用中文注释说明，例如 `tag: 'hot', // 热销 hot，新品 new`。
- 代码块前后各保留一个空行。

## **5. 代码块展示样式**

Markdown 渲染器需要按以下视觉标准展示代码块：

- 标题：加粗、放大，层级清晰。
- 代码区域：浅灰背景、细边框、圆角不超过 8px。
- 代码字体：等宽字体，字号不小于 13px。
- 行高：保持 1.6 到 1.8，便于阅读长接口结构。
- 行号：渲染器支持时必须开启。
- 横向溢出：使用横向滚动，不折断字段名和路径。

推荐 CSS：

```css
.markdown-body h1 {
  font-size: 28px;
  font-weight: 700;
  line-height: 1.35;
}

.markdown-body h2 {
  margin-top: 28px;
  font-size: 22px;
  font-weight: 700;
  line-height: 1.4;
}

.markdown-body pre {
  margin: 12px 0 20px;
  padding: 12px 16px;
  overflow-x: auto;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  background: #f6f8fa;
}

.markdown-body pre code {
  font-family: Consolas, "SFMono-Regular", Menlo, Monaco, monospace;
  font-size: 14px;
  line-height: 1.7;
}
```

## **6. 接口返回格式模板**

接口返回格式文档按“标题 + 说明 + 代码块 + 字段约束”的顺序写。标题必须加粗放大，代码块必须使用 `js` 或 `json`。

## **分类类目（顶部找产品 / 找配件返回格式一致）**

```js
[
  {
    id: 'wjjx',
    name: '挖掘机械',
    groups: [
      {
        title: '按吨位',
        children: [
          { id: 'wjjxOne', name: '微型挖掘机', image: '/home/products/excavator.png' },
          { id: 'wjjxTwo', name: '小型挖掘机', image: '/home/categories/dump-truck.png' },
          { id: 'wjjxThree', name: '中型挖掘机', image: '/home/products/tractor.png' },
          { id: 'wjjxFour', name: '大型挖掘机', image: '/home/products/mower.png' }
        ]
      },
      {
        title: '按行走形式',
        children: [
          { id: 'wjjxFive', name: '履带挖掘机', image: '/home/products/excavator.png' },
          { id: 'wjjxSix', name: '轮式挖掘机', image: '/home/categories/dump-truck.png' },
          { id: 'wjjxSeven', name: '挖掘装载机', image: '/home/products/tractor.png' }
        ]
      }
    ]
  }
]
```

字段约束：

- `id`：业务唯一标识，前后端保持一致。
- `name`：页面展示名称。
- `groups`：二级分组列表，顺序即页面展示顺序。
- `children`：分组下的分类或产品入口。
- `image`：前端可访问的资源路径，不写本地绝对路径。

## **7. 禁止事项**

- 不使用图片表达接口结构。
- 不在代码块外手写大段伪代码。
- 不把未整理的聊天记录、临时截图、一次性排查过程放入规范文档。
- 不在同一份文档里混用 `json`、`js`、`javascript` 三种语言标记表达同一类接口返回。
- 不使用无语言标记的三反引号代码块。

## **8. 维护要求**

- 新增长期文档后，需要在 `harness/docs/index.md` 或对应应用入口文档补充路径。
- 修改接口返回格式时，同步检查示例字段、枚举说明和页面展示名称是否一致。
- 示例数据必须可复制、可搜索，不能只依赖截图。
- 文档与当前代码冲突时，以当前代码为准，并同步修正文档。
