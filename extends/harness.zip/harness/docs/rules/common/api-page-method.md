# 分页接口方法规则

## 结论

`/page`、`/table/page`、`/copy/page` 这类分页查询接口，在 `shop-trade` 里统一使用 `POST`。

## 适用范围

- 后端 Controller 分页接口
- 前端 `src/api/**` 分页请求封装
- 跨模块 RPC / Feign 分页接口

## 后端规则

- 分页接口使用 `@PostMapping`
- 分页查询对象通过 `@RequestBody` 接收
- 常见写法：

```java
@PostMapping("/page")
public CommonResult<PageResult<DemoRespVO>> getDemoPage(
        @Valid @RequestBody DemoPageReqVO pageReqVO) {
    ...
}
```

## 前端规则

- 分页请求统一使用 `request.post`
- 查询条件放到 `data`，不要放到 `params`
- 常见写法：

```ts
export const getDemoPage = (params) => {
  return request.post({ url: '/demo/page', data: params })
}
```

## RPC / Feign 规则

- 分页 RPC 接口统一使用 `@PostMapping`
- 分页 DTO 统一使用 `@RequestBody`
- 不再对分页 DTO 使用 `@SpringQueryMap`

## 允许保留 GET 的情况

- 非分页详情查询，例如 `/get`
- 简单列表查询，例如 `/list`、`/simple-list`
- 文件下载、导出、回调、签名地址等语义上更适合 `GET` 的接口

## 禁止事项

- 新增 `@GetMapping("/page")`
- 新增前端 `request.get({ url: '.../page', params })`
- 只改前端或只改后端，不同步修改另一侧

## 变更检查

- 改造分页接口时，同时检查前端 API、后端 Controller、Feign / RPC 接口
- 如存在历史例外，必须在对应应用文档中单独说明
