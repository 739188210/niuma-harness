# 质量门禁

## 通用完成标准

- 已读取对应 `docs/applications/<子项目>/CLAUDE.md`。
- 改动范围清晰，没有顺手重构无关模块。
- 没有回滚用户已有改动。
- 最终回复说明改动文件、验证命令和未验证风险。

## SQL 改动

- 明确保留数据、删除数据和关联表同步关系。
- 涉及主键重排时，同步更新所有关联表。
- 涉及自增时，按最终最大 ID + 1 设置 `AUTO_INCREMENT`。
- 静态检查分号数量、关键语句和执行顺序。
- 未连接数据库执行时，必须明确说明。

## 后端改动

- 优先运行受影响 Maven 模块的 `compile` 或指定测试。
- 新增业务表时检查公共字段、租户字段、逻辑删除、数据权限字段。
- 新增 DO 时检查 `TenantBaseDO`、`@TableName`、`@TableId(type = IdType.AUTO)` 和 Lombok 注解。
- 新增接口时检查 Controller 分层、VO/DTO 命名和权限控制。
- 如涉及分页接口，检查是否误用了 `@GetMapping("/page")` 或 `@GetMapping("/table/page")`。

## 前端改动

- 优先运行：

```bash
pnpm ts:check
pnpm lint:eslint
pnpm lint:style
```

- 页面、路由、权限改动要手动验证菜单、动态路由、刷新和权限状态。
- 请求层改动要检查 token、租户头、刷新 token 队列和错误提示。
- 如涉及分页请求，检查是否误用了 `request.get(.../page...)`，应统一为 `request.post(.../page..., data)`。
