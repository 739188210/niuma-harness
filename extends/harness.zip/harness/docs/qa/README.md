# QA 文档入口

本目录记录 `shop-trade` 的验证策略和质量门禁。

优先读取：

1. `quality-gates.md`
2. `docs/applications/<子项目>/CLAUDE.md` 中的测试和构建命令
3. 子项目本地测试说明
