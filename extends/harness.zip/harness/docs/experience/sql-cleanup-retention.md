# SQL 清理保留规则

本文件记录当前 `shop-trade-service-system/sql/mysql/retain-red-box-data.sql` 的处理口径。后续补充相关 SQL 时，先读取该 SQL 文件最新内容，再按本文件核对。

## 当前保留目标

- 用户：只保留 `system_users.id = 1` 的 `admin`。
- 部门：只保留根部门 `system_dept.id = 100`。
- 角色：只保留 `system_role.id IN (1, 2, 3)`。
- 用户角色：只保留 `admin` 与保留角色的关系。
- 角色菜单：只保留保留角色的菜单权限关系。
- 岗位：只保留 `admin` 实际绑定的有效岗位，并规整为 `system_post.id = 1`。
- 租户：只保留 `system_tenant.id = 1`。

## 当前关键处理

- `admin.dept_id` 固定更新为 `100`。
- 非 `admin` 用户的非根部门引用先清空，再删除非根部门。
- `system_post.id = 2` 会规整为 `1`。
- `system_user_post.post_id = 2` 同步更新为 `1`。
- 清理指向不存在岗位的用户岗位关联。
- 清理 `admin` 重复岗位关联。

## 自增规划

按当前口径：

- `system_users` -> `AUTO_INCREMENT = 2`
- `system_role` -> `AUTO_INCREMENT = 4`
- `system_dept` -> `AUTO_INCREMENT = 101`
- `system_post` -> `AUTO_INCREMENT = 2`
- `system_tenant` -> `AUTO_INCREMENT = 2`

## 后续修改要求

- 不要凭记忆修改，先读取最新 `retain-red-box-data.sql`。
- 若改变保留主键，必须同步所有关联表。
- 若调整保留部门、岗位、角色，必须同步预期结果注释和自增值。
- 未连接数据库执行时，只能声明静态校验，不要声称实际数据已清理。

