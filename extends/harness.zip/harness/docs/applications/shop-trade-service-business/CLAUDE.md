# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 阅读前置规则

开始阅读当前应用材料前，先读以下规则文件：

- `harness/docs/rules/java/patterns.md`
- 如涉及分页接口，再读 `harness/docs/rules/common/api-page-method.md`

# 易运盈内贸业务模块（shop-trade-service-business）

## Claude Code 快速工作区

### 项目概览

- 本仓库是 **Maven 多模块 Java 17 后端项目**，根 `pom.xml` 聚合两个模块：
  - `shop-trade-service-module-business-api`：对外 API 常量、枚举、DTO/VO 等共享定义
  - `shop-trade-service-module-business-server`：Spring Boot 启动模块与业务实现模块
- 根工程本身是聚合容器，真正的应用入口在 `shop-trade-service-module-business-server`
- 启动类：`shop-trade-service-module-business-server/src/main/java/com/easybiz/shoptrade/module/business/DomesticServerApplication.java`
- 当前默认激活配置见 `shop-trade-service-module-business-server/src/main/resources/application.yaml`，其中 `spring.profiles.active=local`
- 本地开发端口见 `shop-trade-service-module-business-server/src/main/resources/application-local.yaml`，当前为 `48085`

### 常用命令

#### 根目录执行

```bash
# 编译整个多模块项目
mvn clean compile

# 运行全部测试
mvn test

# 打包整个项目
mvn clean package

# 跳过测试打包
mvn clean package -DskipTests
```

#### 启动服务

```bash
# 在根目录启动 business-server
mvn -pl shop-trade-service-module-business-server -am spring-boot:run

# 或先打包再运行 JAR
mvn -pl shop-trade-service-module-business-server -am clean package
java -jar shop-trade-service-module-business-server/target/shop-trade-service-module-business-server.jar
```

#### 运行单个测试

当前仓库 **未发现 `src/test/java` 测试代码**，但如果后续新增测试，优先使用 Maven 的单测筛选：

```bash
# 运行单个测试类
mvn -pl shop-trade-service-module-business-server -Dtest=类名 test

# 运行单个测试方法
mvn -pl shop-trade-service-module-business-server -Dtest=类名#方法名 test
```

如果新增的是 API 模块测试，则将 `-pl shop-trade-service-module-business-server` 替换为 `-pl shop-trade-service-module-business-api`。

### 高层架构

#### 1. 模块边界

- `shop-trade-service-module-business-api` 目前主要承载 **跨模块共享的枚举与常量**，例如 `ErrorCodeConstants`、`DictTypeConstants`、`ApiConstants`
- `shop-trade-service-module-business-server` 承载业务实现，包含：
  - `controller/`：HTTP 接口入口
  - `config/`：Spring / MyBatis / 数据权限等配置
  - `util/`：文档解析、时间处理、脱敏等工具类
  - `job/`：定时任务示例
- 根工程通过私服 BOM `domestic-dependencies` 管理基础依赖，并依赖 system / infra / ai 等外部模块

#### 2. 启动与装配方式

- 应用通过 `@SpringBootApplication(scanBasePackages = {"com.easybiz.shoptrade.server", "com.easybiz.shoptrade.module"})` 扫描公共框架与各业务模块
- 通过 `@EnableFeignClients(basePackages = {"com.easybiz.shoptrade.framework.common.biz.system", "com.easybiz.shoptrade.module.*.api"})` 启用跨模块 Feign 客户端
- 这意味着新增业务代码时，通常遵循 `com.easybiz.shoptrade.module.business.*` 包路径即可被自动扫描

#### 3. 持久层与数据权限

- 持久层基于 **MyBatis-Plus**，类型别名扫描配置在 `application-local.yaml`：`${domestic.info.base-package}.module.*.dal.dataobject`
- 业务表默认采用 **逻辑删除** 与 **多租户基础字段**
- 数据权限的模块入口配置文件是 `shop-trade-service-module-business-server/src/main/java/com/easybiz/shoptrade/module/business/config/DataPermissionConfiguration.java`
- 当前 `DataPermissionConfiguration` 还是占位实现；后续新增需要按部门/用户隔离的数据表时，应优先在这里注册 `DeptDataPermissionRuleCustomizer`

#### 4. 配置与环境

- 主配置文件：`shop-trade-service-module-business-server/src/main/resources/application.yaml`
- 环境配置文件：
  - `application-local.yaml`
  - `application-fat.yaml`
  - `application-prod.yaml`
- `application.yaml` 只负责激活 profile；实际大部分运行配置在各环境文件
- 本地配置中默认关闭了 Nacos 注册与配置中心，便于本地独立启动
- 接口文档通过 `springdoc + knife4j` 暴露，默认路径：
  - `/v3/api-docs`
  - `/swagger-ui`

#### 5. 当前代码现状

- 当前仓库业务实现代码较少，更多是项目骨架、配置和规范约束
- `DefaultController` 用于给未启用模块返回统一的“未实现/已禁用”响应，而不是直接 404
- `DocumentTextExtractor` 是当前较完整的业务工具类之一，负责 PDF / Word / Excel / HTML / 纯文本提取，可作为后续文件处理类的实现参考
- `MybatisInterceptorConfig` 目前更像预留扩展点，逻辑尚未补全；修改持久层拦截器行为时应先核对这里是否只是占位代码

### 修改仓库时的优先关注点

- 若新增业务实体、表结构、Mapper、Service、Controller，优先遵循下方 P0 规范，而不是另起一套命名与分层
- 若新增需要数据权限的业务表，必须同时检查：SQL 字段、DO 继承、`DataPermissionConfiguration` 注册是否完整
- 若补测试，优先按 `docs/00-项目总览/后端开发规范/芋道单元测试.md` 中的模式接入 JUnit5 + Mockito / H2 / Redis 测试基类
- 若文档更新，遵循下方文档目录与命名规范，不要在仓库根目录随意新增 Markdown

> **配置版本**: v2.1
> **最后更新**: 2026-03-28
> **适用范围**: shop-trade-service-business 项目
> **规范级别**: 强制执行（P0）

---

## 配置继承说明

本配置文件继承自：
1. 全局配置 (`C:\Users\mgul\.claude\CLAUDE.md`)
2. 多项目配置 (`E:\mywork\CLAUDE.md`)
3. 父项目配置 (`E:\mywork\domestic-trade-system\CLAUDE.md`)

**本文件覆盖/补充以下规范，具有最高优先级。**

---

## 🔴 P0 - 绝对强制规范（违反必须立即纠正）

### P0-1: 数据库规范（强制执行）

#### 表命名规范
| 项目 | 规范 | 示例 |
|------|------|------|
| 表名 | `模块名_表名`，全小写，下划线分隔 | `business_order`, `business_customer` |
| 引擎 | InnoDB | - |
| 字符集 | utf8mb4 | - |

#### 必选公共字段（所有业务表必须包含）
```sql
`id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
`creator` varchar(64) DEFAULT '' COMMENT '创建者',
`create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
`updater` varchar(64) DEFAULT '' COMMENT '更新者',
`update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
`deleted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除（逻辑删除）',
`tenant_id` bigint NOT NULL DEFAULT 0 COMMENT '租户编号',
PRIMARY KEY (`id`)
```

#### 数据权限字段（需要权限控制的表必须包含）
```sql
`dept_id` bigint DEFAULT NULL COMMENT '部门ID（数据权限）',
`user_id` bigint DEFAULT NULL COMMENT '用户ID（数据权限）',
```

#### 字段命名规范
| 类型 | 规范 | 示例 |
|------|------|------|
| 主键 | `id` | `id` |
| 外键 | `关联表名_id` | `customer_id`, `order_id` |
| 状态 | `status` | `status` tinyint，0-启用 1-禁用 |
| 类型 | `type` 或 `xx_type` | `order_type`, `customer_type` |
| 时间 | `xx_time` | `create_time`, `pay_time` |
| 日期 | `xx_date` | `start_date`, `end_date` |
| 是否 | `is_xx` 或 `xx_flag` | `is_urgent`, `delete_flag` |

#### 主键策略
- **统一使用** `bigint` 自增主键 `AUTO_INCREMENT`
- **禁止使用** UUID、雪花ID（除非有分布式强需求）

**违规后果**: 表结构不符合规范必须重新设计

---

### P0-2: DO/实体规范（强制执行）

#### 继承关系
```
TenantBaseDO（多租户基础类）
├── BaseDO（基础字段：createTime, updateTime, creator, updater, deleted）
│   └── 你的 DO 类
```

#### DO 类强制模板
```java
@TableName("business_order")
@KeySequence("business_order_seq")  // Oracle/PostgreSQL 需要
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderDO extends TenantBaseDO {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String orderNo;
    private Long customerId;
    private Long deptId;    // 数据权限字段
    private Long userId;    // 数据权限字段

    // 业务字段...
    private Integer status;
    private BigDecimal amount;
    private LocalDateTime payTime;
}
```

**强制注解检查清单**:
- [ ] `@TableName` - 指定表名
- [ ] `@Data` - Lombok 数据类
- [ ] `@EqualsAndHashCode(callSuper = true)` - 包含父类字段
- [ ] `@ToString(callSuper = true)` - 包含父类字段
- [ ] `@Builder` - 建造者模式
- [ ] `@NoArgsConstructor` - 无参构造
- [ ] `@AllArgsConstructor` - 全参构造
- [ ] `extends TenantBaseDO` - 继承多租户基础类

**违规后果**: DO 类缺少强制注解必须补充

---

### P0-3: Redis 规范（强制执行）

#### Key 命名规范
格式：`业务:实体:操作:标识`

```
# 好的示例
business:order:info:{orderId}
business:customer:info:{customerId}
business:schedule:info:{scheduleId}

# 禁止
customerData            # 不清晰
businessCustomer        # 驼峰（统一使用下划线）
key1                    # 无意义
```

#### Key 常量定义
统一在 `RedisKeyConstants` 接口中定义：

```java
public interface RedisKeyConstants {
    String BUSINESS_ORDER_INFO = "business:order:info:%s";
    String BUSINESS_CUSTOMER_INFO = "business:customer:info:%s";
    String BUSINESS_SCHEDULE_INFO = "business:schedule:info:%s";
}
```

#### 过期时间规范
| 场景 | 建议过期时间 | 说明 |
|------|-------------|------|
| 订单缓存 | 30分钟 | 业务数据变化较频繁 |
| 客户缓存 | 30分钟 | 业务数据变化较频繁 |
| 日程缓存 | 15分钟 | 实时性要求高 |
| 字典/配置缓存 | 30分钟 | 低频变更数据 |

**违规后果**: Redis Key 不符合命名规范必须修改

---

### P0-4: 数据权限规范（强制执行）

#### 启用步骤

**Step 1: 添加 Starter 依赖（已添加）**
```xml
<dependency>
    <groupId>com.domestic.trade</groupId>
    <artifactId>domestic-spring-boot-starter-biz-data-permission</artifactId>
</dependency>
```

**Step 2: 创建 DataPermissionConfiguration**
```java
package com.easybiz.shoptrade.module.business.config;

import com.easybiz.shoptrade.framework.datapermission.core.rule.dept.DeptDataPermissionRuleCustomizer;
import com.easybiz.shoptrade.module.business.dal.dataobject.order.OrderDO;
import com.easybiz.shoptrade.module.business.dal.dataobject.customer.CustomerInfoDO;
import com.easybiz.shoptrade.module.business.dal.dataobject.schedule.ScheduleInfoDO;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Business 模块的数据权限 Configuration
 *
 * @author 易运盈源码
 */
@Configuration(proxyBeanMethods = false)
public class DataPermissionConfiguration {

    /**
     * 订单管理数据权限配置
     */
    @Bean
    public DeptDataPermissionRuleCustomizer orderDeptDataPermissionRuleCustomizer() {
        return rule -> {
            rule.addDeptColumn(OrderDO.class);
            rule.addUserColumn(OrderDO.class, "user_id");
        };
    }

    /**
     * 客户管理数据权限配置
     */
    @Bean
    public DeptDataPermissionRuleCustomizer customerDeptDataPermissionRuleCustomizer() {
        return rule -> {
            rule.addDeptColumn(CustomerInfoDO.class);
            rule.addUserColumn(CustomerInfoDO.class, "user_id");
        };
    }

    /**
     * 日程管理数据权限配置
     */
    @Bean
    public DeptDataPermissionRuleCustomizer scheduleDeptDataPermissionRuleCustomizer() {
        return rule -> {
            rule.addDeptColumn(ScheduleInfoDO.class);
            rule.addUserColumn(ScheduleInfoDO.class, "user_id");
        };
    }
}
```

**Step 3: 表添加权限字段**
```sql
ALTER TABLE business_order
ADD COLUMN dept_id BIGINT NULL COMMENT '部门ID（数据权限）',
ADD COLUMN user_id BIGINT NULL COMMENT '用户ID（数据权限）';
```

#### 权限级别
| 级别 | 数据库值 | SQL 条件 |
|------|----------|----------|
| 全部数据 | `ALL` | 无 WHERE 条件 |
| 指定部门 | `DEPT_CUSTOM` | `WHERE dept_id IN (?, ?, ...)` |
| 本部门数据 | `DEPT_ONLY` | `WHERE dept_id = ?` |
| 本部门及以下 | `DEPT_AND_CHILD` | `WHERE dept_id IN (?, ?, ...)` |
| 仅本人数据 | `SELF` | `WHERE user_id = ?` |

#### 注解控制
```java
@Service
@DataPermission  // 类级别：所有方法默认开启
public class OrderServiceImpl implements OrderService {

    @Override
    @DataPermission(enable = false)  // 方法级别：禁用数据权限
    public OrderRespVO getOrder(Long id) {
        return orderMapper.selectById(id);
    }
}
```

#### 忽略数据权限
```java
// 临时忽略数据权限执行
DataPermissionUtils.executeIgnore(() -> {
    return orderMapper.selectById(id);
});
```

#### 模块级权限控制清单

| 模块 | 表名 | 是否需要数据权限 | 说明 |
|------|------|-----------------|------|
| 方案管理 | `plan_scheme`, `plan_event` | ✅ 需要 | 按部门/用户隔离 |
| 客户管理 | `customer_info`, `customer_persona` | ✅ 需要 | 按部门/用户隔离 |
| 订单管理 | `order_info`, `order_change_log` | ✅ 需要 | 按部门/用户隔离 |
| 日程管理 | `schedule_info`, `schedule_record` | ✅ 需要 | 按部门/用户隔离 |
| 沟通话术 | `customer_communication_script` | ✅ 需要 | 按部门/用户隔离 |
| 线索池 | `clue_info` | ❌ 不需要 | 业务需求：全部门共享 |
| 知识库 | `knowledge_qa_session`, `knowledge_qa_message` | ❌ 不需要 | 业务需求：全公司共享 |

**违规后果**: 需要数据权限的模块未配置必须补充

---

### P0-5: SQL 变更管理规范（强制执行）

#### 目录结构（强制）
```
sql/
├── mysql/
│   ├── init/                       # 初始化脚本
│   ├── migration/                  # 版本变更脚本
│   │   ├── V1.0.0/                 # 版本目录
│   │   │   ├── V1.0.0_001__create_order_table.sql
│   │   │   └── rollback/           # 回滚脚本目录（强制）
│   │   │       └── R1.0.0_001__drop_order_table.sql
│   └── hotfix/                     # 热修复脚本
```

#### 命名规范（强制）

**变更脚本**:
```
V{版本号}_{序号}__{描述}.sql

示例:
V1.0.0_001__create_customer_table.sql
V1.1.0_002__add_order_index.sql
```

**回滚脚本**:
```
sql/mysql/migration/{版本号}/rollback/R{版本号}_{序号}__{描述}.sql

示例:
sql/mysql/migration/V1.0.0/rollback/R1.0.0_001__drop_customer_table.sql
```

#### 文件头模板（强制）
```sql
-- ============================================
-- 变更描述: 创建客户表
-- 版本: V1.0.0_001
-- 作者: 张三
-- 日期: 2024-03-06
-- 影响表: customer_info
-- 回滚脚本: R1.0.0_001__drop_customer_table.sql
-- ============================================

START TRANSACTION;

-- SQL 语句...

COMMIT;
```

#### 强制检查清单
- [ ] **每个变更脚本必须有对应的回滚脚本**
- [ ] **回滚脚本必须存放在 `rollback/` 子目录下**
- [ ] **所有变更必须使用事务包裹（START TRANSACTION/COMMIT）**
- [ ] **脚本必须包含文件头注释**

**违规后果**: SQL 脚本不符合规范必须重写

---

### P0-6: API 接口规范（强制执行）

#### Controller 分层
```
controller/
├── admin/          # 管理后台接口（需要登录）
│   └── OrderController
└── app/            # 移动端/App 接口（需要登录）
    └── AppOrderController
```

#### DTO 命名
| 类型 | 后缀 | 示例 |
|------|------|------|
| 创建请求 | `CreateReqVO` | `OrderCreateReqVO` |
| 更新请求 | `UpdateReqVO` | `OrderUpdateReqVO` |
| 分页请求 | `PageReqVO` | `OrderPageReqVO` |
| 列表响应 | `RespVO` | `OrderRespVO` |
| 详情响应 | `DetailRespVO` | `OrderDetailRespVO` |

**违规后果**: API 不符合命名规范必须修改

---

### P0-7: Git 提交规范（强制执行）

#### 提交格式
```
类型(模块): 描述

feat(order): 新增订单导出功能
fix(customer): 修复客户查询异常
db(migration): 添加订单表
```

#### 类型说明
| 类型 | 说明 |
|------|------|
| `feat` | 新功能 |
| `fix` | 修复 |
| `chore` | 杂项/配置 |
| `docs` | 文档 |
| `refactor` | 重构 |
| `test` | 测试 |
| `db` | 数据库变更 |

**违规后果**: 提交信息不符合规范必须修改

---

## 🟡 P1 - 强制执行规范

### P1-1: 代码审查检查清单

#### 数据库变更审查
- [ ] 表名是否符合命名规范
- [ ] 是否包含所有公共字段
- [ ] 是否需要数据权限字段
- [ ] 主键是否使用 bigint 自增
- [ ] 字段注释是否完整

#### DO 类审查
- [ ] 是否继承 TenantBaseDO
- [ ] 是否包含所有强制注解
- [ ] 类名是否以 DO 结尾

#### 数据权限审查
- [ ] 新表是否需要数据权限
- [ ] 是否配置了 DataPermissionConfiguration
- [ ] 是否添加了 dept_id/user_id 字段
- [ ] 是否在清单中明确标记不需要权限的表

#### SQL 脚本审查
- [ ] 命名是否符合规范
- [ ] 是否包含文件头
- [ ] 是否使用事务
- [ ] 是否有对应的回滚脚本

---

## 🟢 P2 - 推荐规范

### P2-1: 项目启动类

- **启动类**: `com.easybiz.shoptrade.module.business.BusinessServerApplication`
- **端口**: 8300

### P2-2: 模块结构

```
shop-trade-service-business
├── shop-trade-service-module-business-api/       # API 接口定义
└── shop-trade-service-module-business-server/    # 业务实现
    ├── controller/
    │   ├── admin/                      # 管理端接口
    │   └── app/                        # 应用端接口
    ├── service/                        # 业务逻辑
    ├── dal/                            # 数据访问层
    │   ├── dataobject/                 # DO 实体
    │   └── mapper/                     # MyBatis Mapper
    └── config/                         # 配置类
        └── DataPermissionConfiguration.java
```

### P2-3: 业务模块清单

| 模块 | 说明 | 数据权限 |
|------|------|----------|
| 方案管理 | PlanScheme, PlanEvent | ✅ 需要 |
| 客户管理 | CustomerInfo, CustomerPersona | ✅ 需要 |
| 订单管理 | OrderInfo, OrderChangeLog | ✅ 需要 |
| 日程管理 | ScheduleInfo, ScheduleRecord | ✅ 需要 |
| 沟通话术 | CustomerCommunicationScript | ✅ 需要 |
| 线索池 | ClueInfo | ❌ 不需要 |
| 知识库 | KnowledgeQaSession, KnowledgeQaMessage | ❌ 不需要 |

---

## 📋 项目特定配置

### 技术栈

| 技术 | 版本 |
|------|------|
| Java | 17 |
| Spring Boot | 3.5.9 |
| Spring Cloud | 2025.0.0 |
| MySQL | 8.0+ |
| Redis | 5.0+ |

### 依赖管理

项目依赖 `domestic-dependencies` BOM 管理版本。

### 数据权限 Starter

已引入 `domestic-spring-boot-starter-biz-data-permission`。

---

## 🛠 开发工作流程

### 新增业务表的标准流程

1. **设计表结构** → 遵循数据库规范（P0-1）
2. **编写 SQL 脚本** → 遵循 SQL 变更规范（P0-5）
3. **创建 DO 类** → 遵循 DO 规范（P0-2）
4. **判断是否需要数据权限** → 遵循数据权限规范（P0-4）
5. **配置 DataPermissionConfiguration**（如需要）
6. **创建 Mapper、Service、Controller**
7. **Git 提交** → 遵循 Git 规范（P0-7）

### 不需要数据权限的模块

根据业务需求，以下模块明确不需要数据权限：
- **线索池 (ClueInfo)**：业务需求要求全部门共享
- **知识库检索 (KnowledgeQa)**：业务需求要求全公司共享

在代码注释中必须说明原因：
```java
// ❌ 不需要数据权限（业务需求：线索全部门共享）
// rule.addDeptColumn(ClueInfoDO.class);
```

---

## 📖 文档规范

### 文档目录结构

`docs/` 目录采用 **编号 + 中文目录名**，清晰直观、易检索：

```
docs/
  00-项目总览/           # 文档规范、项目简介、目录说明
  10-需求与规划/         # 需求文档、模块规划、路线图
  20-设计与架构/         # 总体架构、数据库设计、模块设计
  30-接口与协议/         # API接口、Feign接口协议
  40-开发与实现/         # 开发规范、实现说明、脚本说明
  50-测试与质量/         # 测试用例、测试报告、修复报告
  60-运维与部署/         # 部署手册、环境说明、监控告警
  80-调研与决策记录/     # 方案调研、架构比较、决策记录
  90-归档与历史/         # 废弃文档、旧版本、历史资料
  _drafts/              # AI草稿/临时文档
  README.md             # 文档总索引页
```

### 文件命名规范

统一格式：`模块-文档类型-主题-YYYYMMDD-姓名.md`

示例：

- `权限模块-设计-多应用权限方案-20251128-张三.md`
- `Gateway-接口说明-路由配置-20251128-张三.md`
- `系统-决策记录-认证框架选型-20251128-张三.md`

### 文档类型词汇

需求说明、用户故事、模块规划、总体设计、详细设计、数据库设计、接口说明、开发规范、测试用例、测试报告、修复报告、部署手册、配置说明、调研报告、决策记录、使用指南

### AI生成文档规则

1. **所有Markdown文档必须放入 `docs/` 的对应分类目录**
2. 分类规则：

| 文档类型           | 目录                      |
| ------------------ | ------------------------- |
| 需求、规划         | `docs/10-需求与规划/`     |
| 设计、架构         | `docs/20-设计与架构/`     |
| 接口说明           | `docs/30-接口与协议/`     |
| 开发规范、实现说明 | `docs/40-开发与实现/`     |
| 测试用例/报告      | `docs/50-测试与质量/`     |
| 部署、运维、监控   | `docs/60-运维与部署/`     |
| 调研、决策         | `docs/80-调研与决策记录/` |
| 废弃/旧文档        | `docs/90-归档与历史/`     |
| 草稿               | `docs/_drafts/`           |

3. 生成文档时必须给出：完整路径、文件名、文档内容

---

## 📚 参考文档

- **后端开发规范**: `docs/00-项目总览/后端开发规范/开发规范.md`

---

## 📝 版本历史

**v2.1** (2025-03-06)
- ✅ 新增文档规范（目录结构、文件命名、AI生成规则）

**v2.0** (2025-03-06)
- ✅ 新增 P0 强制规范
- ✅ 新增业务模块清单和数据权限控制清单
- ✅ 规范级别升级为强制执行

**v1.0** (2025-02-14)
- ✅ 初始版本

---

**配置文件维护**: Claude Code
**适用范围**: shop-trade-service-business 项目所有开发者
