# Business 分页接口规范

## 适用范围

- `shop-trade-service-module-business-server`
- `shop-trade-service-ui/src/api/business/**`

## 规则

- 后端分页接口统一使用 `@PostMapping("/page")`
- 分页 VO 统一使用 `@Validated @RequestBody`
- 前端分页请求统一使用 `request.post({ url, data: params })`

## 当前落地项

- `product-external-raw/page`
- `exchange-rate/page`

## 检查点

- 改造 Controller 时，同步改对应 `src/api/business/**`
- 改造分页请求时，不要误改 `/get`、`/latest`、`/list`
