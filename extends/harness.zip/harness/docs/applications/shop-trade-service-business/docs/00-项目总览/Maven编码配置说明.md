# Maven 编译器字符编码配置

本文件提供 Maven 配置建议，确保编译过程中正确处理中文字符。

## 方式一：在 pom.xml 中配置（已实施）

项目主 `pom.xml` 文件中已添加以下配置：

```xml
<properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
    <maven.compiler.encoding>UTF-8</maven.compiler.encoding>
</properties>

<build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-compiler-plugin</artifactId>
            <configuration>
                <source>17</source>
                <target>17</target>
                <encoding>UTF-8</encoding>
            </configuration>
        </plugin>
    </plugins>
</build>
```

## 方式二：在 Maven settings.xml 中全局配置

如果需要在全局 Maven 配置中设置字符编码，编辑 `~/.m2/settings.xml` 或 `MAVEN_HOME/conf/settings.xml`：

```xml
<settings>
    <profiles>
        <profile>
            <id>default</id>
            <activation>
                <activeByDefault>true</activeByDefault>
            </activation>
            <properties>
                <!-- 编译器编码 -->
                <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
                <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
                <maven.compiler.encoding>UTF-8</maven.compiler.encoding>
            </properties>
        </profile>
    </profiles>
</settings>
```

## 方式三：在命令行中指定编码

运行 Maven 命令时直接指定编码：

```bash
# 编译时指定编码
mvn clean compile -Dfile.encoding=UTF-8

# 打包时指定编码
mvn clean package -Dfile.encoding=UTF-8

# 运行测试时指定编码
mvn test -Dfile.encoding=UTF-8
```

## 验证编码配置是否生效

### 方法一：检查编译日志

```bash
mvn compile -X | grep encoding
```

输出中应该包含 `encoding=UTF-8` 的相关信息。

### 方法二：检查源文件编码

```bash
# Linux/Mac - 使用 file 命令
file shop-trade-service-module-business-server/src/main/java/com/easybiz/shoptrade/module/business/DomesticServerApplication.java

# 输出示例：
# ... UTF-8 Unicode (with BOM) text
# 或
# ... UTF-8 Unicode text
```

```powershell
# Windows PowerShell - 检查文件编码
[System.IO.File]::ReadAllText("path/to/file.java") | Out-Null
$EncodingName = [System.Text.Encoding]::Default.WebName
Write-Host $EncodingName
```

### 方法三：运行包含中文的单元测试

创建一个测试类来验证中文处理：

```java
@Test
public void testChineseCharacters() {
    String message = "测试中文字符";
    assertEquals(6, message.length());
    log.info("中文测试消息: {}", message);
}
```

## 常见问题

### Q: Maven 编译时出现"编码 GBK 的不可映射字符"错误？
**A:** 这说明 Maven 使用了系统默认编码（Windows 上通常是 GBK）而不是 UTF-8。
- 解决方案：确保 pom.xml 中有 UTF-8 编码配置，或使用 `-Dfile.encoding=UTF-8` 参数运行 Maven

### Q: 如何检查 Maven 当前使用的编码？
**A:** 运行以下命令：
```bash
mvn -v
java -XshowSettings:properties 2>&1 | grep file.encoding
```

### Q: 在 Windows 上如何正确设置字符编码？
**A:** 
1. 在 IDE 中将所有文件编码设置为 UTF-8
2. 在 Maven 命令中加上 `-Dfile.encoding=UTF-8`
3. 或在 PowerShell 中运行：`chcp 65001` 然后再运行 Maven 命令

## 最佳实践

1. **项目级配置优先**：在 pom.xml 中配置字符编码（已完成）
2. **IDE 配置一致**：确保开发工具使用相同的 UTF-8 编码
3. **Git 配置**：在 `.gitattributes` 中指定文件编码
4. **构建服务器**：在 CI/CD 流程中使用 `-Dfile.encoding=UTF-8` 参数

## 参考资源

- [Apache Maven - Encoding](https://maven.apache.org/general.html#Encoding)
- [Maven Compiler Plugin](https://maven.apache.org/plugins/maven-compiler-plugin/)
- [Spring Boot 官方文档](https://spring.io/projects/spring-boot)

---

**更新日期:** 2024-02-19

