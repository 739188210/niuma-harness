# AI模块工作流配置说明

## 1. 概述

本文档说明如何在 AI 模块（shop-trade-service-ai）中配置知识库问答所需的工作流。

## 2. 工作流配置方式

### 2.1 配置入口

有两种方式配置工作流：

1. **管理后台界面配置**（推荐）：通过前端页面可视化配置
2. **数据库直接插入**：通过 SQL 插入工作流配置

### 2.2 工作流数据表

```sql
-- ai_workflow 表结构
CREATE TABLE `ai_workflow` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `name` varchar(255) NOT NULL COMMENT '流程名称',
  `code` varchar(255) NOT NULL COMMENT '流程标识',
  `graph` longtext NOT NULL COMMENT '流程模型（JSON格式）',
  `status` tinyint NOT NULL COMMENT '状态（0-禁用 1-启用）',
  `remark` varchar(256) DEFAULT '' COMMENT '备注',
  `creator` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updater` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` bit(1) NOT NULL DEFAULT b'0',
  `tenant_id` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB COMMENT='AI 工作流';
```

## 3. 需要配置的工作流

| 工作流编码 | 工作流名称 | 用途 |
|-----------|-----------|------|
| `chat_ai` | AI对话工作流 | 处理知识库问答对话 |
| `chat_summery` | 对话摘要工作流 | 归纳总结对话内容 |

## 4. 工作流 Graph 结构

### 4.1 Graph JSON 结构说明

```json
{
  "nodes": [
    {
      "id": "节点ID",
      "type": "节点类型",
      "position": {"x": 坐标, "y": 坐标},
      "data": {
        "title": "节点标题",
        "description": "节点描述",
        "systemPrompt": "系统提示词",
        "userPrompt": "用户提示词",
        "llmId": 模型ID,
        "parameters": [输入参数],
        "outputDefs": [输出定义],
        "expand": true
      }
    }
  ],
  "edges": [
    {
      "id": "边ID",
      "source": "源节点ID",
      "target": "目标节点ID",
      "markerEnd": {"type": "arrowclosed", "width": 20, "height": 20}
    }
  ],
  "viewport": {"x": 0, "y": 0, "zoom": 1}
}
```

### 4.2 节点类型说明

| 节点类型 | 说明 | 用途 |
|---------|------|------|
| `startNode` | 开始节点 | 定义输入参数 |
| `llmNode` | 大模型节点 | 调用AI模型处理 |
| `endNode` | 结束节点 | 定义输出参数 |
| `internalNode` | 内部节点 | 内部处理逻辑 |

## 5. chat_ai 工作流配置

### 5.1 工作流说明

- **编码**: `chat_ai`
- **名称**: AI知识库对话工作流
- **功能**: 接收上下文和知识引用，调用AI模型生成回复

### 5.2 输入参数

| 参数名 | 类型 | 说明 |
|-------|------|------|
| `context` | String | 完整上下文（SystemPrompt + 摘要 + 历史对话） |
| `knowledgeRefs` | List | 知识库引用列表 |
| `sessionId` | Long | 会话ID |
| `modelConfig` | Object | 模型配置（modelId, temperature, maxTokens） |

### 5.3 输出参数

| 参数名 | 类型 | 说明 |
|-------|------|------|
| `content` | String | AI生成的回复内容 |
| `finishReason` | String | 完成原因 |
| `usage` | Object | Token使用统计 |

### 5.4 Graph JSON 示例

```json
{
  "nodes": [
    {
      "id": "node_start",
      "type": "startNode",
      "position": {"x": 100, "y": 100},
      "data": {
        "title": "开始",
        "description": "接收对话输入参数",
        "expand": true,
        "parameters": [
          {"id": "param_context", "name": "context", "required": true},
          {"id": "param_knowledgeRefs", "name": "knowledgeRefs", "required": false},
          {"id": "param_sessionId", "name": "sessionId", "required": true},
          {"id": "param_modelConfig", "name": "modelConfig", "required": true}
        ]
      }
    },
    {
      "id": "node_llm",
      "type": "llmNode",
      "position": {"x": 500, "y": 100},
      "data": {
        "title": "AI对话",
        "description": "调用大模型生成回复",
        "systemPrompt": "你是企业知识助手，基于提供的知识库内容回答用户问题。请确保回答准确、专业，并引用相关知识。",
        "userPrompt": "${context}",
        "llmId": 50,
        "parameters": [
          {"id": "ref_context", "ref": "node_start.context", "name": "context"}
        ],
        "outputDefs": [
          {"id": "out_content", "name": "content", "dataType": "String"},
          {"id": "out_finishReason", "name": "finishReason", "dataType": "String"},
          {"id": "out_usage", "name": "usage", "dataType": "Object"}
        ],
        "expand": true
      }
    },
    {
      "id": "node_end",
      "type": "endNode",
      "position": {"x": 900, "y": 100},
      "data": {
        "title": "结束",
        "description": "返回AI回复结果",
        "outputDefs": [
          {"id": "out_content", "ref": "node_llm.content", "name": "content"},
          {"id": "out_finishReason", "ref": "node_llm.finishReason", "name": "finishReason"},
          {"id": "out_usage", "ref": "node_llm.usage", "name": "usage"}
        ]
      }
    }
  ],
  "edges": [
    {
      "id": "edge_start_llm",
      "source": "node_start",
      "target": "node_llm",
      "markerEnd": {"type": "arrowclosed", "width": 20, "height": 20}
    },
    {
      "id": "edge_llm_end",
      "source": "node_llm",
      "target": "node_end",
      "markerEnd": {"type": "arrowclosed", "width": 20, "height": 20}
    }
  ],
  "viewport": {"x": 0, "y": 0, "zoom": 1}
}
```

### 5.5 SQL 插入语句

```sql
INSERT INTO `ai_workflow` (
  `name`, `code`, `graph`, `status`, `remark`, `tenant_id`
) VALUES (
  'AI知识库对话工作流',
  'chat_ai',
  '{"nodes":[{"id":"node_start","type":"startNode","position":{"x":100,"y":100},"data":{"title":"开始","description":"接收对话输入参数","expand":true,"parameters":[{"id":"param_context","name":"context","required":true},{"id":"param_knowledgeRefs","name":"knowledgeRefs","required":false},{"id":"param_sessionId","name":"sessionId","required":true},{"id":"param_modelConfig","name":"modelConfig","required":true}]}},{"id":"node_llm","type":"llmNode","position":{"x":500,"y":100},"data":{"title":"AI对话","description":"调用大模型生成回复","systemPrompt":"你是企业知识助手，基于提供的知识库内容回答用户问题。请确保回答准确、专业，并引用相关知识。","userPrompt":"${context}","llmId":50,"parameters":[{"id":"ref_context","ref":"node_start.context","name":"context"}],"outputDefs":[{"id":"out_content","name":"content","dataType":"String"},{"id":"out_finishReason","name":"finishReason","dataType":"String"},{"id":"out_usage","name":"usage","dataType":"Object"}],"expand":true}},{"id":"node_end","type":"endNode","position":{"x":900,"y":100},"data":{"title":"结束","description":"返回AI回复结果","outputDefs":[{"id":"out_content","ref":"node_llm.content","name":"content"},{"id":"out_finishReason","ref":"node_llm.finishReason","name":"finishReason"},{"id":"out_usage","ref":"node_llm.usage","name":"usage"}]}}],"edges":[{"id":"edge_start_llm","source":"node_start","target":"node_llm","markerEnd":{"type":"arrowclosed","width":20,"height":20}},{"id":"edge_llm_end","source":"node_llm","target":"node_end","markerEnd":{"type":"arrowclosed","width":20,"height":20}}],"viewport":{"x":0,"y":0,"zoom":1}}',
  1,
  '知识库问答AI对话工作流',
  0
);
```

## 6. chat_summery 工作流配置

### 6.1 工作流说明

- **编码**: `chat_summery`
- **名称**: 对话摘要归纳工作流
- **功能**: 对对话内容进行归纳总结，提取关键信息

### 6.2 输入参数

| 参数名 | 类型 | 说明 |
|-------|------|------|
| `sessionId` | Long | 会话ID |
| `existingSummary` | String | 已有摘要（可能为空） |
| `messages` | List | 待归纳的消息列表（含role和content） |
| `modelConfig` | Object | 模型配置（使用轻量级模型如gpt-4o-mini） |

### 6.3 输出参数

| 参数名 | 类型 | 说明 |
|-------|------|------|
| `summary` | String | 生成的摘要内容 |
| `keyPoints` | List | 关键要点列表 |
| `messageCount` | Integer | 已归纳消息数 |
| `usage` | Object | Token使用统计 |

### 6.4 Prompt 模板

```
请对以下对话内容进行归纳总结，提取关键信息。

{{#if existingSummary}}
【此前对话摘要】
{{existingSummary}}

{{/if}}
【新增对话】
{{#each messages}}
{{#if (eq role "user")}}用户{{else}}AI{{/if}}：{{content}}
{{/each}}

要求：
1. 整合已有摘要和新增内容（如有）
2. 总结对话主题和核心讨论点
3. 提取用户关心的主要问题
4. 记录AI提供的关键解答
5. 字数控制在200-300字

请输出结构化摘要：
```

### 6.5 Graph JSON 示例

```json
{
  "nodes": [
    {
      "id": "node_start",
      "type": "startNode",
      "position": {"x": 100, "y": 100},
      "data": {
        "title": "开始",
        "description": "接收摘要输入参数",
        "expand": true,
        "parameters": [
          {"id": "param_sessionId", "name": "sessionId", "required": true},
          {"id": "param_existingSummary", "name": "existingSummary", "required": false},
          {"id": "param_messages", "name": "messages", "required": true},
          {"id": "param_modelConfig", "name": "modelConfig", "required": true}
        ]
      }
    },
    {
      "id": "node_prompt",
      "type": "internalNode",
      "position": {"x": 300, "y": 100},
      "data": {
        "title": "构建Prompt",
        "description": "构建归纳摘要Prompt",
        "handler": "buildSummarizePrompt"
      }
    },
    {
      "id": "node_llm",
      "type": "llmNode",
      "position": {"x": 600, "y": 100},
      "data": {
        "title": "生成摘要",
        "description": "调用大模型生成摘要",
        "systemPrompt": "你是对话摘要助手。请对提供的对话内容进行归纳总结，提取关键信息。要求：1.整合已有摘要和新增内容；2.总结对话主题和核心讨论点；3.提取用户关心的主要问题；4.记录AI提供的关键解答；5.字数控制在200-300字。",
        "userPrompt": "${prompt}",
        "llmId": 51,
        "parameters": [
          {"id": "ref_prompt", "ref": "node_prompt.prompt", "name": "prompt"}
        ],
        "outputDefs": [
          {"id": "out_summary", "name": "summary", "dataType": "String"},
          {"id": "out_usage", "name": "usage", "dataType": "Object"}
        ],
        "expand": true
      }
    },
    {
      "id": "node_end",
      "type": "endNode",
      "position": {"x": 1000, "y": 100},
      "data": {
        "title": "结束",
        "description": "返回摘要结果",
        "outputDefs": [
          {"id": "out_summary", "ref": "node_llm.summary", "name": "summary"},
          {"id": "out_usage", "ref": "node_llm.usage", "name": "usage"}
        ]
      }
    }
  ],
  "edges": [
    {
      "id": "edge_start_prompt",
      "source": "node_start",
      "target": "node_prompt",
      "markerEnd": {"type": "arrowclosed", "width": 20, "height": 20}
    },
    {
      "id": "edge_prompt_llm",
      "source": "node_prompt",
      "target": "node_llm",
      "markerEnd": {"type": "arrowclosed", "width": 20, "height": 20}
    },
    {
      "id": "edge_llm_end",
      "source": "node_llm",
      "target": "node_end",
      "markerEnd": {"type": "arrowclosed", "width": 20, "height": 20}
    }
  ],
  "viewport": {"x": 0, "y": 0, "zoom": 1}
}
```

### 6.6 SQL 插入语句（简化版）

```sql
INSERT INTO `ai_workflow` (
  `name`, `code`, `graph`, `status`, `remark`, `tenant_id`
) VALUES (
  '对话摘要归纳工作流',
  'chat_summery',
  '{"nodes":[{"id":"node_start","type":"startNode","position":{"x":100,"y":100},"data":{"title":"开始","description":"接收摘要输入参数","expand":true,"parameters":[{"id":"param_sessionId","name":"sessionId","required":true},{"id":"param_existingSummary","name":"existingSummary","required":false},{"id":"param_messages","name":"messages","required":true},{"id":"param_modelConfig","name":"modelConfig","required":true}]}},{"id":"node_llm","type":"llmNode","position":{"x":500,"y":100},"data":{"title":"生成摘要","description":"调用大模型生成摘要","systemPrompt":"你是对话摘要助手。请对提供的对话内容进行归纳总结，提取关键信息。\n\n要求：\n1. 整合已有摘要和新增内容（如有）\n2. 总结对话主题和核心讨论点\n3. 提取用户关心的主要问题\n4. 记录AI提供的关键解答\n5. 字数控制在200-300字\n\n输入格式：\n【此前对话摘要】（如有）\nxxx\n\n【新增对话】\n用户：xxx\nAI：xxx\n...\n\n请输出结构化摘要：","userPrompt":"${context}","llmId":51,"parameters":[{"id":"ref_context","ref":"node_start.context","name":"context"}],"outputDefs":[{"id":"out_summary","name":"summary","dataType":"String"},{"id":"out_usage","name":"usage","dataType":"Object"}],"expand":true}},{"id":"node_end","type":"endNode","position":{"x":900,"y":100},"data":{"title":"结束","description":"返回摘要结果","outputDefs":[{"id":"out_summary","ref":"node_llm.summary","name":"summary"},{"id":"out_usage","ref":"node_llm.usage","name":"usage"}]}}],"edges":[{"id":"edge_start_llm","source":"node_start","target":"node_llm","markerEnd":{"type":"arrowclosed","width":20,"height":20}},{"id":"edge_llm_end","source":"node_llm","target":"node_end","markerEnd":{"type":"arrowclosed","width":20,"height":20}}],"viewport":{"x":0,"y":0,"zoom":1}}',
  1,
  '知识库问答对话摘要归纳工作流，使用轻量级模型',
  0
);
```

## 7. 模型ID配置

### 7.1 获取模型ID

`llmId` 对应 `ai_model` 表的 `id` 字段。需要查询可用的模型：

```sql
-- 查询可用的大模型
SELECT id, name, model, platform FROM ai_model WHERE type = 1 AND status = 0;
```

### 7.2 推荐模型配置

| 工作流 | 推荐模型 | 说明 |
|-------|---------|------|
| chat_ai | deepseek-chat / qwen-plus | 对话质量高的模型 |
| chat_summery | gpt-4o-mini / qwen-turbo | 轻量级、速度快、成本低 |

## 8. 工作流测试

### 8.1 使用管理后台测试

1. 登录管理后台
2. 进入 AI管理 -> 工作流管理
3. 选择工作流，点击"测试"
4. 输入测试参数，执行测试

### 8.2 使用API测试

```bash
# 测试 chat_ai 工作流
curl -X POST http://localhost:48082/admin-api/ai/workflow/test \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer xxx" \
  -d '{
    "id": 5,
    "params": {
      "sessionId": 123,
      "context": "你是企业知识助手...\n用户：CRM系统的核心功能有哪些？\nAI：",
      "knowledgeRefs": [],
      "modelConfig": {
        "modelId": "deepseek-chat",
        "temperature": 0.7,
        "maxTokens": 2048
      }
    }
  }'
```

## 9. 配置检查清单

- [ ] 创建 `chat_ai` 工作流（编码: chat_ai）
- [ ] 创建 `chat_summery` 工作流（编码: chat_summery）
- [ ] 配置正确的 `llmId`（对应 ai_model 表的模型ID）
- [ ] 工作流状态设置为启用（status = 1）
- [ ] 测试工作流执行正常
- [ ] business 模块配置正确的工作流编码

## 10. 常见问题

### 10.1 工作流不存在错误

```
工作流不存在: chat_ai
```

**解决**: 检查 `ai_workflow` 表中是否存在 `code = 'chat_ai'` 的记录。

### 10.2 模型不存在错误

```
模型不存在: llmId=50
```

**解决**: 检查 `ai_model` 表中是否存在对应ID的模型，且状态为启用。

### 10.3 工作流执行超时

**解决**:
- 检查模型服务是否正常
- 调整 `knowledge-qa.workflow.chat.timeout-seconds` 配置
- 简化 prompt 或减少 maxTokens

### 10.4 白名单限制错误

当前代码中有模型白名单限制 `ALLOWED_LLM_MODELS`，只允许 `qwen-plus-latest` 和 `qwen-flash`。

**解决**:
- 使用白名单内的模型
- 或修改 `AiWorkflowServiceImpl.validateWorkflowModelWhiteList()` 方法扩展白名单

---

**注意**: 工作流配置后需要确保 business 模块的 `application-local.yaml` 中配置的 `workflow-code` 与数据库中的工作流编码一致。
