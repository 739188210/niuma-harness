# 知识库检索 RPC 转 Feign 设计文档

## 一、文档信息

| 项目 | 内容 |
|------|------|
| 文档标题 | 知识库检索 RPC 转 Feign 设计文档 |
| 创建时间 | 2026-02-22 |
| 作者 | Claude |
| 所属模块 | shop-trade-service-ai / shop-trade-service-business |
| 关联需求 | 知识库问答功能 |

---

## 二、背景与问题

### 2.1 原始问题

在知识库问答功能实现中，`AiKnowledgeSegmentApi` 接口使用了 **Dubbo** 作为 RPC 框架：

- 接口定义使用 `@DubboService` 暴露服务
- 调用方使用 `@DubboReference` 注入服务

### 2.2 架构冲突

但本项目整体架构使用 **Spring Cloud OpenFeign** 作为服务间通信方式：

| 组件 | 项目使用 | AiKnowledgeSegmentApi 使用 |
|------|----------|---------------------------|
| RPC 框架 | Feign | Dubbo |
| 服务注册 | Nacos | - |
| 负载均衡 | Spring Cloud LoadBalancer | Dubbo 内置 |

**问题表现**：
- 项目没有引入 Dubbo 相关依赖
- 编译报错：`程序包com.easybiz.shoptrade.module.ai.api.knowledge不存在`
- 运行时无法注入 `@DubboReference` 标记的服务

### 2.3 现有接口对比

| 接口 | 通信方式 | 状态 |
|------|----------|------|
| `AiWorkflowRpcApi` | Feign (`@FeignClient`) | ✅ 正常 |
| `AiSpeechCraftApi` | Feign (`@FeignClient`) | ✅ 正常 |
| `AiKnowledgeSegmentApi` | Dubbo (`@DubboService`) | ❌ 不兼容 |

**结论**：需要统一改为 Feign，保持架构一致性。

---

## 三、设计方案

### 3.1 目标

将 `AiKnowledgeSegmentApi` 从 Dubbo RPC 改为 **Spring Cloud OpenFeign HTTP** 调用。

### 3.2 修改范围

```
shop-trade-service-ai
├── shop-trade-service-module-ai-api
│   └── AiKnowledgeSegmentApi.java              # 添加 @FeignClient
└── shop-trade-service-module-ai-server
    └── AiKnowledgeSegmentApiImpl.java          # 改为 @RestController

shop-trade-service-business
└── shop-trade-service-module-business-server
    └── KnowledgeQaRetriever.java               # 改为 @Resource
```

### 3.3 关键变更

| 变更项 | 原实现 | 新实现 |
|--------|--------|--------|
| 服务暴露 | `@DubboService` | `@RestController` |
| 服务调用 | `@DubboReference` | `@Resource` |
| 传输协议 | Dubbo 二进制 | HTTP JSON |
| 返回包装 | 直接返回 | `CommonResult<T>` |
| 路径定义 | 接口方法 | `@PostMapping` |

---

## 四、详细设计

### 4.1 API 接口层（ai-api）

**文件**：`shop-trade-service-ai/shop-trade-service-module-ai-api/src/main/java/.../AiKnowledgeSegmentApi.java`

```java
@FeignClient(name = "shop-trade-service-module-ai-server", contextId = "aiKnowledgeSegmentApi")
public interface AiKnowledgeSegmentApi {

    String PREFIX = "/rpc-api/ai/knowledge-segment";

    @PostMapping(PREFIX + "/search")
    CommonResult<List<AiKnowledgeSegmentSearchRespDTO>> searchKnowledgeSegment(
            @RequestParam("knowledgeId") Long knowledgeId,
            @RequestParam("content") String content,
            @RequestParam(value = "topK", required = false) Integer topK,
            @RequestParam(value = "similarityThreshold", required = false) Double similarityThreshold);
}
```

**设计要点**：
1. 添加 `@FeignClient` 注解，指定服务名和 contextId
2. 定义 URL 前缀常量 `PREFIX`
3. 方法添加 `@PostMapping` 注解
4. 参数添加 `@RequestParam` 注解
5. 返回类型包装为 `CommonResult<List<T>>`

### 4.2 服务实现层（ai-server）

**文件**：`shop-trade-service-ai/shop-trade-service-module-ai-server/src/main/java/.../AiKnowledgeSegmentApiImpl.java`

```java
@RestController
@Slf4j
public class AiKnowledgeSegmentApiImpl implements AiKnowledgeSegmentApi {

    @Override
    public CommonResult<List<AiKnowledgeSegmentSearchRespDTO>> searchKnowledgeSegment(
            @RequestParam("knowledgeId") Long knowledgeId,
            @RequestParam("content") String content,
            @RequestParam(value = "topK", required = false) Integer topK,
            @RequestParam(value = "similarityThreshold", required = false) Double similarityThreshold) {
        // 业务逻辑...
        return success(result);
    }
}
```

**设计要点**：
1. 将 `@DubboService` 改为 `@RestController`
2. 返回类型改为 `CommonResult<List<T>>`
3. 保留参数校验和业务逻辑

### 4.3 调用方（business-server）

**文件**：`shop-trade-service-business/.../KnowledgeQaRetriever.java`

```java
@Component
@Slf4j
public class KnowledgeQaRetriever {

    @Resource
    private AiKnowledgeSegmentApi knowledgeSegmentApi;

    public List<KnowledgeRefBO> retrieve(Long knowledgeId, String question,
                                         Integer topK, Double similarityThreshold) {
        // 参数校验...
        
        // 执行Feign HTTP调用
        CommonResult<List<AiKnowledgeSegmentSearchRespDTO>> result =
                knowledgeSegmentApi.searchKnowledgeSegment(knowledgeId, question, topK, similarityThreshold);
        
        if (result == null || !result.isSuccess()) {
            log.warn("[retrieve][知识库({})检索失败: {}]", knowledgeId, result != null ? result.getMsg() : "返回为空");
            return Collections.emptyList();
        }
        
        List<AiKnowledgeSegmentSearchRespDTO> segments = result.getData();
        // 后续处理...
    }
}
```

**设计要点**：
1. 将 `@DubboReference` 改为 `@Resource`
2. 处理 `CommonResult` 包装，检查结果状态
3. 错误处理更加完善

---

## 五、接口契约

### 5.1 URL 路径

```
POST /rpc-api/ai/knowledge-segment/search
```

### 5.2 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| knowledgeId | Long | 是 | 知识库ID |
| content | String | 是 | 搜索内容（用户问题）|
| topK | Integer | 否 | 返回数量上限 |
| similarityThreshold | Double | 否 | 相似度阈值（0.0-1.0）|

### 5.3 响应结构

```json
{
  "code": 0,
  "data": [
    {
      "id": 1,
      "documentId": 100,
      "knowledgeId": 10,
      "content": "段落内容...",
      "contentLength": 100,
      "tokens": 50,
      "score": 0.92,
      "documentName": "文档名称.pdf"
    }
  ],
  "msg": ""
}
```

---

## 六、调用链路

```
┌─────────────────────────────────────────────────────────────┐
│                    business-server                          │
│  ┌───────────────────────────────────────────────────────┐  │
│  │         KnowledgeQaRetriever                         │  │
│  │  ┌───────────────────────────────────────────────┐   │  │
│  │  │  @Resource                                    │   │  │
│  │  │  AiKnowledgeSegmentApi                        │   │  │
│  │  │      ↓                                        │   │  │
│  │  │  Feign HTTP 调用                              │   │  │
│  │  └───────────────────────────────────────────────┘   │  │
│  └───────────────────────────────────────────────────────┘  │
└────────────────────────────┬────────────────────────────────┘
                             │ HTTP
                             ↓
┌────────────────────────────┴────────────────────────────────┐
│                      ai-server (Nacos)                      │
│  ┌───────────────────────────────────────────────────────┐  │
│  │      @RestController                                  │  │
│  │      AiKnowledgeSegmentApiImpl                        │  │
│  │              ↓                                        │  │
│  │      AiKnowledgeSegmentService                        │  │
│  │              ↓                                        │  │
│  │      向量检索 / 数据库查询                              │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 七、兼容性分析

### 7.1 向后兼容

- API 路径发生变化（从 Dubbo 注册中心到 HTTP 路径）
- 调用方式从 RPC 代理改为 HTTP 调用
- 需要同时更新调用方和服务方

### 7.2 性能影响

| 指标 | Dubbo | Feign HTTP | 说明 |
|------|-------|-----------|------|
| 序列化 | Hessian2 | JSON | HTTP 稍慢 |
| 连接方式 | 长连接 | 连接池 | 均可复用连接 |
| 传输大小 | 二进制（小）| JSON（大）| 差距约 20-30% |
| 适用场景 | 内部高并发 | 通用 REST | 本场景两者均可 |

**结论**：知识库检索是低频操作（用户提问时触发），Feign HTTP 性能足够。

### 7.3 服务治理

| 功能 | Dubbo | Feign + Nacos | 状态 |
|------|-------|---------------|------|
| 服务注册 | ✅ 内置 | ✅ Nacos | 一致 |
| 服务发现 | ✅ 内置 | ✅ Nacos | 一致 |
| 负载均衡 | ✅ 内置 | ✅ Ribbon/SC LB | 一致 |
| 熔断降级 | ✅ 内置 | ✅ Sentinel | 需配置 |
| 调用链路 | ✅ 内置 | ✅ SkyWalking | 一致 |

---

## 八、测试验证

### 8.1 单元测试

```java
@SpringBootTest
class KnowledgeQaRetrieverTest {

    @Autowired
    private KnowledgeQaRetriever retriever;

    @Test
    void testRetrieve() {
        List<KnowledgeRefBO> result = retriever.retrieve(1L, "测试问题", 5, 0.8);
        assertNotNull(result);
    }
}
```

### 8.2 联调测试

1. 启动 `ai-server` 服务
2. 启动 `business-server` 服务
3. 在 `business-server` 中调用知识库问答接口
4. 验证调用链路正常

---

## 九、风险评估

| 风险 | 可能性 | 影响 | 应对措施 |
|------|--------|------|----------|
| 网络超时 | 中 | 检索失败 | 配置 Feign 超时时间 |
| 服务不可用 | 低 | 检索失败 | 降级返回空列表 |
| JSON 序列化问题 | 低 | 数据错误 | 使用标准 DTO |

---

## 十、总结

### 10.1 改动清单

| 文件 | 变更类型 | 变更内容 |
|------|----------|----------|
| `AiKnowledgeSegmentApi.java` | 修改 | 添加 `@FeignClient`，改为 HTTP 接口定义 |
| `AiKnowledgeSegmentApiImpl.java` | 修改 | 改为 `@RestController`，返回 `CommonResult` |
| `KnowledgeQaRetriever.java` | 修改 | 改为 `@Resource` 注入，处理 `CommonResult` |

### 10.2 收益

1. **架构统一**：所有 AI 模块接口统一使用 Feign
2. **维护简化**：无需引入 Dubbo 依赖和配置
3. **调试便利**：HTTP 接口可直接使用 Postman 测试
4. **团队协作**：符合团队现有技术栈

### 10.3 后续建议

1. 监控知识库检索接口的响应时间和成功率
2. 考虑添加熔断降级机制（Sentinel）
3. 评估是否需要接口缓存（Redis）

---

## 附录：相关文档

- [知识库检索功能检查报告](知识库检索功能检查报告.md)
- [知识库检索功能修复报告](知识库检索功能修复报告.md)
