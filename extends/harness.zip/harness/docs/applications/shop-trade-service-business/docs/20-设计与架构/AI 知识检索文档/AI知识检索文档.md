# AI知识库问答服务设计文档

## 1. 概述

### 1.1 文档信息

| 项目 | 内容 |
|------|------|
| 文档名称 | AI知识库问答服务设计文档 |
| 版本 | v1.0 |
| 作者 | Claude Code |
| 日期 | 2025-02-22 |
| 关联需求 | AI对话流式输出、对话记忆归纳 |

### 1.2 背景与目标

**背景**：
- 知识库问答系统已完成基础架构（会话管理、消息存储、知识检索、归纳触发）
- `KnowledgeQaChatServiceImpl.streamChat()` 中AI流式对话接口为模拟实现（TODO状态）
- `KnowledgeQaSummaryServiceImpl.doSummarize()` 中摘要生成为简化实现（TODO状态）
- TinyFlow工作流引擎已集成，已创建 `chat_ai` 和 `chat_summery` 两个工作流

**目标**：
1. 通过工作流引擎调用AI对话服务，实现真正的流式输出
2. 通过工作流引擎调用AI摘要服务，实现对话记忆自动归纳
3. 与现有知识库问答系统无缝集成

---

## 2. 架构设计

### 2.1 整体架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           前端 (domestic-trade-ui)                           │
│                         KnowledgeQaChat.vue                                  │
│                              │                                               │
│                              ▼                                               │
│                    SSE 流式连接 (/knowledge-qa/chat)                         │
└─────────────────────────────────────────────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Business模块 (shop-trade-service-business)                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ KnowledgeQaController                                                │   │
│  │   └─ POST /chat ──────┐                                              │   │
│  │                       ▼                                              │   │
│  │ KnowledgeQaChatServiceImpl.streamChat()                              │   │
│  │   ├─ 1. 保存用户消息                                                  │   │
│  │   ├─ 2. 知识库检索 (KnowledgeQaRetriever)                             │   │
│  │   ├─ 3. 组装上下文 (buildContext)                                     │   │
│  │   ├─ 4. 【新】调用AI工作流引擎 ────┐                                  │   │
│  │   │                              │                                   │   │
│  │   │                              ▼                                   │   │
│  │   │  KnowledgeQaAiWorkflowEngineService                              │   │
│  │   │      ├─ executeChatWorkflow(sessionId, context)                  │   │
│  │   │      │       │                                                  │   │
│  │   │      │       ▼                                                  │   │
│  │   │      │   AiWorkflowApi.executeWorkflow()                        │   │
│  │   │      │       │                                                  │   │
│  │   │      │       ▼                                                  │   │
│  │   │      │   workflowCode = "chat_ai"                                │   │
│  │   │      │   params = {context, knowledgeRefs, sessionId}            │   │
│  │   │      │                                                          │   │
│  │   │      └─ streamChatEmitter() 流式返回SSE                          │   │
│  │   │                                                                  │   │
│  │   └─ 5. 保存AI消息                                                   │   │
│  │                                                                      │   │
│  │ KnowledgeQaMessageService.saveAssistantMessage()                     │   │
│  │   └─ 触发归纳检查 ───────┐                                           │   │
│  │                         ▼                                           │   │
│  │ KnowledgeQaSummaryService.triggerSummarize()                         │   │
│  │   └─ 【新】调用AI工作流引擎 ────┐                                    │   │
│  │                              │                                       │   │
│  │                              ▼                                       │   │
│  │                    KnowledgeQaAiWorkflowEngineService                │   │
│  │                        └─ executeSummarizeWorkflow()                 │   │
│  │                                │                                     │   │
│  │                                ▼                                     │   │
│  │                            workflowCode = "chat_summery"             │   │
│  │                            params = {messages, existingSummary}      │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                       │
                                       │ Feign RPC
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         AI模块 (shop-trade-service-ai)                           │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ AiWorkflowController                                                 │   │
│  │   └─ POST /workflow/execute                                          │   │
│  │                                                                      │   │
│  │ TinyFlow工作流引擎                                                    │   │
│  │   ├─ chat_ai: 聊天工作流                                              │   │
│  │   │       ├─ 输入: context, knowledgeRefs                             │   │
│  │   │       ├─ 节点1: 参数校验                                          │   │
│  │   │       ├─ 节点2: 调用AI模型 (流式)                                  │   │
│  │   │       ├─ 节点3: 输出格式化                                        │   │
│  │   │       └─ 输出: {content, finishReason, usage}                     │   │
│  │   │                                                                  │   │
│  │   └─ chat_summery: 总结工作流                                         │   │
│  │           ├─ 输入: messages, existingSummary                          │   │
│  │           ├─ 节点1: 参数校验                                          │   │
│  │           ├─ 节点2: 构建归纳Prompt                                     │   │
│  │           ├─ 节点3: 调用AI模型 (非流式)                                │   │
│  │           ├─ 节点4: 摘要结构化处理                                     │   │
│  │           └─ 输出: {summary, messageCount, tokens}                    │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 工作流定义

#### 2.2.1 聊天工作流 (chat_ai)

| 属性 | 值 |
|------|-----|
| 工作流编码 | `chat_ai` |
| 工作流名称 | AI知识库对话工作流 |
| 执行方式 | 流式输出 (SSE) |
| 输入参数 | `context`, `knowledgeRefs`, `sessionId`, `question` |
| 输出结果 | 流式文本内容 |

**工作流节点设计**：

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Start     │────▶│  参数校验   │────▶│  AI模型调用 │────▶│  输出格式化 │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
                                              │
                                              ▼
                                       ┌─────────────┐
                                       │  流式返回   │
                                       └─────────────┘
```

**输入参数结构**：

```json
{
  "sessionId": 123,
  "context": "你是企业知识助手...\n此前对话摘要：...\n用户：CRM系统的核心功能有哪些？\nAI：",
  "knowledgeRefs": [
    {
      "docId": 1,
      "docName": "CRM产品介绍",
      "content": "CRM系统核心功能包括...",
      "similarity": 0.92
    }
  ],
  "modelConfig": {
    "modelId": "deepseek-chat",
    "temperature": 0.7,
    "maxTokens": 2048
  }
}
```

**输出数据结构**：

```json
{
  "content": "CRM系统的核心功能包括客户管理、销售管理、营销自动化...",
  "finishReason": "stop",
  "usage": {
    "promptTokens": 1024,
    "completionTokens": 256,
    "totalTokens": 1280
  }
}
```

#### 2.2.2 总结工作流 (chat_summery)

| 属性 | 值 |
|------|-----|
| 工作流编码 | `chat_summery` |
| 工作流名称 | AI对话摘要归纳工作流 |
| 执行方式 | 同步调用 |
| 输入参数 | `messages`, `existingSummary` |
| 输出结果 | 结构化摘要内容 |

**工作流节点设计**：

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Start     │────▶│  参数校验   │────▶│ Prompt构建  │────▶│  AI模型调用 │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
                                                                    │
                                                                    ▼
                                                             ┌─────────────┐
                                                             │ 结构化处理  │
                                                             └─────────────┘
```

**输入参数结构**：

```json
{
  "sessionId": 123,
  "existingSummary": "此前讨论了CRM系统的基本概念",
  "messages": [
    {"role": "user", "content": "CRM系统的核心功能有哪些？"},
    {"role": "assistant", "content": "CRM系统的核心功能包括客户管理..."}
  ],
  "modelConfig": {
    "modelId": "gpt-4o-mini",
    "temperature": 0.3,
    "maxTokens": 512
  }
}
```

**输出数据结构**：

```json
{
  "summary": "用户询问CRM系统核心功能，AI详细介绍了客户管理、销售管理、营销自动化等功能模块。",
  "keyPoints": ["客户管理", "销售管理", "营销自动化"],
  "messageCount": 2,
  "usage": {
    "promptTokens": 512,
    "completionTokens": 128,
    "totalTokens": 640
  }
}
```

---

## 3. 核心服务设计

### 3.1 KnowledgeQaAiWorkflowEngineService

基于 `PlanWorkflowEngineService` 的设计模式，创建工作流引擎服务专门处理AI问答相关的工作流调用。

```java
/**
 * AI问答工作流引擎服务
 * 调用AI模块的TinyFlow工作流，实现对话和摘要功能
 */
public interface KnowledgeQaAiWorkflowEngineService {

    /**
     * 执行AI对话工作流（流式）
     * 通过SSE方式流式返回AI回复内容
     *
     * @param sessionId 会话ID
     * @param context 完整上下文（SystemPrompt + 摘要 + 知识引用 + 历史对话）
     * @param knowledgeRefs 知识库引用列表
     * @param emitter SSE发射器，用于流式返回
     */
    void executeChatWorkflow(Long sessionId, String context,
                             List<KnowledgeRefBO> knowledgeRefs,
                             SseEmitter emitter);

    /**
     * 执行摘要归纳工作流（非流式）
     *
     * @param sessionId 会话ID
     * @param existingSummary 已有摘要（可能为null）
     * @param messages 待归纳的消息列表
     * @return 生成的摘要内容
     */
    String executeSummarizeWorkflow(Long sessionId, String existingSummary,
                                    List<KnowledgeQaMessageDO> messages);
}
```

### 3.2 实现类 KnowledgeQaAiWorkflowEngineServiceImpl

参考 `PlanWorkflowEngineServiceImpl` 的实现模式：

```java
@Slf4j
@Service
@RequiredArgsConstructor
public class KnowledgeQaAiWorkflowEngineServiceImpl implements KnowledgeQaAiWorkflowEngineService {

    private final AiWorkflowApi aiWorkflowApi;

    // 工作流编码常量
    private static final String WORKFLOW_CHAT_AI = "chat_ai";
    private static final String WORKFLOW_CHAT_SUMMARY = "chat_summery";

    @Override
    public void executeChatWorkflow(Long sessionId, String context,
                                    List<KnowledgeRefBO> knowledgeRefs,
                                    SseEmitter emitter) {
        log.info("[executeChatWorkflow][开始执行AI对话工作流] sessionId={}", sessionId);

        try {
            // 1. 构建工作流参数
            Map<String, Object> params = buildChatWorkflowParams(sessionId, context, knowledgeRefs);

            // 2. 执行工作流（流式场景下，工作流内部会处理SSE）
            // 注意：TinyFlow工作流引擎是否支持流式需要确认
            // 如果不支持流式，需要改为直接调用AI模块的流式接口

            AiWorkflowExecuteReqDTO reqDTO = new AiWorkflowExecuteReqDTO();
            reqDTO.setWorkflowCode(WORKFLOW_CHAT_AI);
            reqDTO.setParams(params);

            CommonResult<AiWorkflowExecuteRespDTO> result = aiWorkflowApi.executeWorkflow(reqDTO);

            // 3. 处理结果并流式返回
            if (result != null && result.getCode() == 0 && result.getData() != null) {
                String content = parseChatResult(result.getData().getResult());
                streamContentToEmitter(content, emitter);
            } else {
                String errorMsg = result != null ? result.getMsg() : "工作流执行失败";
                log.error("[executeChatWorkflow][工作流执行失败] sessionId={}, msg={}", sessionId, errorMsg);
                emitter.send(SseEmitter.event().data(buildErrorResponse(errorMsg)));
            }

        } catch (Exception e) {
            log.error("[executeChatWorkflow][执行异常] sessionId={}", sessionId, e);
            handleEmitterError(emitter, e);
        } finally {
            completeEmitter(emitter);
        }
    }

    @Override
    public String executeSummarizeWorkflow(Long sessionId, String existingSummary,
                                           List<KnowledgeQaMessageDO> messages) {
        log.info("[executeSummarizeWorkflow][开始执行摘要工作流] sessionId={}", sessionId);

        long startTime = System.currentTimeMillis();

        try {
            // 1. 构建工作流参数
            Map<String, Object> params = buildSummarizeWorkflowParams(sessionId, existingSummary, messages);

            // 2. 执行工作流
            AiWorkflowExecuteReqDTO reqDTO = new AiWorkflowExecuteReqDTO();
            reqDTO.setWorkflowCode(WORKFLOW_CHAT_SUMMARY);
            reqDTO.setParams(params);

            CommonResult<AiWorkflowExecuteRespDTO> result = aiWorkflowApi.executeWorkflow(reqDTO);

            // 3. 解析结果
            if (result != null && result.getCode() == 0 && result.getData() != null) {
                String summary = parseSummarizeResult(result.getData().getResult());
                log.info("[executeSummarizeWorkflow][摘要生成完成] sessionId={}, 耗时={}ms",
                        sessionId, System.currentTimeMillis() - startTime);
                return summary;
            } else {
                String errorMsg = result != null ? result.getMsg() : "工作流执行失败";
                log.error("[executeSummarizeWorkflow][工作流执行失败] sessionId={}, msg={}", sessionId, errorMsg);
                throw new RuntimeException("摘要生成失败: " + errorMsg);
            }

        } catch (Exception e) {
            log.error("[executeSummarizeWorkflow][执行异常] sessionId={}", sessionId, e);
            throw new RuntimeException("摘要生成异常", e);
        }
    }

    // ============ 私有方法 ============

    private Map<String, Object> buildChatWorkflowParams(Long sessionId, String context,
                                                        List<KnowledgeRefBO> knowledgeRefs) {
        Map<String, Object> params = new HashMap<>();
        params.put("sessionId", sessionId);
        params.put("context", context);
        params.put("knowledgeRefs", convertKnowledgeRefs(knowledgeRefs));

        // 模型配置（可从配置文件中读取）
        Map<String, Object> modelConfig = new HashMap<>();
        modelConfig.put("modelId", "deepseek-chat");
        modelConfig.put("temperature", 0.7);
        modelConfig.put("maxTokens", 2048);
        params.put("modelConfig", modelConfig);

        return params;
    }

    private Map<String, Object> buildSummarizeWorkflowParams(Long sessionId, String existingSummary,
                                                             List<KnowledgeQaMessageDO> messages) {
        Map<String, Object> params = new HashMap<>();
        params.put("sessionId", sessionId);
        params.put("existingSummary", existingSummary);
        params.put("messages", convertMessages(messages));

        // 摘要模型配置（轻量级模型）
        Map<String, Object> modelConfig = new HashMap<>();
        modelConfig.put("modelId", "gpt-4o-mini");
        modelConfig.put("temperature", 0.3);
        modelConfig.put("maxTokens", 512);
        params.put("modelConfig", modelConfig);

        return params;
    }

    private List<Map<String, Object>> convertKnowledgeRefs(List<KnowledgeRefBO> refs) {
        if (CollUtil.isEmpty(refs)) {
            return Collections.emptyList();
        }
        return refs.stream()
                .map(ref -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("docId", ref.getDocId());
                    map.put("docName", ref.getDocName());
                    map.put("content", ref.getContent());
                    map.put("similarity", ref.getSimilarity());
                    return map;
                })
                .collect(Collectors.toList());
    }

    private List<Map<String, String>> convertMessages(List<KnowledgeQaMessageDO> messages) {
        if (CollUtil.isEmpty(messages)) {
            return Collections.emptyList();
        }
        return messages.stream()
                .map(msg -> {
                    Map<String, String> map = new HashMap<>();
                    map.put("role", msg.getRole() == 1 ? "user" : "assistant");
                    map.put("content", msg.getContent());
                    return map;
                })
                .collect(Collectors.toList());
    }

    private String parseChatResult(Object result) {
        if (result instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) result;
            return (String) map.get("content");
        }
        return result != null ? result.toString() : "";
    }

    private String parseSummarizeResult(Object result) {
        if (result instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) result;
            return (String) map.get("summary");
        }
        return result != null ? result.toString() : "";
    }

    private void streamContentToEmitter(String content, SseEmitter emitter) throws IOException {
        // 模拟流式输出，实际应根据工作流返回的流式结果处理
        String[] chunks = content.split("(?<=\\G.{10})");
        for (String chunk : chunks) {
            KnowledgeQaChatStreamRespVO vo = new KnowledgeQaChatStreamRespVO();
            vo.setType("content");
            vo.setContent(chunk);
            emitter.send(SseEmitter.event().data(JSONUtil.toJsonStr(vo)));
        }
    }

    private void handleEmitterError(SseEmitter emitter, Exception e) {
        try {
            KnowledgeQaChatStreamRespVO errorVo = new KnowledgeQaChatStreamRespVO();
            errorVo.setType("error");
            errorVo.setContent(e.getMessage());
            emitter.send(SseEmitter.event().data(JSONUtil.toJsonStr(errorVo)));
        } catch (IOException ignored) {
        }
        emitter.completeWithError(e);
    }

    private void completeEmitter(SseEmitter emitter) {
        try {
            KnowledgeQaChatStreamRespVO endVo = new KnowledgeQaChatStreamRespVO();
            endVo.setType("end");
            emitter.send(SseEmitter.event().data(JSONUtil.toJsonStr(endVo)));
        } catch (IOException ignored) {
        }
        emitter.complete();
    }

    private String buildErrorResponse(String errorMsg) {
        KnowledgeQaChatStreamRespVO vo = new KnowledgeQaChatStreamRespVO();
        vo.setType("error");
        vo.setContent(errorMsg);
        return JSONUtil.toJsonStr(vo);
    }
}
```

---

## 4. 集成改造点

### 4.1 KnowledgeQaChatServiceImpl 改造

修改 `streamChat` 方法，将模拟的AI回复替换为工作流调用：

```java
@Service
@Validated
@Slf4j
@RequiredArgsConstructor
public class KnowledgeQaChatServiceImpl implements KnowledgeQaChatService {

    private final KnowledgeQaSessionService sessionService;
    private final KnowledgeQaMessageService messageService;
    private final KnowledgeQaSummaryService summaryService;
    private final KnowledgeQaRetriever knowledgeQaRetriever;
    private final KnowledgeQaProperties knowledgeQaProperties;

    // 【新增】注入AI工作流引擎服务
    private final KnowledgeQaAiWorkflowEngineService aiWorkflowEngineService;

    @Override
    public SseEmitter streamChat(KnowledgeQaChatReqVO reqVO) {
        KnowledgeQaSessionDO session = sessionService.validateSession(reqVO.getSessionId());
        SseEmitter emitter = new SseEmitter(0L);
        Long tenantId = TenantContextHolder.getTenantId();

        CompletableFuture.runAsync(() -> {
            try {
                if (tenantId != null) {
                    TenantContextHolder.setTenantId(tenantId);
                }

                // 1. 保存用户消息
                messageService.saveUserMessage(reqVO.getSessionId(), reqVO.getQuestion());

                // 2. 知识库检索
                List<KnowledgeRefBO> knowledgeRefs = null;
                if (knowledgeQaProperties.getRag().isEnabled()) {
                    knowledgeRefs = retrieveKnowledge(session.getKnowledgeBaseId(), reqVO.getQuestion());
                }

                // 3. 组装上下文
                String context = buildContext(reqVO.getSessionId(), reqVO.getQuestion(), knowledgeRefs);

                // 4. 【改造】调用AI工作流引擎（替换原有的模拟代码）
                aiWorkflowEngineService.executeChatWorkflow(
                        reqVO.getSessionId(),
                        context,
                        knowledgeRefs,
                        emitter
                );

                // 5. 保存AI消息（在工作流执行完成后异步保存）
                // 注意：由于流式输出，AI回复内容需要在前端接收完整后通过 /message/save 接口保存
                // 或者在工作流服务内部缓存内容，完成后再回调保存

            } catch (Exception e) {
                log.error("[streamChat][流式对话失败] sessionId={}", reqVO.getSessionId(), e);
                handleStreamError(emitter, e);
            } finally {
                TenantContextHolder.clear();
            }
        });

        return emitter;
    }

    // ... 其他方法保持不变
}
```

### 4.2 KnowledgeQaSummaryServiceImpl 改造

修改 `doSummarize` 方法，使用工作流引擎调用AI摘要：

```java
@Service
@Validated
@Slf4j
@RequiredArgsConstructor
public class KnowledgeQaSummaryServiceImpl implements KnowledgeQaSummaryService {

    private final KnowledgeQaSummaryMapper summaryMapper;
    private final KnowledgeQaMessageService messageService;
    private final KnowledgeQaProperties knowledgeQaProperties;

    // 【新增】注入AI工作流引擎服务
    private final KnowledgeQaAiWorkflowEngineService aiWorkflowEngineService;

    private void doSummarize(Long sessionId) {
        long startTime = System.currentTimeMillis();

        try {
            // 1. 获取待归纳消息
            List<KnowledgeQaMessageDO> messages = messageService.getUnsummarizedMessages(sessionId);
            if (CollUtil.isEmpty(messages)) {
                return;
            }

            // 2. 查询当前摘要记录
            KnowledgeQaSummaryDO summary = summaryMapper.selectBySessionId(sessionId);
            String existingSummary = summary != null ? summary.getSummaryContent() : null;

            // 3. 更新状态为"归纳中"
            summary = updateSummaryStatus(summary, sessionId);

            // 4. 【改造】调用AI工作流引擎生成摘要
            String newSummary = aiWorkflowEngineService.executeSummarizeWorkflow(
                    sessionId,
                    existingSummary,
                    messages
            );

            // 5. 更新摘要记录
            summary.setSummaryContent(newSummary);
            summary.setMessageCount(summary.getMessageCount() + messages.size());
            summary.setStatus(KnowledgeQaSummaryStatusEnum.COMPLETED.getStatus());
            summary.setGenerateTimeMs((int) (System.currentTimeMillis() - startTime));
            summaryMapper.updateById(summary);

            // 6. 标记消息为已归纳
            markMessagesSummarized(messages);

            log.info("[doSummarize][会话({})归纳完成，耗时{}ms，归纳消息数{}]",
                    sessionId, summary.getGenerateTimeMs(), messages.size());

        } catch (Exception e) {
            log.error("[doSummarize][会话({})归纳失败]", sessionId, e);
            resetSummaryStatus(sessionId);
        }
    }

    // ... 其他辅助方法
}
```

---

## 5. 工作流配置详情

### 5.1 chat_ai 工作流配置

```yaml
# TinyFlow 工作流配置示例
workflow:
  code: chat_ai
  name: AI知识库对话工作流
  nodes:
    - id: node_1
      name: 参数校验
      type: validator
      config:
        rules:
          - field: context
            required: true
          - field: sessionId
            required: true

    - id: node_2
      name: AI模型调用
      type: llm
      config:
        model: ${params.modelConfig.modelId}
        temperature: ${params.modelConfig.temperature}
        maxTokens: ${params.modelConfig.maxTokens}
        systemPrompt: |
          你是企业知识助手，基于知识库回答用户问题。
          请根据提供的上下文和知识库引用进行回答。
        stream: true  # 启用流式输出
      input:
        context: ${params.context}
        knowledgeRefs: ${params.knowledgeRefs}

    - id: node_3
      name: 输出格式化
      type: formatter
      config:
        format: json
        template: |
          {
            "content": "${node_2.output.content}",
            "finishReason": "${node_2.output.finishReason}",
            "usage": ${node_2.output.usage}
          }

  output: ${node_3.output}
```

### 5.2 chat_summery 工作流配置

```yaml
# TinyFlow 工作流配置示例
workflow:
  code: chat_summery
  name: AI对话摘要归纳工作流
  nodes:
    - id: node_1
      name: 参数校验
      type: validator
      config:
        rules:
          - field: messages
            required: true

    - id: node_2
      name: Prompt构建
      type: prompt_builder
      config:
        template: |
          请对以下对话内容进行归纳总结，提取关键信息。

          {{#if existingSummary}}
          【此前对话摘要】
          {{existingSummary}}

          {{/if}}
          【新增对话】
          {{#each messages}}
          {{#if (eq role "user")}}用户{{else}}AI{{/if}}：{{content}}
          {{/each}}

          要求：
          1. 整合已有摘要和新增内容（如有）
          2. 总结对话主题和核心讨论点
          3. 提取用户关心的主要问题
          4. 记录AI提供的关键解答
          5. 字数控制在200-300字

          请输出结构化摘要：
      input:
        existingSummary: ${params.existingSummary}
        messages: ${params.messages}

    - id: node_3
      name: AI模型调用
      type: llm
      config:
        model: ${params.modelConfig.modelId}
        temperature: ${params.modelConfig.temperature}
        maxTokens: ${params.modelConfig.maxTokens}
        stream: false  # 非流式
      input:
        prompt: ${node_2.output}

    - id: node_4
      name: 结构化处理
      type: formatter
      config:
        format: json
        template: |
          {
            "summary": "${node_3.output.content}",
            "messageCount": ${params.messages.size()},
            "usage": ${node_3.output.usage}
          }

  output: ${node_4.output}
```

---

## 6. 接口设计

### 6.1 内部服务接口

#### 6.1.1 KnowledgeQaAiWorkflowEngineService

| 方法 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `executeChatWorkflow` | 执行AI对话工作流 | sessionId, context, knowledgeRefs, emitter | void（通过emitter流式返回） |
| `executeSummarizeWorkflow` | 执行摘要归纳工作流 | sessionId, existingSummary, messages | String（摘要内容） |

### 6.2 对外API接口（保持不变）

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 创建会话 | POST | /business/knowledge-qa/session/create | 新建问答会话 |
| 流式对话 | POST | /business/knowledge-qa/chat | SSE流式问答 |
| 保存消息 | POST | /business/knowledge-qa/message/save | 保存AI回复并触发归纳 |
| 结束会话 | POST | /business/knowledge-qa/session/end/{sessionId} | 结束会话 |

---

## 7. 数据模型

### 7.1 核心数据对象（已存在，保持不变）

| 表名 | 说明 |
|------|------|
| `knowledge_qa_session` | 问答会话表 |
| `knowledge_qa_message` | 问答消息表 |
| `knowledge_qa_summary` | 会话归纳摘要表 |

### 7.2 工作流参数对象

```java
/**
 * AI对话工作流参数
 */
@Data
public class ChatWorkflowParams {
    private Long sessionId;
    private String context;
    private List<KnowledgeRef> knowledgeRefs;
    private ModelConfig modelConfig;
}

/**
 * 摘要工作流参数
 */
@Data
public class SummarizeWorkflowParams {
    private Long sessionId;
    private String existingSummary;
    private List<Message> messages;
    private ModelConfig modelConfig;
}

/**
 * 模型配置
 */
@Data
public class ModelConfig {
    private String modelId;
    private Double temperature;
    private Integer maxTokens;
}
```

---

## 8. 配置项

### 8.1 application.yml 配置

```yaml
knowledge-qa:
  # 归纳配置
  summarize:
    threshold: 2        # 每1轮对话（2条消息）触发一次归纳
    async: true         # 异步执行归纳

  # 上下文配置
  context:
    recent-messages: 4  # 保留最近4条消息作为上下文

  # RAG配置
  rag:
    enabled: true
    top-k: 5
    score-threshold: 0.7

  # 【新增】AI工作流配置
  workflow:
    # 对话工作流
    chat:
      workflow-code: chat_ai
      model-id: deepseek-chat
      temperature: 0.7
      max-tokens: 2048
      timeout-seconds: 120

    # 摘要工作流
    summarize:
      workflow-code: chat_summery
      model-id: gpt-4o-mini
      temperature: 0.3
      max-tokens: 512
      timeout-seconds: 30
```

---

## 9. 时序图

### 9.1 AI对话完整流程

```
用户        前端        KnowledgeQaController  KnowledgeQaChatService  KnowledgeQaAiWorkflowEngine  AiWorkflowApi  TinyFlow
 │           │               │                        │                            │              │           │
 │──提问───▶│               │                        │                            │              │           │
 │          │────────POST /chat─────────────────────▶│                            │              │           │
 │          │               │                        │                            │              │           │
 │          │◀─────────────SSE连接建立───────────────│                            │              │           │
 │          │               │                        │                            │              │           │
 │          │               │                        │──streamChat()─────────────▶│              │           │
 │          │               │                        │                            │              │           │
 │          │               │                        │                            │──executeChatWorkflow()───▶│
 │          │               │                        │                            │              │           │
 │          │               │                        │                            │────────POST /execute─────▶│
 │          │               │                        │                            │              │           │
 │          │               │                        │                            │◀────────Result───────────│
 │          │               │                        │                            │              │           │
 │          │               │                        │                            │◀───────流式输出───────────│
 │          │               │                        │◀───────────────────────────│              │           │
 │          │◀────────────SSE: content──────────────│                            │              │           │
 │          │               │                        │                            │◀───────流式输出───────────│
 │          │◀────────────SSE: content──────────────│                            │              │           │
 │          │               │                        │                            │     ...      │           │
 │          │               │                        │                            │◀───────流式结束───────────│
 │          │◀────────────SSE: end──────────────────│                            │              │           │
 │          │               │                        │                            │              │           │
 │          │────────POST /message/save────────────▶│                            │              │           │
 │          │               │                        │                            │              │           │
 │          │               │                        │──saveAssistantMessage()───▶│              │           │
 │          │               │                        │                            │              │           │
 │          │               │                        │──triggerSummarize()──────────────────────────────────▶│
 │          │               │                        │                            │              │           │
```

### 9.2 摘要归纳流程

```
KnowledgeQaSummaryService  KnowledgeQaAiWorkflowEngine  AiWorkflowApi  TinyFlow
           │                            │              │           │
           │──doSummarize()────────────▶│              │           │
           │                            │              │           │
           │                            │──executeSummarizeWorkflow()▶
           │                            │              │           │
           │                            │────────POST /execute─────▶│
           │                            │              │           │
           │                            │              │        【chat_summery】
           │                            │              │           │
           │                            │              │           │
           │                            │◀────────Result───────────│
           │                            │              │           │
           │◀───────────────────────────│              │           │
           │                            │              │           │
```

---

## 10. 风险与应对

| 风险 | 影响 | 应对策略 |
|------|------|----------|
| 工作流引擎不支持流式输出 | 无法实现打字机效果 | 方案A: 直接调用AI模块的流式接口<br>方案B: 使用轮询方式模拟流式效果 |
| 工作流执行超时 | 对话中断 | 配置合理的超时时间（120s）<br>实现超时降级策略（返回友好提示） |
| 模型调用失败 | 对话无法进行 | 实现模型切换机制<br>返回友好的错误提示 |
| 摘要生成过长 | Token超限 | 限制摘要长度（300字以内）<br>使用轻量级模型（gpt-4o-mini） |
| 并发量大 | 系统负载高 | 限流控制<br>异步执行摘要归纳 |

---

## 11. 附录

### 11.1 参考资料

1. `TestWorkflowController.java` - 工作流调用参考实现
2. `PlanWorkflowEngineServiceImpl.java` - 工作流引擎服务参考实现
3. `AiWorkflowApi.java` - AI工作流API接口
4. `知识库问答-设计-内部知识库AI问答与记忆归纳-20260221-Claude.md` - 原知识库问答设计文档

### 11.2 关键代码路径

| 功能 | 文件路径 |
|------|----------|
| 方案工作流引擎 | `shop-trade-service-business/.../service/plangeneration/PlanWorkflowEngineServiceImpl.java` |
| AI工作流API | `shop-trade-service-ai/.../api/workflow/AiWorkflowApi.java` |
| 知识库对话服务 | `shop-trade-service-business/.../knowledgeqa/service/KnowledgeQaChatServiceImpl.java` |
| 知识库摘要服务 | `shop-trade-service-business/.../knowledgeqa/service/KnowledgeQaSummaryServiceImpl.java` |

### 11.3 变更日志

| 版本 | 日期 | 变更内容 |
|------|------|----------|
| v1.0 | 2025-02-22 | 初始版本，基于工作流的AI对话和摘要设计 |

