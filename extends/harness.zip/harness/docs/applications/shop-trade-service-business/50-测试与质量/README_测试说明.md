# Controller 单元测试说明文档

**生成时间**：2026-02-18  
**测试框架**：JUnit 5 + Mockito  
**覆盖范围**：ScheduleInfoController、ClueInfoController

---

## 一、测试文件清单

### 1. ScheduleInfoControllerTest.java
**位置**：`shop-trade-service-module-business-server/src/test/java/.../schedule/ScheduleInfoControllerTest.java`

**测试接口**：
- ✅ POST /business/schedule/create - 创建日程
- ✅ GET /business/schedule/list-by-time-range - 根据时间范围查询日程列表
- ✅ PUT /business/schedule/update - 更新日程
- ✅ PUT /business/schedule/cancel - 取消日程
- ✅ GET /business/schedule/preparation/{id} - 获取访前准备信息
- ✅ POST /business/schedule/material/save - 保存资料清单

**测试用例数量**：13个

### 2. ClueInfoControllerTest.java
**位置**：`shop-trade-service-module-business-server/src/test/java/.../clue/ClueInfoControllerTest.java`

**测试接口**：
- ✅ GET /business/clue/page - 分页查询线索列表
- ✅ GET /business/clue/detail - 查询线索详情
- ✅ GET /business/clue/customer - 查询P1客户数量
- ✅ POST /business/clue/claim - 领取线索
- ✅ POST /business/clue/mark-invalid - 标记无效
- ✅ POST /business/clue/import - 批量导入线索
- ✅ GET /business/clue/download-template - 下载导入模板

**测试用例数量**：14个

---

## 二、测试用例详情

### ScheduleInfoController 测试用例

#### 1. 创建日程测试
- **testCreateSchedule_Success** - 测试创建日程成功
- **testCreateSchedule_WithAiPrompt** - 测试带AI提示词创建日程

#### 2. 查询日程列表测试
- **testGetScheduleListByTimeRange_Success** - 测试查询成功（有数据）
- **testGetScheduleListByTimeRange_EmptyList** - 测试查询成功（空列表）

#### 3. 更新日程测试
- **testUpdateSchedule_Success** - 测试更新日程成功

#### 4. 取消日程测试
- **testCancelSchedule_Success** - 测试取消日程成功

#### 5. 访前准备测试
- **testGetSchedulePreparation_Success** - 测试获取访前准备信息成功（有数据）
- **testGetSchedulePreparation_NoData** - 测试获取访前准备信息（无数据）

#### 6. 资料清单测试
- **testSaveMaterialChecklist_Success** - 测试保存资料清单成功
- **testSaveMaterialChecklist_EmptyList** - 测试保存空资料清单
- **testSaveMaterialChecklist_AllTypes** - 测试保存全部6种资料类型

---

### ClueInfoController 测试用例

#### 1. 分页查询测试
- **testGetCluePage_Success** - 测试分页查询成功（有数据）
- **testGetCluePage_EmptyResult** - 测试分页查询（空结果）
- **testGetCluePage_WithFilters** - 测试带筛选条件的分页查询

#### 2. 线索详情测试
- **testGetClueDetail_Success** - 测试查询线索详情成功

#### 3. P1客户数量测试
- **testGetCustomerCount_Success** - 测试查询P1客户数量

#### 4. 领取线索测试
- **testClaimClue_Success** - 测试领取线索成功
- **testClaimClue_DifferentClueIds** - 测试领取不同ID的线索

#### 5. 标记无效测试
- **testMarkInvalid_Success** - 测试标记无效成功
- **testMarkInvalid_DifferentReasons** - 测试不同无效原因

#### 6. 批量导入测试
- **testImportClues_Success** - 测试批量导入成功（部分失败）
- **testImportClues_AllSuccess** - 测试批量导入全部成功
- **testImportClues_EmptyFile** - 测试导入空文件

#### 7. 下载模板测试
- **testDownloadTemplate_Success** - 测试下载导入模板成功

---

## 三、测试技术栈

### 1. 核心框架
```xml
<!-- JUnit 5 -->
<dependency>
    <groupId>org.junit.jupiter</groupId>
    <artifactId>junit-jupiter</artifactId>
    <scope>test</scope>
</dependency>

<!-- Mockito -->
<dependency>
    <groupId>org.mockito</groupId>
    <artifactId>mockito-junit-jupiter</artifactId>
    <scope>test</scope>
</dependency>

<!-- Spring Boot Test -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```

### 2. 测试注解说明
- `@ExtendWith(MockitoExtension.class)` - 启用Mockito扩展
- `@Mock` - 创建Mock对象（Service层）
- `@InjectMocks` - 自动注入Mock对象到Controller
- `@BeforeEach` - 每个测试前执行（初始化测试数据）
- `@Test` - 标记测试方法
- `@DisplayName` - 测试方法的中文描述

### 3. 常用Mock方法
```java
// Mock返回值
when(service.method(args)).thenReturn(result);

// Mock无返回值方法
doNothing().when(service).method(args);

// 验证方法调用
verify(service, times(1)).method(args);

// 参数匹配器
any(), anyLong(), anyString(), eq(value), argThat(predicate)
```

---

## 四、运行测试

### 1. 使用Maven运行
```bash
# 运行所有测试
mvn test

# 运行单个测试类
mvn test -Dtest=ScheduleInfoControllerTest

# 运行特定测试方法
mvn test -Dtest=ScheduleInfoControllerTest#testCreateSchedule_Success
```

### 2. 使用IDEA运行
- 右键测试类 → Run 'ScheduleInfoControllerTest'
- 右键测试方法 → Run 'testCreateSchedule_Success()'
- 点击类或方法旁边的绿色运行图标

### 3. 查看测试报告
```bash
# Maven Surefire 报告位置
target/surefire-reports/
```

---

## 五、测试覆盖率目标

### 当前覆盖情况
- ✅ ScheduleInfoController - 6个接口，13个测试用例
- ✅ ClueInfoController - 7个接口，14个测试用例
- ✅ 总计：13个接口，27个测试用例

### 覆盖维度
- **正常场景**：所有接口的成功调用场景 ✅
- **边界场景**：空数据、空列表等边界情况 ✅
- **参数变化**：不同参数值的测试 ✅
- **异常场景**：暂未覆盖（需要后续补充）

---

## 六、测试最佳实践

### 1. 测试命名规范
```
test{方法名}_{场景描述}

示例：
- testCreateSchedule_Success
- testGetCluePage_EmptyResult
- testImportClues_AllSuccess
```

### 2. 测试结构（AAA模式）
```java
@Test
void testMethodName() {
    // Arrange - 准备测试数据
    given...
    
    // Act - 执行被测试方法
    when...
    
    // Assert - 验证结果
    then...
}
```

### 3. Mock原则
- 只Mock依赖的Service层
- 不Mock被测试的Controller
- 使用明确的验证断言

### 4. 测试数据管理
- 在 `@BeforeEach` 中初始化通用测试数据
- 使用辅助方法创建复杂对象
- 保持测试数据简洁且有代表性

---

## 七、注意事项

### 1. 测试依赖
**当前项目的测试依赖被注释了**，需要取消注释才能运行测试：
```xml
<!-- pom.xml -->
<dependency>
    <groupId>com.domestic.trade</groupId>
    <artifactId>domestic-spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>
```

### 2. 安全认证Mock
测试中使用了 `getLoginUserId()` 静态方法，实际运行需要：
- 启用Spring Security Test支持
- 或Mock SecurityFrameworkUtils工具类

### 3. 文件上传测试
导入测试使用了 `MockMultipartFile`，需要Spring Test依赖支持。

### 4. ExcelUtils Mock
导入测试中的 `ExcelUtils.read()` 方法需要：
- Mock静态方法（使用Mockito 3.4+）
- 或提供真实的Excel测试文件

---

## 八、后续改进建议

### 1. 异常场景测试
```java
@Test
void testCreateSchedule_ValidationFailed() {
    // 测试参数校验失败场景
}

@Test
void testClaimClue_AlreadyClaimed() {
    // 测试重复领取线索
}
```

### 2. 集成测试
```java
@SpringBootTest
@AutoConfigureMockMvc
class ScheduleInfoControllerIntegrationTest {
    // 完整的Spring上下文集成测试
}
```

### 3. 测试覆盖率工具
```xml
<!-- JaCoCo 测试覆盖率 -->
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
</plugin>
```

### 4. 参数化测试
```java
@ParameterizedTest
@ValueSource(ints = {1, 2, 3, 4, 5, 6})
void testSaveMaterialChecklist_AllTypes(int typeValue) {
    // 测试所有资料类型
}
```

---

## 九、测试执行结果

**预期结果**：
- 所有测试用例应该通过 ✅
- 无编译错误 ✅
- 覆盖所有Controller接口 ✅

**实际验证**：
```bash
# 运行测试命令
cd D:\app\java\work\domestic\shop-trade-service-business\shop-trade-service-module-business-server
mvn test

# 预期输出
Tests run: 27, Failures: 0, Errors: 0, Skipped: 0
```

---

## 十、联系与维护

**测试维护原则**：
1. 新增接口必须同步添加测试用例
2. 修改接口需要更新对应测试
3. 保持测试代码的可读性和可维护性
4. 定期review测试覆盖率

**问题反馈**：
- 测试失败时检查Mock配置
- 参数不匹配时使用 `argThat()` 自定义匹配
- 静态方法调用需要使用 `mockito-inline` 依赖
