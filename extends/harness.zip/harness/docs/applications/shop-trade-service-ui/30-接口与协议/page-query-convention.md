# UI 分页请求规范

## 规则

- `src/api/**` 中的分页请求统一使用 `POST`
- 请求体字段统一使用 `data: params`
- 不再新增 `request.get({ url: '.../page', params })`

## 适用路径

- `/page`
- `/table/page`
- `/copy/page`

## 示例

```ts
export const getDemoPage = (params) => {
  return request.post({ url: '/demo/page', data: params })
}
```

## 说明

- 这里只约束 API 封装层
- 页面组件仍然只调用 `src/api/**`，不要直接在页面里手写分页请求
