# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 阅读前置规则

开始阅读当前应用材料前，先读以下规则文件：

- `harness/docs/rules/web/patterns.md`
- 如涉及分页接口，再读 `harness/docs/rules/common/api-page-method.md`

## 项目概览

这是一个基于 Vue 3、Vite 5、TypeScript、Element Plus、Pinia、Vue Router、UnoCSS 和 SCSS 的后台管理前端项目。

项目整体是“后端驱动菜单 + 前端运行时生成路由”的模式：用户登录后会拉取用户信息和菜单树，再在前端转换成运行时路由、侧边栏和标签页结构。

当前工作区里存在一组大规模的 `src/views/ai/**` 删除变更。后续修改时要特别小心，不要误恢复、误覆盖这批正在进行中的改动。

## 包管理与环境

- 日常开发统一使用 `pnpm`
- 仓库同时存在 `pnpm-lock.yaml` 和 `package-lock.json`，但脚本和使用习惯都以 `pnpm` 为主
- 本地运行项目前，先复制一份 `.env.local.example` 并重命名为 `.env.local`
- 本地开发通常通过 `pnpm dev` 使用 `.env.local`
- `.env.local.example` 中的本地示例配置：
  - `VITE_BASE_URL=http://localhost:48080`
  - `VITE_API_URL=/admin-api`
- 额外环境文件还有：`dev`、`fat`、`test`、`stage`、`prod`

## 常用命令

### 安装依赖

```bash
pnpm install
```

### 启动开发环境

先准备本地环境文件：复制 `.env.local.example` 为 `.env.local`。

```bash
pnpm dev
pnpm dev-server
```

- `pnpm dev`：以 `env.local` 模式启动 Vite
- `pnpm dev-server`：以 `dev` 模式启动 Vite

### 类型检查

```bash
pnpm ts:check
```

### 代码检查与格式化

```bash
pnpm lint:eslint
pnpm lint:format
pnpm lint:style
```

### 构建

```bash
pnpm build:local
pnpm build:dev
pnpm build:fat
pnpm build:test
pnpm build:stage
pnpm build:prod
```

### 预览构建结果

```bash
pnpm preview
pnpm serve:dev
pnpm serve:prod
```

### 清理依赖与缓存

```bash
pnpm clean
pnpm clean:cache
```

## 测试说明

当前 `package.json` 中没有配置 Vitest、Jest 等自动化测试脚本。

因此修改后默认使用以下方式验证：

```bash
pnpm ts:check
pnpm lint:eslint
pnpm lint:style
```

仓库当前也没有“运行单个测试”的标准命令，因为并不存在已接入的测试运行器。

## 高层架构

## 应用启动流程

应用启动入口在 `src/main.ts`，整体顺序如下：

1. 加载 UnoCSS 和全局样式
2. 注册 SVG 图标和全局组件
3. 初始化 i18n
4. 安装 Pinia
5. 安装 Element Plus 和 form-create
6. 安装路由与权限控制
7. 注册自定义指令
8. 注册 DOMPurify，用于降低 `v-html` 的安全风险
9. 注册打印插件和 wangEditor 插件
10. 挂载应用

因此，框架级初始化集中在 `src/main.ts`，各类插件实现则分散在 `src/plugins/**`。

## 路由模型

路由由两部分组成：

- `src/router/modules/remaining.ts`：静态路由，如登录页、首页、错误页、个人中心以及一些隐藏业务页
- 登录后由后端返回的菜单树，再在前端动态转换为路由

核心流程如下：

- `src/permission.ts` 中定义全局前置守卫
- 如果存在 token，但用户信息尚未装载，则调用 `useUserStore().setUserInfoAction()`
- 该方法通过 `src/api/login/index.ts` 的 `/system/auth/get-permission-info` 获取用户信息和菜单
- 用户信息与菜单树会缓存到浏览器存储中
- `usePermissionStore().generateRoutes()` 把后端菜单结构转换为 Vue Router 路由
- 再通过 `router.addRoute()` 动态注册到路由系统中

理解权限、菜单、动态路由问题时，优先一起阅读这些文件：

- `src/permission.ts`
- `src/store/modules/user.ts`
- `src/store/modules/permission.ts`
- `src/utils/routerHelper.ts`
- `types/router.d.ts`

### 动态路由生成细节

`src/utils/routerHelper.ts` 是后端驱动菜单模型的核心。

它通过 `import.meta.glob('../views/**/*.{vue,tsx}')` 扫描视图文件，再把后端返回的菜单配置映射成前端路由。因此需要特别注意：

- 后端菜单里的 `component` 字段需要能匹配到 `src/views` 下的实际文件路径
- 没有子节点的顶级菜单通常会被包一层 `Layout`
- 多级菜单会通过 `flatMultiLevelRoutes` 做层级拍平，以适配路由系统和菜单渲染
- `meta` 字段会直接影响侧边栏、面包屑、TagsView、缓存和高亮行为

如果新增页面需要被后端菜单动态访问，要确认该页面路径能被这套路由映射逻辑正确识别。

## 布局系统

项目外壳布局在 `src/layout/Layout.vue`，内部通过 `useRenderLayout()` 切换不同布局模式。

布局相关状态，例如：

- 是否折叠菜单
- 是否移动端
- 当前布局类型
- 标签页与界面设置

主要由 `src/store/modules/**` 下的 Pinia 模块维护，尤其是：

- `app`
- `permission`
- `tagsView`
- `locale`
- `lock`
- `user`

## 状态管理与缓存

Pinia 初始化位于 `src/store/index.ts`，并启用了 `pinia-plugin-persistedstate`。

除 Pinia 持久化外，项目还通过 `src/hooks/web/useCache.ts` 的 `WebStorageCache` 存储以下内容：

- 用户信息
- 角色菜单路由
- 字典缓存
- 租户相关信息
- 部分界面偏好设置

因此登录态、菜单异常、权限异常这类问题，通常不能只看 Pinia，还要一起检查浏览器缓存。

## API 层

接口按业务域组织在 `src/api/**` 下。

关键模式如下：

- `src/config/axios/service.ts` 是 Axios 核心实现，包含请求/响应拦截器、401 刷新 token 队列、租户头处理、错误提示，以及可选的请求/响应加解密
- `src/config/axios/config.ts` 使用 `VITE_BASE_URL + VITE_API_URL` 组合基础地址
- `src/api/**/index.ts` 中的各业务模块通常只是薄封装

公共请求层统一处理的内容包括：

- Bearer Token 注入
- 租户请求头
- 401 后的 refresh-token 重放队列
- 二进制下载响应处理
- 全局错误提示
- 基于 `@/utils/encrypt` 的可选加解密逻辑

如果要改接口行为，优先判断是否应该放在共享 Axios 层，而不是散落到单个 API 文件里。

## 国际化

i18n 初始化位于 `src/plugins/vueI18n/index.ts`。

语言资源放在 `src/locales/**` 下，静态路由中也有不少标题直接通过 `t(...)` 生成。所以改动文案时，往往不只是改页面文本，也可能需要同步修改语言包和路由元信息。

## 构建系统与自动导入

Vite 相关配置主要在：

- `vite.config.ts`
- `build/vite/index.ts`
- `build/vite/optimize.ts`

需要知道的几个关键点：

- `@/` 指向 `src/`
- AutoImport 会自动注入 Vue、Vue Router 以及部分项目内部 hooks / utils
- `src/components/**` 下的大量组件通过 `unplugin-vue-components` 自动注册
- Element Plus 组件与解析器是自动导入的
- SVG 图标来自 `src/assets/svgs`
- 构建时对 `echarts`、`@form-create/element-ui`、`@form-create/designer` 做了手动分包

因为启用了自动导入，所以很多文件里会刻意省略 `useI18n()` 等函数的显式 import，这属于正常现象。

## 主要业务域

页面和接口整体按业务域组织在 `src/views/**` 与 `src/api/**` 下。目前从代码结构上看，主要包括：

- `system`：用户、角色、菜单、租户、通知、OAuth2、短信、邮件
- `infra`：代码生成、定时任务、文件、Redis、配置、日志、数据源
- `bpm`：流程模型、表单设计、流程实例、任务、监听器、OA 请假等流程场景
- `ai`：聊天、绘图、知识库、工作流、写作、音乐、模型配置等

其中 BPM 模块定制程度比较高，除了页面层 `src/views/bpm/**`，还包含一套可复用的流程设计器基础设施，位于 `src/components/bpmnProcessDesigner/**`。

## 组件约定

- 通用复用组件位于 `src/components/**`
- 真正手动全局注册的组件很少，见 `src/components/index.ts`
- 更多组件依赖 Vite 的自动注册机制
- 业务页面中常见 `index.vue` + `*Form.vue` + 若干子组件的同目录组织方式

## 来自现有仓库说明的重要信息

仓库里已有的 `AGENTS.md` 中，以下信息值得保留并遵循：

- 默认使用 `pnpm`，不要把日常开发切换到 npm
- `src/api/` 放接口封装，`src/views/` 放页面，`src/components/` 放复用组件，`src/store/modules/` 放 Pinia 模块，`src/router/` 管理路由
- 当前没有成熟的自动化测试体系，因此默认验证路径是类型检查 + lint + 受影响功能的手动验证

另外，仓库根目录的 `README.md` 当前基本是通用 GitLab 模板，不适合作为项目真实架构和开发流程的主要依据。优先信任 `package.json`、`vite.config.ts`、`src/main.ts`、`src/router/**`、`src/store/**`、`src/config/axios/**` 与实际代码结构。

## 给后续 Claude 实例的实用建议

- 修改路由、权限、菜单相关逻辑前，先一起阅读 `src/permission.ts`、`src/store/modules/user.ts`、`src/store/modules/permission.ts`、`src/utils/routerHelper.ts`
- 修改登录态、token、请求行为前，先一起阅读 `src/api/login/index.ts`、`src/config/axios/service.ts`、`src/utils/auth.ts`
- 修改布局、导航、侧边栏、标签页时，优先查看 `src/layout/**` 以及路由 `meta` 的使用方式
- 修改 `src/views/ai/**` 邻近文件时要特别谨慎，因为当前工作区已经存在一批 AI 模块删除中的改动
