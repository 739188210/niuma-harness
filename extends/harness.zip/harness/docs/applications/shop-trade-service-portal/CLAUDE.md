# shop-trade-service-portal

## 阅读前置规则

开始阅读当前应用材料前，先读以下规则文件：

- `harness/docs/rules/web/patterns.md`

## 应用定位

- `shop-trade-service-portal` 是 `shop-trade` 下独立的 Nuxt 3 前台门户应用。
- 负责首页、商品详情、分类页、搜索页、多语言页面和 SEO 相关渲染。
- 它与 `shop-trade-service-ui` 不同，不走后台菜单驱动路由体系。

## 技术栈

- Nuxt 3
- Vue 3
- TypeScript
- SSR

## 启动与配置

- 主配置文件：`nuxt.config.ts`
- 默认开发端口：`5178`
- 常见环境变量：
  - `NUXT_API_INTERNAL_BASE`
  - `NUXT_PUBLIC_API_ORIGIN`
  - `NUXT_PUBLIC_API_BASE`
  - `NUXT_PUBLIC_SITE_URL`
  - `NUXT_PUBLIC_CDN_URL`

## 常用命令

```bash
pnpm install
pnpm dev
pnpm typecheck
pnpm build
pnpm preview
```

## 阅读优先级

1. `README.md`
2. `package.json`
3. `nuxt.config.ts`
4. `pages/`、`components/`、`composables/`、`server/api/`

## 排查重点

- 页面渲染问题：优先看 `pages/`、`layouts/`、`components/`
- SEO 问题：优先看 `nuxt.config.ts`、页面 head 配置、`server/api/sitemap*`
- 接口问题：优先看 `composables/` 与 `server/api/`
- 环境变量问题：优先看 `nuxt.config.ts` 和 `.env.example`
