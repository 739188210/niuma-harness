# System / Infra 分页接口规范

## 适用范围

- `shop-trade-service-module-system-server`
- `shop-trade-service-module-infra-server`
- `shop-trade-service-module-system-api`
- `shop-trade-service-ui/src/api/system/**`
- `shop-trade-service-ui/src/api/infra/**`

## 规则

- Controller 分页接口统一使用 `@PostMapping`
- 分页查询对象统一使用 `@RequestBody`
- Feign / RPC 分页接口统一使用 `@PostMapping + @RequestBody`
- 前端分页请求统一使用 `request.post({ url, data: params })`

## 重点

- `OperateLogApi` 这类跨模块分页接口也属于规则范围
- `table/page` 这种分页路径同样按 `POST` 处理

## 检查点

- 如果文件里既有 `/page` 也有 `/get`、`/export-excel`，注意不要删掉 `GetMapping` import
