# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 阅读前置规则

开始阅读当前应用材料前，先读以下规则文件：

- `harness/docs/rules/java/patterns.md`
- 如涉及分页接口，再读 `harness/docs/rules/common/api-page-method.md`

## 项目概述

易运盈内贸管理系统 - 基于 Java 17 + Spring Boot 3.5 + Spring Cloud 2025 的微服务架构。

**核心技术栈**:
- Java 17
- Spring Boot 3.5.9 + Spring Cloud 2025.0.0
- Spring Cloud Gateway (API 网关)
- Nacos (注册中心 + 配置中心)
- MyBatis Plus (持久层)
- Redis + Redisson (缓存与分布式锁)
- MySQL 8.0+

## 常用 Maven 命令

### 构建与编译
```bash
# 清理并编译整个项目
mvn clean compile

# 打包整个项目
mvn clean package

# 打包并跳过测试
mvn clean package -DskipTests

# 仅编译特定模块（例如 system 模块）
mvn clean compile -pl shop-trade-service-module-system -am

# 安装到本地仓库
mvn clean install
```

### 测试
```bash
# 运行所有测试
mvn test

# 运行特定模块的测试
mvn test -pl shop-trade-service-module-system-server

# 运行单个测试类
mvn test -Dtest=YourTestClass

# 运行单个测试方法
mvn test -Dtest=YourTestClass#testMethod
```

### 依赖管理
```bash
# 查看依赖树
mvn dependency:tree

# 分析依赖冲突
mvn dependency:analyze

# 更新版本号（项目使用 revision 统一管理版本）
# 修改根 pom.xml 中的 <revision> 属性
```

## 项目架构

### 模块划分原则

本项目采用**分层微服务架构**，核心分为以下几层：

#### 1. **依赖管理层** (`shop-trade-service-dependencies`)
- Maven BOM (Bill of Materials)，统一管理所有第三方依赖版本
- 所有模块通过 `import` 引入此 BOM

#### 2. **框架层** (`shop-trade-service-framework`)
提供 17 个技术组件 Spring Boot Starter，按职责分类：

**基础设施类**:
- `shop-trade-service-common`: 公共工具类、常量、基础 DTO
- `shop-trade-service-spring-boot-starter-web`: Web 层封装（REST API、Swagger、异常处理）
- `shop-trade-service-spring-boot-starter-security`: 认证与授权（OAuth2、JWT）
- `shop-trade-service-spring-boot-starter-mybatis`: 数据库访问（MyBatis Plus、多数据源）
- `shop-trade-service-spring-boot-starter-redis`: 缓存与分布式锁（Redisson）

**业务能力类**:
- `shop-trade-service-spring-boot-starter-mq`: 消息队列封装
- `shop-trade-service-spring-boot-starter-job`: 定时任务（XXL-Job）
- `shop-trade-service-spring-boot-starter-rpc`: 远程调用（OpenFeign）
- `shop-trade-service-spring-boot-starter-excel`: Excel 导入导出
- `shop-trade-service-spring-boot-starter-websocket`: WebSocket 实时通信

**运维能力类**:
- `shop-trade-service-spring-boot-starter-monitor`: 监控（Admin、Metrics）
- `shop-trade-service-spring-boot-starter-protection`: 限流、幂等、分布式锁
- `shop-trade-service-spring-boot-starter-env`: 环境管理

**业务扩展类**:
- `shop-trade-service-spring-boot-starter-biz-tenant`: 多租户支持
- `shop-trade-service-spring-boot-starter-biz-data-permission`: 数据权限
- `shop-trade-service-spring-boot-starter-biz-ip`: IP 地理定位

#### 3. **网关层** (`shop-trade-service-gateway`)
- Spring Cloud Gateway 实现
- 路由转发、鉴权、限流、日志等

#### 4. **业务模块层** (`shop-trade-service-module-*`)
每个业务模块采用 **API + Server** 双模块结构：

**shop-trade-service-module-system** (系统管理):
- `shop-trade-service-module-system-api`: 对外暴露的接口、DTO（供其他模块 RPC 调用）
- `shop-trade-service-module-system-server`: 实际业务实现（Controller、Service、Mapper）
- 包含：用户管理、角色权限、菜单管理、字典配置、OAuth2 认证等

**shop-trade-service-module-infra** (基础设施):
- `shop-trade-service-module-infra-api`: 基础设施接口
- `shop-trade-service-module-infra-server`: 代码生成器、定时任务管理、文件服务、API 日志等

**未来扩展模块** (当前注释掉):
- `shop-trade-service-module-business`: 主启动服务（聚合所有业务模块）
- `shop-trade-service-module-ai`: AI 大模型
- `shop-trade-service-module-member`: 会员管理
- `shop-trade-service-module-bpm`: 工作流
- `shop-trade-service-module-pay`: 支付
- 其他业务模块...

### 包结构规范

所有代码遵循统一的包命名规范：

```
com.easybiz.shoptrade
├── framework.common                  # 框架层公共代码
│   ├── biz                          # 业务层通用 API
│   │   ├── infra.logger             # 基础设施日志 API
│   │   ├── system.dict              # 系统字典 API
│   │   ├── system.oauth2            # OAuth2 Token API
│   │   └── system.permission        # 权限 API
│   └── core                         # 核心工具类
├── module.system                     # 系统模块
│   ├── api                          # 对外 API（供 RPC 调用）
│   │   ├── dept                     # 部门相关 API
│   │   ├── dict                     # 字典相关 API
│   │   ├── logger                   # 日志相关 API
│   │   ├── permission               # 权限相关 API
│   │   └── ...
│   └── service                      # 内部实现
│       ├── controller               # REST 控制器
│       ├── service                  # 业务逻辑
│       ├── dal.dataobject           # 数据对象 (DO)
│       └── dal.mapper               # MyBatis Mapper
└── module.infra                      # 基础设施模块（同上）
```

### 启动顺序

开发环境启动顺序：
1. **Nacos**: 先启动 Nacos 注册中心（默认 8848 端口）
2. **MySQL**: 确保 MySQL 运行并导入 `sql/` 目录下的初始化脚本
3. **Redis**: 启动 Redis（默认 6379 端口）
4. **shop-trade-service-gateway**: 启动网关服务（运行 `GatewayServerApplication`）
5. **shop-trade-service-module-system-server**: 启动系统管理服务（运行 `SystemServerApplication`）
6. **shop-trade-service-module-infra-server**: 启动基础设施服务（如需要）
7. **shop-trade-service-module-business**: 启动主业务服务（未来）

### 配置文件管理

项目使用 **Nacos 配置中心**，本地配置文件主要用于：
- 指定 Nacos 连接地址
- 本地开发覆盖配置
- 当前激活的 profile（dev/fat/uat/prod）

根据 git 提交记录，当前环境配置：
- 默认激活 profile: `fat` (功能验收测试环境)

### 代码生成与注解处理

项目使用 **Lombok + MapStruct** 组合，注意事项：
- Lombok 生成 getter/setter
- MapStruct 生成实体转换代码（DO ↔ DTO ↔ VO）
- Maven 编译时需要正确配置 `annotationProcessorPaths`（已配置）
- 如遇到 "No property named xxx" 错误，检查 `lombok-mapstruct-binding` 依赖

### API 设计规范

根据代码结构推断的 API 分层：
- **CommonApi**: 跨模块通用接口（在 `shop-trade-service-common` 中定义）
- **模块 API**: 各业务模块对外暴露的 RPC 接口（在 `*-api` 模块中）
- **Controller**: RESTful HTTP 接口（在 `*-server` 模块中）

**DTO 命名规范**:
- `ReqDTO`: 请求参数
- `RespDTO`: 响应结果
- `CreateReqDTO`: 创建请求
- `UpdateReqDTO`: 更新请求
- `PageReqDTO`: 分页查询请求

## 开发注意事项

### Maven 私服配置
项目已配置内网 Nexus 私服（192.168.31.254:20001），如无法访问需注释掉 `distributionManagement` 配置。

### 环境变量与 Profile
- 本地开发: `local`
- 开发环境: `dev`
- 测试环境: `fat` (当前默认)
- 生产环境: `prod`

修改激活 profile: 在各服务的 `application.yml` 中修改 `spring.profiles.active`

### 数据库脚本
- 初始化脚本位于 `sql/` 目录
- 使用 MyBatis Plus，支持自动建表（需配置）
- 多租户场景下注意数据隔离

### Git 分支规范
当前分支: `fat`
主分支: `main`

根据 git 提交记录，团队使用中文提交信息：
```
feat(模块): 功能描述
fix(模块): 修复描述
chore(模块): 配置或杂项修改
```
