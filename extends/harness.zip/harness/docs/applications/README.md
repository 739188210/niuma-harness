# 应用材料归档

本目录集中存放从各 shop 子项目迁入的非 README Markdown 材料。

原子项目目录下的 `README.md` 已按要求保留原位，不在这里重复迁移。

## 归档目录

- `shop-trade-service-system/`：系统管理、基础设施、框架入门、MapStruct、监控等材料。
- `shop-trade-service-business/`：业务模块规则、项目总览、AI 知识检索设计与修复报告、测试说明等材料。
- `shop-trade-service-ai/`：AI 服务规则、项目总览、Nacos 配置、数据库、接口说明等材料。
- `shop-trade-service-material/`：素材库独立应用规则、边界、运行方式与接口设计材料。
- `shop-trade-service-ui/`：管理后台前端协作规则。
- `shop-trade-service-portal/`：Nuxt 3 前台门户应用规则、边界、运行方式与协议说明。

## 阅读规则

- 具体任务先读对应应用下的 `CLAUDE.md`。
- 原子项目下的 `README.md`、`pom.xml`、`package.json` 仍作为代码侧事实入口。
- 如果归档材料和当前代码冲突，以当前代码和构建配置为准，再同步修正文档。
