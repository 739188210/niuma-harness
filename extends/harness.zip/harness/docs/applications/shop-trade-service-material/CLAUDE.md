# shop-trade-service-material

## 阅读前置规则

开始阅读当前应用材料前，先读以下规则文件：

- `harness/docs/rules/java/patterns.md`
- 如涉及分页接口，再读 `harness/docs/rules/common/api-page-method.md`

## 应用定位

- `shop-trade-service-material` 是 `shop-trade` 下独立的素材库应用
- 负责素材分类、素材主档、素材引用、素材选择器等全站通用能力
- 它与 `shop-trade-service-business`、`shop-trade-service-ai`、`shop-trade-service-system` 平级

## 模块边界

- `shop-trade-service-module-material-api`：跨服务共享的常量、枚举、DTO、RPC 接口
- `shop-trade-service-module-material-server`：Spring Boot 启动模块与业务实现模块
- 素材库服务可以依赖 `infra-api`、`system-api`
- **禁止反向依赖 `business` 模块实现包**

## 启动与配置

- 启动类：`shop-trade-service-module-material-server/src/main/java/com/easybiz/shoptrade/module/material/MaterialServerApplication.java`
- 默认本地端口：`58086`
- 默认 profile：`local`

## 常用命令

```bash
# 在 shop-trade-service-material 根目录执行
mvn clean compile
mvn clean package -DskipTests
mvn -pl shop-trade-service-module-material-server -am spring-boot:run
```

## 数据与命名

- 表前缀统一：`shop_material_*`
- 包路径统一：`com.easybiz.shoptrade.module.material`
- 接口前缀统一：`/admin-api/material*`
