# AI 接口埋点日志表建表脚本

## 表结构

```sql
CREATE TABLE ai_trace_log (
    id BIGINT AUTO_INCREMENT COMMENT '日志ID',
    tenant_id BIGINT NOT NULL DEFAULT 0 COMMENT '租户ID',

    -- 请求信息
    request_path VARCHAR(500) NOT NULL COMMENT '请求路径',
    request_method VARCHAR(10) NOT NULL COMMENT 'HTTP方法(GET/POST/PUT/DELETE等)',
    request_headers JSON COMMENT '请求头(JSON格式)',
    request_cookies JSON COMMENT 'Cookie(JSON数组格式)',
    request_body TEXT COMMENT '请求体内容',

    -- 用户信息
    user_id BIGINT COMMENT '用户ID',
    username VARCHAR(64) COMMENT '用户名',
    dept_id BIGINT COMMENT '部门ID',
    dept_name VARCHAR(100) COMMENT '部门名称',

    -- 响应信息
    response_status INT COMMENT '响应状态码',
    response_body TEXT COMMENT '响应体内容（可选）',
    response_size BIGINT COMMENT '响应大小（字节）',
    request_size BIGINT COMMENT '请求大小（字节）',

    -- 性能指标
    duration BIGINT COMMENT '请求响应时间（毫秒）',

    -- 其他信息
    client_ip VARCHAR(50) COMMENT '客户端IP',
    user_agent VARCHAR(500) COMMENT 'User-Agent',
    exception_message TEXT COMMENT '异常信息（如果有）',

    -- 审计字段（继承 BaseDO）
    creator VARCHAR(64) COMMENT '创建人',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updater VARCHAR(64) COMMENT '更新人',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    deleted BIT NOT NULL DEFAULT 0 COMMENT '是否删除',

    PRIMARY KEY (id),
    INDEX idx_user_id (user_id),
    INDEX idx_request_path (request_path),
    INDEX idx_create_time (create_time),
    INDEX idx_tenant_id (tenant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI接口埋点日志';
```

## 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| request_headers | JSON | 存储格式：`{"Content-Type":"application/json","Authorization":"Bearer xxx"}` |
| request_cookies | JSON | 存储格式：`[{"name":"session","value":"xxx"},{"name":"token","value":"yyy"}]` |
| request_size | BIGINT | 通过 `Content-Length` 或实际计算请求体字节得到 |
| response_size | BIGINT | 通过响应 `Content-Length` 或实际计算响应体字节得到 |
| duration | BIGINT | `afterCompletion` 时间 - `preHandle` 时间 |

## 索引说明

- `idx_user_id`：用于按用户查询日志
- `idx_request_path`：用于按接口路径查询日志
- `idx_create_time`：用于按时间范围查询日志
- `idx_tenant_id`：用于多租户场景下的查询
