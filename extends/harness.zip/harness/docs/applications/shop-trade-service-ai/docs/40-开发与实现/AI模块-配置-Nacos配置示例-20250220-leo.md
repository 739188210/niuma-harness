# AI 接口埋点日志 - Nacos 配置

## 配置文件

在 Nacos 配置中心创建或更新 `shop-trade-service-module-ai-server.yaml` 配置文件：

```yaml
ai:
  log:
    intercept:
      # 是否启用日志记录
      enabled: true

      # 是否记录请求体（可能包含敏感信息，建议默认关闭）
      log-request-body: false

      # 是否记录响应体（可能包含大量数据，建议默认关闭）
      log-response-body: false

      # 需要拦截的路径配置列表
      paths:
        # AI 对话管理
        - path: /admin-api/ai/chat/**
          methods: GET,POST,PUT,DELETE

        # AI 模型管理
        - path: /admin-api/ai/model/**
          methods: GET,POST,PUT,DELETE

        # AI 知识库管理
        - path: /admin-api/ai/knowledge/**
          methods: GET,POST,PUT,DELETE

        # AI 图像生成
        - path: /admin-api/ai/image/**
          methods: GET,POST,PUT,DELETE

        # AI 工作流
        - path: /admin-api/ai/workflow/**
          methods: GET,POST,PUT,DELETE

        # AI 思维导图
        - path: /admin-api/ai/mindmap/**
          methods: GET,POST,PUT,DELETE

        # AI 音乐生成
        - path: /admin-api/ai/music/**
          methods: GET,POST,PUT,DELETE

        # AI 写作
        - path: /admin-api/ai/write/**
          methods: GET,POST,PUT,DELETE

        # AI 工具管理
        - path: /admin-api/ai/tool/**
          methods: GET,POST,PUT,DELETE
```

## 配置说明

### enabled
- **类型**：Boolean
- **默认值**：true
- **说明**：总开关，关闭后不记录任何日志

### log-request-body
- **类型**：Boolean
- **默认值**：false
- **说明**：是否记录请求体内容
  - 可能包含敏感信息（密码、Token 等）
  - 可能包含大量数据（文件上传等）
  - 建议仅在调试时开启，生产环境默认关闭

### log-response-body
- **类型**：Boolean
- **默认值**：false
- **说明**：是否记录响应体内容
  - 可能包含大量数据（如大模型返回的长文本）
  - 可能影响性能
  - 建议仅在调试时开启，生产环境默认关闭

### paths
- **类型**：List<PathConfig>
- **说明**：需要拦截的路径配置列表

#### PathConfig.path
- **类型**：String
- **说明**：路径模式，支持 Ant 风格通配符
  - `/**`：匹配所有路径
  - `/*`：匹配单级路径
  - `/xxx/**`：匹配多级路径
  - `/xxx/*`：匹配单级路径

#### PathConfig.methods
- **类型**：Set<String>
- **说明**：HTTP 方法列表
  - 可选值：GET、POST、PUT、DELETE、PATCH 等
  - 如果不指定，则拦截所有 HTTP 方法

## 配置示例

### 示例 1：仅拦截 GET 请求
```yaml
ai:
  log:
    intercept:
      enabled: true
      paths:
        - path: /admin-api/ai/chat/**
          methods: GET
```

### 示例 2：拦截所有方法
```yaml
ai:
  log:
    intercept:
      enabled: true
      paths:
        - path: /admin-api/ai/chat/**
          # 不指定 methods，则拦截所有方法
```

### 示例 3：禁用日志记录
```yaml
ai:
  log:
    intercept:
      enabled: false
```

### 示例 4：启用请求/响应体记录（调试用）
```yaml
ai:
  log:
    intercept:
      enabled: true
      log-request-body: true
      log-response-body: true
      paths:
        - path: /admin-api/ai/chat/**
          methods: POST
```

## 动态刷新

本配置支持 Nacos 动态刷新（通过 `@RefreshScope` 实现）：

1. 修改 Nacos 配置后，无需重启应用
2. 配置会自动刷新到内存
3. 下次请求会立即生效

### 验证动态刷新

1. 修改 `enabled` 为 `false`
2. 调用接口，检查数据库是否还有新日志
3. 修改 `enabled` 为 `true`
4. 调用接口，检查数据库是否重新记录日志

## 注意事项

1. **性能影响**：
   - 日志记录采用异步方式，不会阻塞主线程
   - 但仍会占用一定资源（数据库连接、线程池等）
   - 高并发场景下建议关闭不必要的日志记录

2. **存储空间**：
   - 日志表会持续增长，建议定期清理历史数据
   - 可添加定时任务，定期清理（如保留 90 天）

3. **敏感信息**：
   - 请求头中可能包含 `Authorization`、`Token` 等敏感信息
   - 如需脱敏，需在 `AiTraceLogServiceImpl` 中添加脱敏逻辑

4. **大文件上传**：
   - 文件上传接口不应记录请求体
   - 建议在配置中排除文件上传接口
