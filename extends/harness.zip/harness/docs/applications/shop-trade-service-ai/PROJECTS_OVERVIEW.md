# 项目架构说明文档

## 概述

本项目由三个独立的 Maven 项目组成，都是从开源项目（基于 RuoYi-Vue-Pro）改造而来的微服务架构系统。

```
D:\code\
├── domestic-trade-system/     # 基础框架项目（底层依赖）
├── shop-trade-service-ai/        # AI 大模型服务（独立服务）
└── domestic-trade-business/  # 业务聚合服务（主入口）
```

---

## 一、为什么拆成三个项目？

### 拆分原因

1. **关注点分离**：将不同职责的代码分离到不同项目中
2. **独立部署**：AI 服务可以独立部署和扩展
3. **依赖管理**：system 项目作为公共基础库，被其他项目依赖
4. **团队协作**：不同团队可以独立开发不同的模块

### 三种角色的定位

| 项目 | 角色 | 说明 |
|------|------|------|
| **domestic-trade-system** | 基础设施提供者 | 提供所有技术组件、系统管理、基础设施功能 |
| **shop-trade-service-ai** | AI 能力提供者 | 提供独立的 AI 大模型服务 |
| **domestic-trade-business** | 业务聚合容器 | 聚合所有业务模块，统一对外提供服务 |

---

## 二、各项目详细说明

### 1. domestic-trade-system（基础框架项目）

**路径**：`D:\Project\shop-trade\shop-trade-service-system`

**功能定位**：微服务架构的基础框架，提供系统管理和基础设施能力

**主要模块**：

| 模块 | 说明 | 端口 |
|------|------|------|
| domestic-dependencies | Maven 依赖版本管理（BOM） | - |
| domestic-framework | 技术组件库（17 个 Spring Boot Starter） | - |
| domestic-gateway | API 网关服务（Spring Cloud Gateway） | 48080 |
| domestic-module-system | 系统管理模块（用户、角色、权限、字典等） | 48081 |
| domestic-module-infra | 基础设施模块（代码生成、定时任务、文件服务等） | 48082 |

**启动类**：
- `GatewayServerApplication` - 网关服务
- `SystemServerApplication` - 系统管理服务
- `InfraServerApplication` - 基础设施服务

**特点**：
- 本身可以独立运行多个微服务
- 被 business 项目通过 Maven 依赖引用
- 提供所有项目共用的基础组件

---

### 2. shop-trade-service-ai（AI 大模型服务）

**路径**：`D:\Project\shop-trade\shop-trade-service-ai`

**功能定位**：独立的 AI 大模型服务，提供各种 AI 能力

**主要功能**：
- AI 对话（支持多模型）
- AI 绘图（文生图）
- AI 写作（辅助内容创作）
- AI 思维导图
- AI 音乐生成

**已对接模型**：
- 国内：通义千问、文心一言、讯飞星火、智谱 GLM、DeepSeek、字节豆包、腾讯混元、硅基流动
- 国外：OpenAI、Azure OpenAI、Anthropic Claude、Ollama、Midjourney、Stable Diffusion、Suno

**服务端口**：48090

**启动类**：`AiServerApplication`

**特点**：
- 完全独立部署
- 通过 Feign 调用 system 项目的 API（如文件上传、用户信息）
- 不依赖 business 项目

---

### 3. domestic-trade-business（业务聚合服务）

**路径**：`D:\Project\shop-trade\shop-trade-service-business`

**功能定位**：业务聚合容器，统一启动所有业务模块

**服务端口**：48085

**启动类**：`DomesticServerApplication`

**当前聚合的模块**：
- domestic-module-system-server（系统管理）
- domestic-module-infra-server（基础设施）
- shop-trade-service-module-ai-api（AI 模块 API，但未包含 AI 服务）

**pom.xml 中已注释的模块**（可选启用）：
- shop-trade-service-module-ai-server（AI 服务 - 已注释，需要单独部署）
- domestic-module-member-server（会员中心）
- domestic-module-report-server（数据报表）
- domestic-module-bpm-server（工作流）
- domestic-module-pay-server（支付服务）
- domestic-module-mp-server（微信公众号）
- domestic-module-product-server（商品管理）
- domestic-module-promotion-server（营销促销）
- domestic-module-trade-server（交易）
- domestic-module-statistics-server（统计）
- domestic-module-crm-server（CRM）
- domestic-module-erp-server（ERP）
- domestic-module-iot-server（物联网）

**特点**：
- 本身是空壳容器，不包含业务逻辑
- 通过 Maven 依赖引入各业务模块
- 统一对外提供 RESTful API

---

## 三、项目间依赖关系

### Maven 依赖关系

```
┌─────────────────────────────────────────────────────────────────┐
│                    依赖关系图                                     │
│                                                                  │
│  domestic-trade-business (2.0.0-SNAPSHOT)                       │
│       │                                                         │
│       ├── 依赖 domestic-trade-system (1.0.0-SNAPSHOT)           │
│       │    ├── domestic-dependencies (BOM)                     │
│       │    ├── domestic-framework (技术组件)                    │
│       │    ├── domestic-module-system-server                   │
│       │    └── domestic-module-infra-server                     │
│       │                                                         │
│       └── 依赖 shop-trade-service-ai (2.0.0-SNAPSHOT)              │
│            └── shop-trade-service-module-ai-api (仅API，不含服务)         │
│                                                                  │
│  shop-trade-service-ai (2.0.0-SNAPSHOT)                            │
│       │                                                         │
│       └── 依赖 domestic-trade-system (1.0.0-SNAPSHOT)         │
│            ├── domestic-module-system-api                      │
│            └── domestic-module-infra-api                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### RPC 调用关系

```
┌─────────────────────────────────────────────────────────────────┐
│                    RPC 调用关系                                   │
│                                                                  │
│  ┌─────────────────┐         Feign         ┌─────────────────┐  │
│  │   AI Service   │ ─────────────────────▶ │  System API     │  │
│  │   (独立部署)     │   文件上传、用户信息    │  (通过system)   │  │
│  └─────────────────┘                      └─────────────────┘  │
│                                                                  │
│  ┌─────────────────┐         Feign         ┌─────────────────┐  │
│  │  Business Srv  │ ─────────────────────▶ │  System API     │  │
│  │  (聚合容器)      │   系统管理、基础设施     │  (通过system)   │  │
│  └─────────────────┘                      └─────────────────┘  │
│                                                                  │
│  ┌─────────────────┐         Feign         ┌─────────────────┐  │
│  │  Business Srv  │ ─────────────────────▶ │    AI API       │  │
│  │  (聚合容器)      │   AI能力调用（可选）     │  (通过ai)       │  │
│  └─────────────────┘                      └─────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Nacos 服务注册

| 服务名 | 来源项目 | 端口 |
|--------|----------|------|
| domestic-gateway | domestic-trade-system | 48080 |
| domestic-module-system-server | domestic-trade-system | 48081 |
| domestic-module-infra-server | domestic-trade-system | 48082 |
| domestic-module-business-server | domestic-trade-business | 48085 |
| shop-trade-service-module-ai-server | shop-trade-service-ai | 48090 |

---

## 四、启动顺序和依赖

### 基础设施（必须先启动）

| 组件 | 说明 | 本地地址 |
|------|------|----------|
| Nacos | 注册中心 + 配置中心 | 127.0.0.1:8848 |
| MySQL | 数据库 | 192.168.31.251:3306 |
| Redis | 缓存 | 192.168.31.252:6379 |
| XXL-Job | 定时任务（可选） | http://192.168.31.253:19090/qlJob |

### 服务启动顺序

```
启动顺序（推荐）：

1. domestic-gateway          (网关服务)
2. domestic-module-system-server   (系统管理服务)
3. domestic-module-infra-server    (基础设施服务)
4. shop-trade-service-module-ai-server        (AI 服务，可选)
5. domestic-module-business-server  (业务聚合服务，最后启动)
```

### 启动依赖说明

| 服务 | 前置依赖 | 说明 |
|------|----------|------|
| domestic-gateway | Nacos | 需要注册中心 |
| domestic-module-system-server | Nacos, MySQL, Redis | 需要完整的基础设施 |
| domestic-module-infra-server | Nacos, MySQL, Redis | 需要完整的基础设施 |
| shop-trade-service-module-ai-server | Nacos, MySQL, Redis, **system 服务** | 通过 Feign 调用 system 的 API |
| domestic-module-business-server | Nacos, MySQL, Redis | 聚合服务，依赖其他服务 |

**重要**：
- `shop-trade-service-module-ai-server` 依赖 `domestic-module-system-server`（文件上传、用户信息）
- `domestic-module-business-server` 不强依赖其他服务（除非启用了需要调用的模块）

---

## 五、启动指南

### 方式一：只启动 business 服务（最简单）

适合：快速开发、测试业务功能

```bash
# 1. 确保 Nacos、MySQL、Redis 已启动

# 2. 启动 business 服务
cd D:\Project\shop-trade\shop-trade-service-business
mvn spring-boot:run

# 或者直接运行主类
# 运行 DomesticServerApplication
```

**说明**：
- business 服务内部聚合了 system 和 infra 模块
- 不需要单独启动 system 项目的服务
- 但需要单独部署 ai 服务才能使用 AI 功能

### 方式二：启动完整的微服务集群

适合：生产环境、需要服务独立扩展

```bash
# 1. 启动基础设施
# - Nacos (127.0.0.1:8848)
# - MySQL (192.168.31.251:3306)
# - Redis (192.168.31.252:6379)

# 2. 启动网关
cd D:\Project\shop-trade\shop-trade-service-system\shop-trade-service-gateway
mvn spring-boot:run

# 3. 启动系统服务
cd D:\Project\shop-trade\shop-trade-service-system\shop-trade-service-module-system\shop-trade-service-module-system-server
mvn spring-boot:run

# 4. 启动基础设施服务
cd D:\Project\shop-trade\shop-trade-service-system\shop-trade-service-module-infra\shop-trade-service-module-infra-server
mvn spring-boot:run

# 5. 启动 AI 服务（可选）
cd D:\Project\shop-trade\shop-trade-service-ai
mvn spring-boot:run

# 6. 启动 business 服务（最后）
cd D:\Project\shop-trade\shop-trade-service-business
mvn spring-boot:run
```

### 方式三：启动 AI 服务（独立）

适合：只需要 AI 能力

```bash
# 1. 确保 Nacos、MySQL、Redis 已启动
# 2. 确保 domestic-module-system-server 已启动（AI 服务需要调用文件 API）

# 3. 启动 AI 服务
cd D:\Project\shop-trade\shop-trade-service-ai
mvn spring-boot:run

# 或者
java -jar shop-trade-service-module-ai-server/target/shop-trade-service-module-ai-server.jar --spring.profiles.active=local
```

**注意**：AI 服务需要调用 system 服务的文件上传 API，所以必须先启动 system 服务

---

## 六、总结

### 如果你只想快速启动项目：

**推荐启动顺序**：
1. Nacos、MySQL、Redis
2. `domestic-module-business-server`

这样就可以使用大部分功能（系统管理、基础设施等）

### 如果需要使用 AI 功能：

**额外启动**：
3. `domestic-module-system-server`（AI 服务依赖它）
4. `shop-trade-service-module-ai-server`

### 服务端口速查

| 服务 | 端口 |
|------|------|
| Gateway | 48080 |
| System | 48081 |
| Infra | 48082 |
| Business | 48085 |
| AI | 48090 |

### 接口文档

| 服务 | Swagger 地址 |
|------|--------------|
| Business | http://localhost:48085/swagger-ui |
| AI | http://localhost:48090/swagger-ui |
