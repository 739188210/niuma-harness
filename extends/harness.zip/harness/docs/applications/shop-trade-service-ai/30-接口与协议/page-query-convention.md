# AI 分页接口规范

## 适用范围

- `shop-trade-service-module-ai-server`
- `shop-trade-service-ui/src/api/ai/**`

## 规则

- AI 模块分页接口统一使用 `@PostMapping("/page")`
- 分页 VO 统一通过 `@RequestBody` 接收
- 前端分页请求统一使用 `request.post({ url, data: params })`

## 覆盖对象

- workflow
- image
- mindmap
- model / tool / api-key / chat-role
- chat conversation / message
- knowledge / knowledge-document / knowledge-segment
- music
- write
- trace
