# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 阅读前置规则

开始阅读当前应用材料前，先读以下规则文件：

- `harness/docs/rules/java/patterns.md`
- 如涉及分页接口，再读 `harness/docs/rules/common/api-page-method.md`

## 项目概述

这是一个 AI 大模型服务模块（shop-trade-service-ai），提供智能化能力的独立部署服务。项目采用 Maven 多模块架构，基于 Spring Boot 3.5.9 和 Java 17 开发。

**核心功能**：
- AI 对话 -- 支持多模型对话交互
- AI 绘图 -- 文生图能力
- AI 写作 -- 辅助内容创作
- AI 思维导图 -- 自动生成思维导图
- AI 知识库 -- 向量存储与检索
- AI 工作流 -- 基于 TinyFlow 的工作流编排

**已集成模型**：
- 国内：通义千问、文心一言、讯飞星火、智谱 GLM、DeepSeek、月之暗面
- 国外：OpenAI、Ollama、Anthropic、Midjourney、Stable Diffusion、Suno

## 模块结构

```
shop-trade-service-ai/
├── shop-trade-service-module-ai-api/          # API 接口定义与 DTO
└── shop-trade-service-module-ai-server/       # 业务实现（Controller、Service、DAO）
    ├── controller/
    │   ├── admin/                   # 管理端接口
    │   └── app/                     # 应用端接口
    ├── service/
    │   ├── chat/                    # 对话服务
    │   ├── image/                   # 图像生成服务
    │   ├── knowledge/               # 知识库服务
    │   ├── mindmap/                 # 思维导图服务
    │   ├── model/                   # 模型管理服务
    │   ├── music/                   # 音乐生成服务
    │   ├── workflow/                # 工作流服务
    │   └── write/                   # 写作服务
    ├── dal/                         # 数据访问层
    ├── framework/                   # 框架层配置
    │   ├── ai/                      # AI 模型配置
    │   ├── rpc/                     # RPC 配置
    │   └── security/                # 安全配置
    ├── job/                         # 定时任务
    │   ├── image/                   # 图像任务
    │   └── music/                   # 音乐任务
    └── tool/                        # AI 工具集成
        ├── function/                # Function Calling
        └── method/                  # 方法调用
```

## 常用命令

### 构建项目
```bash
# 清理并编译（跳过测试）
mvn clean compile -DskipTests

# 完整构建
mvn clean package -DskipTests

# 安装到本地仓库
mvn clean install -DskipTests
```

### 运行服务
```bash
# 方式一：使用 Maven 运行
cd shop-trade-service-module-ai-server
mvn spring-boot:run

# 方式二：运行打包后的 jar
java -jar shop-trade-service-module-ai-server/target/shop-trade-service-module-ai-server.jar

# 指定环境运行（local/fat/dev/prod）
java -jar shop-trade-service-module-ai-server/target/shop-trade-service-module-ai-server.jar --spring.profiles.active=local
```

### 运行测试
```bash
# 运行所有测试
mvn test

# 运行单个测试类
mvn test -Dtest=YourTestClass

# 运行单个测试方法
mvn test -Dtest=YourTestClass#testMethod
```

### 依赖管理
```bash
# 更新依赖
mvn clean install -U

# 查看依赖树
mvn dependency:tree

# 查看有效 POM
mvn help:effective-pom
```

### 发布到私服
```bash
# 发布 SNAPSHOT 版本
mvn clean deploy -DskipTests

# 发布 Release 版本（需修改 pom.xml 版本号）
mvn clean deploy -DskipTests
```

## 架构设计

### 依赖关系
- **Framework 依赖**：项目依赖于 `domestic-dependencies` (版本 1.0.0-SNAPSHOT)，从私服 Nexus 获取
- **模块间依赖**：依赖 `domestic-module-system-api` 和 `domestic-module-infra-api` 提供的基础服务
- **私服地址**：http://192.168.31.254:20001/repository/maven-public/

### 核心技术栈
- **Spring 生态**：Spring Boot 3.5.9、Spring Cloud Alibaba
- **注册中心**：Nacos Discovery
- **配置中心**：Nacos Config
- **AI 框架**：Spring AI 1.1.2、Spring AI Alibaba 1.1.0.0-RC2
- **工作流引擎**：TinyFlow 1.2.6
- **向量数据库**：Qdrant、Redis Vector、Milvus
- **数据库**：MyBatis-Plus
- **定时任务**：XXL-Job
- **对象映射**：MapStruct 1.6.3

### 分层架构
1. **Controller 层**：分为 admin（管理端）和 app（应用端）两个维度
2. **Service 层**：按业务领域拆分（chat/image/knowledge/mindmap/model/music/workflow/write）
3. **DAL 层**：数据访问对象（dataobject）和 Mapper（mysql）
4. **Framework 层**：框架级配置（AI 模型配置、RPC 配置、安全配置）
5. **Job 层**：定时任务（图像生成、音乐生成的异步任务）
6. **Tool 层**：AI Function Calling 工具集

### AI 模型管理
- **多模型支持**：通过 Spring AI 统一接口支持多个 LLM 提供商
- **模型配置**：在 `framework/ai/` 目录下进行各个模型的配置
- **向量存储**：支持 Qdrant、Redis、Milvus 多种向量数据库
- **文档解析**：使用 Tika 进行多格式文档解析

### 注意事项
1. **环境配置**：默认激活 `dev` 环境，可通过 `application.yaml` 修改
2. **向量存储自动配置**：启动类中已排除 Qdrant 和 Milvus 的自动配置，避免配置冲突
3. **WebMVC vs WebFlux**：项目使用 SpringMVC，不使用 WebFlux，因此 MCP 相关依赖需使用 webmvc 版本
4. **依赖冲突**：注意 Spring Cloud Function、日志框架（logback/slf4j）的冲突，已在 pom.xml 中处理
5. **包路径**：主包路径为 `com.easybiz.shoptrade.module.ai`（注意不是 domestic.trade）

### 启动入口
- **主类**：`com.easybiz.shoptrade.module.ai.AiServerApplication`
- **端口配置**：在各环境的 `application-{profile}.yaml` 中配置

## 开发规范

### 代码组织
- Controller 中按管理端（admin）和应用端（app）分离
- Service 按业务领域垂直拆分，避免过度耦合
- 使用 MapStruct 进行 DO/DTO/VO 的对象转换
- 使用 Lombok 简化实体类代码

### 配置管理
- 本地开发使用 `application-local.yaml`
- 测试环境使用 `application-fat.yaml`
- 生产环境配置通过 Nacos Config 管理

### 注解处理器
项目已配置以下注解处理器（按顺序）：
1. `spring-boot-configuration-processor` - 配置元数据生成
2. `lombok` - Lombok 注解处理
3. `lombok-mapstruct-binding` - Lombok 与 MapStruct 绑定
4. `mapstruct-processor` - MapStruct 对象映射生成

## 文档规范

### 文档目录结构

`docs/` 目录采用 **编号 + 中文目录名**，清晰直观、易检索：

```
docs/
  00-项目总览/           # 文档规范、项目简介、目录说明
  10-需求与规划/         # 需求文档、模块规划、路线图
  20-设计与架构/         # 总体架构、数据库设计、模块设计
  30-接口与协议/         # API接口、Feign接口协议
  40-开发与实现/         # 开发规范、实现说明、脚本说明
  50-测试与质量/         # 测试用例、测试报告、修复报告
  60-运维与部署/         # 部署手册、环境说明、监控告警
  80-调研与决策记录/     # 方案调研、架构比较、决策记录
  90-归档与历史/         # 废弃文档、旧版本、历史资料
  _drafts/              # AI草稿/临时文档
  README.md             # 文档总索引页
```

### 文件命名规范

统一格式：`模块-文档类型-主题-YYYYMMDD-姓名.md`

示例：

- `权限模块-设计-多应用权限方案-20251128-张三.md`
- `Gateway-接口说明-路由配置-20251128-张三.md`
- `系统-决策记录-认证框架选型-20251128-张三.md`

### 文档类型词汇

需求说明、用户故事、模块规划、总体设计、详细设计、数据库设计、接口说明、开发规范、测试用例、测试报告、修复报告、部署手册、配置说明、调研报告、决策记录、使用指南

### AI生成文档规则

1. **所有Markdown文档必须放入 `docs/` 的对应分类目录**
2. 分类规则：

| 文档类型           | 目录                      |
| ------------------ | ------------------------- |
| 需求、规划         | `docs/10-需求与规划/`     |
| 设计、架构         | `docs/20-设计与架构/`     |
| 接口说明           | `docs/30-接口与协议/`     |
| 开发规范、实现说明 | `docs/40-开发与实现/`     |
| 测试用例/报告      | `docs/50-测试与质量/`     |
| 部署、运维、监控   | `docs/60-运维与部署/`     |
| 调研、决策         | `docs/80-调研与决策记录/` |
| 废弃/旧文档        | `docs/90-归档与历史/`     |
| 草稿               | `docs/_drafts/`           |

3. 生成文档时必须给出：完整路径、文件名、文档内容
