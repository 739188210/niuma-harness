# 本地开发和排查手册

## 管理后台前端启动

目录：相对 `shop-trade` 根目录为 `shop-trade-service-ui`

```bash
pnpm install
pnpm dev
```

管理后台端口由环境变量和 Vite 配置共同决定，不写死默认值；以实际启动输出为准。

## 前台 Portal 启动

目录：相对 `shop-trade` 根目录为 `shop-trade-service-portal`

```bash
pnpm install
pnpm dev
```

Portal 当前默认开发端口为 `5178`，以 `nuxt.config.ts` 和实际启动输出为准。

## 后端启动顺序

实际依赖内网环境时，先确认：

1. Nacos 可访问。
2. MySQL 可访问且已导入初始化 SQL。
3. Redis 可访问。
4. Maven 私服可访问。
5. `NACOS_GROUP` 已正确设置，且不是 `DEFAULT_GROUP`。

推荐顺序：

1. Gateway
2. System Server
3. Infra Server
4. Material Server
5. Business Server
6. AI Server

## 素材库启动

目录：相对 `shop-trade` 根目录为 `shop-trade-service-material`

```bash
mvn clean compile
mvn -pl shop-trade-service-module-material-server -am spring-boot:run
```

## 常见排查

- Maven 依赖失败：先判断是否无法访问内网 Nexus。
- 服务无法读取配置：检查 Nacos namespace、group、profile。
- 管理后台前端接口 404：检查 `.env.*`、Axios base URL、网关路由和后端服务是否启动。
- Portal 接口或渲染异常：检查 `NUXT_PUBLIC_API_BASE`、`NUXT_API_INTERNAL_BASE`、`nuxt.config.ts` 和后端聚合接口。
- 菜单不显示：检查 `system_menu`、角色菜单权限、前端动态路由映射和浏览器缓存。
