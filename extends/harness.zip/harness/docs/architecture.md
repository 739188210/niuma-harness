# 架构说明

`shop-trade` 是易运盈内贸管理系统，当前以多项目并列方式组织。

## 顶层结构

```text
shop-trade/
  harness/                     # AI 协作文档骨架
  shop-trade-service-system/   # 系统、基础设施、网关、框架、初始化 SQL
  shop-trade-service-business/ # 业务模块
  shop-trade-service-ai/       # AI 大模型服务
  shop-trade-service-ui/       # 管理后台前端
  shop-trade-service-material/ # 独立素材库应用
  shop-trade-service-portal/   # Nuxt 3 前台门户应用
```

## 后端结构

后端使用 Java 17、Spring Boot 3.5.9、Spring Cloud 2025、MyBatis-Plus、Nacos、Redis、MySQL。

常见模块模式：

```text
*-api      # 对外 API、DTO、枚举、常量
*-server   # Controller、Service、DAL、配置、启动类
```

`shop-trade-service-system` 还包含：

- `shop-trade-service-dependencies`：BOM 和依赖版本管理。
- `shop-trade-service-framework`：公共 starter 和框架能力。
- `shop-trade-service-gateway`：网关服务。
- `shop-trade-service-module-system`：用户、角色、权限、菜单、租户等系统管理。
- `shop-trade-service-module-infra`：基础设施能力。

`shop-trade-service-business` 是业务主服务，强约束已归档到 `applications/shop-trade-service-business/CLAUDE.md`，尤其是数据库、DO、数据权限、SQL 变更和文档规范。

`shop-trade-service-ai` 是独立 AI 服务，包含 chat、image、knowledge、workflow、write 等领域。

`shop-trade-service-material` 是独立素材库服务，负责素材分类、素材主档、素材引用和素材选择器等通用能力。

## 前端结构

### 管理后台前端

`shop-trade-service-ui` 是 Vue 3 + Vite + TypeScript + Element Plus + Pinia + Vue Router 的管理后台。

核心模式是“后端驱动菜单 + 前端运行时生成路由”：

- 登录后拉取用户、角色、菜单
- `src/permission.ts` 控制权限入口
- `src/store/modules/permission.ts` 生成动态路由
- `src/utils/routerHelper.ts` 将后端菜单映射到 `src/views/**`

菜单、权限、路由问题必须同时检查前端路由映射和后端菜单数据。

### 前台门户

`shop-trade-service-portal` 是 Nuxt 3 SSR 前台应用，负责：

- 首页
- 商品详情
- 分类页
- 搜索页
- 多语言页面
- SEO 相关渲染和聚合接口对接

Portal 不复用管理后台路由体系，阅读和排查时要和 `shop-trade-service-ui` 区分。

## 跨项目注意事项

- `system` 的用户、角色、菜单、部门、岗位等基础数据会影响前端菜单和权限。
- `business` 依赖 system、infra、ai、material 等 API 或服务能力。
- `material` 作为独立应用，对 `business` 和 `ui` 提供素材底座能力。
- `portal` 依赖后端聚合接口与静态发布资源，不走管理后台动态菜单体系。
- 前端请求路径受 `.env.*`、Axios 配置和网关路由共同影响。
- 初始化或清理 SQL 变更要同步考虑前端可见菜单和系统管理页面。
