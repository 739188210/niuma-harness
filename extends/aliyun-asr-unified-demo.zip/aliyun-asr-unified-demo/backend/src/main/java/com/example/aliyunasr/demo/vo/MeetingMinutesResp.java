package com.example.aliyunasr.demo.vo;

import java.util.ArrayList;
import java.util.List;

public class MeetingMinutesResp {

    private List<String> keywords = new ArrayList<>();
    private String overview;
    private List<ChapterItem> chapters = new ArrayList<>();
    private List<SpeakerSummaryItem> speakerSummaries = new ArrayList<>();
    private List<ReviewGroupItem> reviews = new ArrayList<>();
    private String rawMinutesText;

    public List<String> getKeywords() {
        return keywords;
    }

    public void setKeywords(List<String> keywords) {
        this.keywords = keywords;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public List<ChapterItem> getChapters() {
        return chapters;
    }

    public void setChapters(List<ChapterItem> chapters) {
        this.chapters = chapters;
    }

    public List<SpeakerSummaryItem> getSpeakerSummaries() {
        return speakerSummaries;
    }

    public void setSpeakerSummaries(List<SpeakerSummaryItem> speakerSummaries) {
        this.speakerSummaries = speakerSummaries;
    }

    public List<ReviewGroupItem> getReviews() {
        return reviews;
    }

    public void setReviews(List<ReviewGroupItem> reviews) {
        this.reviews = reviews;
    }

    public String getRawMinutesText() {
        return rawMinutesText;
    }

    public void setRawMinutesText(String rawMinutesText) {
        this.rawMinutesText = rawMinutesText;
    }

    public static class ChapterItem {
        private String time;
        private String title;
        private String content;

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }
    }

    public static class SpeakerSummaryItem {
        private String speaker;
        private String summary;

        public String getSpeaker() {
            return speaker;
        }

        public void setSpeaker(String speaker) {
            this.speaker = speaker;
        }

        public String getSummary() {
            return summary;
        }

        public void setSummary(String summary) {
            this.summary = summary;
        }
    }

    public static class ReviewGroupItem {
        private String title;
        private List<String> items = new ArrayList<>();

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<String> getItems() {
            return items;
        }

        public void setItems(List<String> items) {
            this.items = items;
        }
    }
}



