package com.example.aliyunasr.demo.vo;

public class MeetingMinutesGenerateReq {

    private String sourceText;
    private String sourceLanguage;
    private String minutesType;
    private String model;

    public String getSourceText() {
        return sourceText;
    }

    public void setSourceText(String sourceText) {
        this.sourceText = sourceText;
    }

    public String getSourceLanguage() {
        return sourceLanguage;
    }

    public void setSourceLanguage(String sourceLanguage) {
        this.sourceLanguage = sourceLanguage;
    }

    public String getMinutesType() {
        return minutesType;
    }

    public void setMinutesType(String minutesType) {
        this.minutesType = minutesType;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }
}



