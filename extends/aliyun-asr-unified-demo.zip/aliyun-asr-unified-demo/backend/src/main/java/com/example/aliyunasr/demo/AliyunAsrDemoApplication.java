package com.example.aliyunasr.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class AliyunAsrDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AliyunAsrDemoApplication.class, args);
    }
}



