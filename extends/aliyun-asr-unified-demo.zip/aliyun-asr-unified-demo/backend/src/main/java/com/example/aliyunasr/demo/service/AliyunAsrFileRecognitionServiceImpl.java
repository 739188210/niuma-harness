package com.example.aliyunasr.demo.service;

import cn.hutool.core.util.StrUtil;
import com.alibaba.dashscope.audio.asr.transcription.Transcription;
import com.alibaba.dashscope.audio.asr.transcription.TranscriptionParam;
import com.alibaba.dashscope.audio.asr.transcription.TranscriptionQueryParam;
import com.alibaba.dashscope.audio.asr.transcription.TranscriptionResult;
import com.alibaba.dashscope.audio.asr.transcription.TranscriptionTaskResult;
import com.alibaba.dashscope.common.TaskStatus;
import com.example.aliyunasr.demo.config.AliyunAsrDemoProperties;
import com.example.aliyunasr.demo.vo.AliyunAsrDemoRecognizeReq;
import com.example.aliyunasr.demo.vo.AliyunAsrDemoResp;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Service
public class AliyunAsrFileRecognitionServiceImpl implements AliyunAsrFileRecognitionService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AliyunAsrDemoProperties properties;
    private final FileStorageService fileStorageService;

    public AliyunAsrFileRecognitionServiceImpl(AliyunAsrDemoProperties properties,
                                               FileStorageService fileStorageService) {
        this.properties = properties;
        this.fileStorageService = fileStorageService;
    }

    @Override
    public AliyunAsrDemoResp recognize(MultipartFile file, AliyunAsrDemoRecognizeReq req) {
        validateEnabledAndApiKey();
        validateFile(file);
        long start = System.currentTimeMillis();
        String fileUrl = fileStorageService.saveAndGetPublicUrl(file);
        String model = StrUtil.blankToDefault(req == null ? null : req.getFileModel(), properties.getFileModel());
        String sourceLanguage = StrUtil.blankToDefault(req == null ? null : req.getSourceLanguage(), properties.getSourceLanguage());
        Map<String, Object> result = callTranscription(fileUrl, model);
        return new AliyunAsrDemoResp(
                file.getOriginalFilename(),
                model,
                sourceLanguage,
                extractText(result),
                fileUrl,
                String.valueOf(result.getOrDefault("taskId", "")),
                System.currentTimeMillis() - start
        );
    }

    private Map<String, Object> callTranscription(String fileUrl, String model) {
        Transcription transcription = new Transcription();
        TranscriptionParam.TranscriptionParamBuilder<?, ?> builder = TranscriptionParam.builder()
                .apiKey(properties.resolveApiKey())
                .model(model)
                .fileUrls(List.of(fileUrl));
        if (StrUtil.isNotBlank(properties.getWorkspace())) {
            builder.workspace(properties.getWorkspace());
        }
        TranscriptionResult created = transcription.asyncCall(builder.build());
        TranscriptionResult completed = transcription.wait(TranscriptionQueryParam.builder()
                .apiKey(properties.resolveApiKey())
                .taskId(created.getTaskId())
                .headers(Collections.emptyMap())
                .build());
        if (!TaskStatus.SUCCEEDED.equals(completed.getTaskStatus())) {
            throw new ResponseStatusException(BAD_REQUEST, "阿里云语音识别任务未成功：" + completed.getTaskStatus());
        }
        TranscriptionTaskResult first = completed.getResults() == null || completed.getResults().isEmpty()
                ? null : completed.getResults().get(0);
        if (first == null || StrUtil.isBlank(first.getTranscriptionUrl())) {
            throw new ResponseStatusException(BAD_REQUEST, "阿里云语音识别返回缺少 transcriptionUrl");
        }
        Map<String, Object> result = fetchTranscriptionResult(first.getTranscriptionUrl());
        result.put("taskId", completed.getTaskId());
        return result;
    }

    private Map<String, Object> fetchTranscriptionResult(String transcriptionUrl) {
        String body = restTemplate.getForObject(URI.create(transcriptionUrl), String.class);
        if (StrUtil.isBlank(body)) {
            return Map.of();
        }
        try {
            return objectMapper.readValue(body, new TypeReference<>() {
            });
        } catch (IOException ex) {
            throw new ResponseStatusException(BAD_REQUEST, "解析阿里云识别结果失败：" + ex.getMessage(), ex);
        }
    }

    private String extractText(Map<String, Object> result) {
        Object text = result.get("text");
        if (text != null) {
            return String.valueOf(text);
        }
        Object transcriptionText = result.get("transcriptionText");
        return transcriptionText == null ? "" : String.valueOf(transcriptionText);
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(BAD_REQUEST, "请上传音频文件");
        }
        if (properties.getMaxFileSizeBytes() != null && file.getSize() > properties.getMaxFileSizeBytes()) {
            throw new ResponseStatusException(BAD_REQUEST, "音频文件大小超过限制");
        }
        String ext = extractExtension(file.getOriginalFilename()).toLowerCase(Locale.ROOT);
        if (!properties.getAllowedFormats().contains(ext)) {
            throw new ResponseStatusException(BAD_REQUEST, "暂不支持该音频格式：" + ext);
        }
    }

    private String extractExtension(String fileName) {
        if (StrUtil.isBlank(fileName) || !fileName.contains(".")) {
            return "";
        }
        return fileName.substring(fileName.lastIndexOf('.') + 1);
    }

    private void validateEnabledAndApiKey() {
        if (!properties.isDemoEnabled()) {
            throw new ResponseStatusException(BAD_REQUEST, "阿里云语音识别 Demo 未启用");
        }
        if (StrUtil.isBlank(properties.resolveApiKey())) {
            throw new ResponseStatusException(BAD_REQUEST, "请先配置 DASHSCOPE_API_KEY");
        }
    }
}



