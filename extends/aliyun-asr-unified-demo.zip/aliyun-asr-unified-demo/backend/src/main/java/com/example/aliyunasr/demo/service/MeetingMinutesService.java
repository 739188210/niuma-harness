package com.example.aliyunasr.demo.service;

import com.example.aliyunasr.demo.vo.MeetingMinutesGenerateReq;
import com.example.aliyunasr.demo.vo.MeetingMinutesResp;

public interface MeetingMinutesService {

    MeetingMinutesResp generate(MeetingMinutesGenerateReq req);
}



