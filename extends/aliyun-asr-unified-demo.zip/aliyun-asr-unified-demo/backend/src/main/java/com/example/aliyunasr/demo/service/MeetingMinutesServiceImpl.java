package com.example.aliyunasr.demo.service;

import cn.hutool.core.util.StrUtil;
import com.alibaba.dashscope.aigc.generation.Generation;
import com.alibaba.dashscope.aigc.generation.GenerationOutput;
import com.alibaba.dashscope.aigc.generation.GenerationParam;
import com.alibaba.dashscope.aigc.generation.GenerationResult;
import com.alibaba.dashscope.common.Message;
import com.alibaba.dashscope.common.Role;
import com.example.aliyunasr.demo.config.AliyunAsrDemoProperties;
import com.example.aliyunasr.demo.vo.MeetingMinutesGenerateReq;
import com.example.aliyunasr.demo.vo.MeetingMinutesResp;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Service
public class MeetingMinutesServiceImpl implements MeetingMinutesService {

    private static final Map<String, String> LANGUAGE_NAMES = Map.of(
            "zh", "中文",
            "en", "英文",
            "ja", "日文",
            "ko", "韩文",
            "fr", "法文",
            "de", "德文",
            "es", "西班牙文",
            "ru", "俄文");

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AliyunAsrDemoProperties properties;

    public MeetingMinutesServiceImpl(AliyunAsrDemoProperties properties) {
        this.properties = properties;
    }

    @Override
    public MeetingMinutesResp generate(MeetingMinutesGenerateReq req) {
        validateEnabledAndApiKey();
        String sourceText = StrUtil.trim(req == null ? null : req.getSourceText());
        if (StrUtil.isBlank(sourceText)) {
            throw new ResponseStatusException(BAD_REQUEST, "识别文本不能为空");
        }
        String language = normalizeLanguage(req.getSourceLanguage());
        String model = StrUtil.blankToDefault(req.getModel(), properties.getRealtimeTranslationModel());
        String rawText = StrUtil.trim(callDashScope(buildParam(sourceText, language, req.getMinutesType(), model)));
        MeetingMinutesResp resp = parseMinutes(rawText);
        resp.setRawMinutesText(rawText);
        return resp;
    }

    private GenerationParam buildParam(String sourceText, String sourceLanguage, String minutesType, String model) {
        Message systemMessage = Message.builder()
                .role(Role.SYSTEM.getValue())
                .content("你是专业会议纪要助手。只基于输入内容做结构化提炼，不编造事实。")
                .build();
        Message userMessage = Message.builder()
                .role(Role.USER.getValue())
                .content(buildPrompt(sourceText, sourceLanguage, minutesType))
                .build();
        GenerationParam.GenerationParamBuilder<?, ?> builder = GenerationParam.builder()
                .apiKey(properties.resolveApiKey())
                .model(model)
                .messages(List.of(systemMessage, userMessage))
                .resultFormat(GenerationParam.ResultFormat.MESSAGE)
                .temperature(0.2f)
                .maxTokens(properties.getRealtimeTranslationMaxTokens())
                .headers(Collections.emptyMap());
        if (StrUtil.isNotBlank(properties.getWorkspace())) {
            builder.workspace(properties.getWorkspace());
        }
        return builder.build();
    }

    private String buildPrompt(String sourceText, String sourceLanguage, String minutesType) {
        return """
                请把下面的%s语音识别文本整理成%sAI提炼结果。
                要求：
                1. 只输出 JSON，不要 Markdown 包裹。
                2. 不确定负责人或时间时，不要臆造，可以写“未明确”。
                3. JSON 顶层字段固定为：keywords、overview、chapters、speakerSummaries、reviews。
                4. keywords 必须是字符串数组，提取 3 到 8 个关键词。
                5. overview 是全文概要，使用完整自然段。
                6. chapters 必须是数组，每项字段固定为：time、title、content。time 使用 mm:ss 格式；无法判断时写“未明确”。
                7. speakerSummaries 必须是数组，每项字段固定为：speaker、summary。
                8. reviews 必须是数组，每项字段固定为：title、items。items 必须是字符串数组。

                识别文本：
                %s
                """.formatted(languageName(sourceLanguage), StrUtil.blankToDefault(minutesType, "普通会议"), sourceText);
    }

    private String callDashScope(GenerationParam param) {
        try {
            GenerationResult result = new Generation().call(param);
            return extractText(result);
        } catch (Exception ex) {
            throw new ResponseStatusException(BAD_REQUEST, "阿里云AI提炼调用失败：" + ex.getMessage(), ex);
        }
    }

    private MeetingMinutesResp parseMinutes(String rawText) {
        MeetingMinutesResp fallback = new MeetingMinutesResp();
        fallback.setOverview(rawText);
        if (StrUtil.isBlank(rawText)) {
            return fallback;
        }
        try {
            MeetingMinutesResp parsed = objectMapper.readValue(stripJsonFence(rawText), MeetingMinutesResp.class);
            return parsed == null ? fallback : parsed;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private String extractText(GenerationResult result) {
        if (result == null || result.getOutput() == null) {
            return "";
        }
        GenerationOutput output = result.getOutput();
        if (StrUtil.isNotBlank(output.getText())) {
            return output.getText();
        }
        if (output.getChoices() == null || output.getChoices().isEmpty()) {
            return "";
        }
        Message message = output.getChoices().get(0).getMessage();
        return message == null ? "" : StrUtil.nullToEmpty(message.getContent());
    }

    private String stripJsonFence(String text) {
        String value = StrUtil.trim(text);
        if (value.startsWith("```json")) {
            value = value.substring("```json".length());
        } else if (value.startsWith("```")) {
            value = value.substring("```".length());
        }
        if (value.endsWith("```")) {
            value = value.substring(0, value.length() - "```".length());
        }
        return StrUtil.trim(value);
    }

    private String normalizeLanguage(String language) {
        return StrUtil.blankToDefault(language, properties.getSourceLanguage()).trim().toLowerCase(Locale.ROOT);
    }

    private String languageName(String language) {
        return LANGUAGE_NAMES.getOrDefault(normalizeLanguage(language), StrUtil.blankToDefault(language, "源语言"));
    }

    private void validateEnabledAndApiKey() {
        if (!properties.isDemoEnabled()) {
            throw new ResponseStatusException(BAD_REQUEST, "阿里云语音识别 Demo 未启用");
        }
        if (StrUtil.isBlank(properties.resolveApiKey())) {
            throw new ResponseStatusException(BAD_REQUEST, "请先配置 DASHSCOPE_API_KEY");
        }
    }
}



