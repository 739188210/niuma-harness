package com.example.aliyunasr.demo.service;

import org.springframework.web.multipart.MultipartFile;

public interface FileStorageService {

    /**
     * 保存音频文件，并返回 DashScope 能访问到的 URL。
     */
    String saveAndGetPublicUrl(MultipartFile file);
}



