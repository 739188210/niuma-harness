package com.example.aliyunasr.demo.controller;

import com.example.aliyunasr.demo.service.AliyunAsrFileRecognitionService;
import com.example.aliyunasr.demo.service.MeetingMinutesService;
import com.example.aliyunasr.demo.vo.AliyunAsrDemoRecognizeReq;
import com.example.aliyunasr.demo.vo.AliyunAsrDemoResp;
import com.example.aliyunasr.demo.vo.MeetingMinutesGenerateReq;
import com.example.aliyunasr.demo.vo.MeetingMinutesResp;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/aliyun-asr-demo")
public class AliyunAsrDemoController {

    private final AliyunAsrFileRecognitionService fileRecognitionService;
    private final MeetingMinutesService meetingMinutesService;

    public AliyunAsrDemoController(AliyunAsrFileRecognitionService fileRecognitionService,
                                   MeetingMinutesService meetingMinutesService) {
        this.fileRecognitionService = fileRecognitionService;
        this.meetingMinutesService = meetingMinutesService;
    }

    @PostMapping(value = "/recognize", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public AliyunAsrDemoResp recognize(@RequestParam("file") MultipartFile file,
                                       @ModelAttribute AliyunAsrDemoRecognizeReq req) {
        return fileRecognitionService.recognize(file, req);
    }

    @PostMapping("/minutes/generate")
    public MeetingMinutesResp generateMinutes(@RequestBody MeetingMinutesGenerateReq req) {
        return meetingMinutesService.generate(req);
    }
}



