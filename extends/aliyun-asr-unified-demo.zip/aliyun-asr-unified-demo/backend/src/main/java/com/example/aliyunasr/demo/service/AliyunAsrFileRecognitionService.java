package com.example.aliyunasr.demo.service;

import com.example.aliyunasr.demo.vo.AliyunAsrDemoRecognizeReq;
import com.example.aliyunasr.demo.vo.AliyunAsrDemoResp;
import org.springframework.web.multipart.MultipartFile;

public interface AliyunAsrFileRecognitionService {

    AliyunAsrDemoResp recognize(MultipartFile file, AliyunAsrDemoRecognizeReq req);
}



