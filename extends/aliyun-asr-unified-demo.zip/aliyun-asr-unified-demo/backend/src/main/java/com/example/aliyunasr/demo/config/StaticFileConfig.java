package com.example.aliyunasr.demo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;

@Configuration
public class StaticFileConfig implements WebMvcConfigurer {

    private final AliyunAsrDemoProperties properties;

    public StaticFileConfig(AliyunAsrDemoProperties properties) {
        this.properties = properties;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        Path uploadPath = Path.of(properties.getLocalUploadDir()).toAbsolutePath().normalize();
        registry.addResourceHandler("/files/aliyun-asr-demo/**")
                .addResourceLocations(uploadPath.toUri().toString() + "/");
    }
}



