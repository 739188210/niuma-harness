package com.example.aliyunasr.demo.vo;

public record AliyunAsrDemoResp(
        String fileName,
        String fileModel,
        String sourceLanguage,
        String transcriptionText,
        String fileUrl,
        String taskId,
        Long durationMs
) {
}



