package com.example.aliyunasr.demo.config;

import com.example.aliyunasr.demo.websocket.AliyunAsrDemoWebSocketHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    private final AliyunAsrDemoWebSocketHandler handler;

    public WebSocketConfig(AliyunAsrDemoWebSocketHandler handler) {
        this.handler = handler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(handler, "/api/aliyun-asr-demo/realtime")
                .setAllowedOriginPatterns("*");
    }
}



