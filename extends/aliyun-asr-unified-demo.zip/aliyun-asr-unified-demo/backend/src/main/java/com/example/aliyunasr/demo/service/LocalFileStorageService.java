package com.example.aliyunasr.demo.service;

import cn.hutool.core.util.StrUtil;
import com.example.aliyunasr.demo.config.AliyunAsrDemoProperties;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Service
public class LocalFileStorageService implements FileStorageService {

    private final AliyunAsrDemoProperties properties;

    public LocalFileStorageService(AliyunAsrDemoProperties properties) {
        this.properties = properties;
    }

    @Override
    public String saveAndGetPublicUrl(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(BAD_REQUEST, "请上传音频文件");
        }
        try {
            String originalName = StrUtil.blankToDefault(file.getOriginalFilename(), "audio.bin");
            String safeName = UUID.randomUUID() + "-" + originalName.replace('\\', '_').replace('/', '_');
            Path uploadDir = Path.of(properties.getLocalUploadDir()).toAbsolutePath().normalize();
            Files.createDirectories(uploadDir);
            Files.copy(file.getInputStream(), uploadDir.resolve(safeName));
            return properties.getLocalFileBaseUrl() + "/" + URLEncoder.encode(safeName, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new ResponseStatusException(BAD_REQUEST, "保存音频文件失败：" + ex.getMessage(), ex);
        }
    }
}



