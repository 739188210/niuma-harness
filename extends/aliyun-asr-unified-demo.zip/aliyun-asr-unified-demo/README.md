# 阿里云语音识别统一 Demo

此项目将两个原始 Demo 合并为一个可独立运行、也可拆分接入现有系统的项目：

- 完整能力：音频文件识别、麦克风实时识别、模拟音频、实时翻译、录音回放、AI 会议纪要。
- 独立前端：Vue 3 + Vite + Element Plus，已配置开发代理和 WebSocket 代理。
- 接入资产：`gateway/` 的网关路由示例和 `sql/` 的菜单示例。

## 目录

```text
backend/    Spring Boot 3 / Java 17 服务
frontend/   Vue 3 独立页面
gateway/    Spring Cloud Gateway 路由样例
sql/        菜单 SQL 样例
```

## 启动

1. 设置 DashScope API Key（PowerShell）：

```powershell
$env:DASHSCOPE_API_KEY = '你的 DashScope API Key'
```

2. 分别启动后端与前端：

```powershell
cd backend
mvn spring-boot:run

cd ../frontend
npm install
npm run dev
```

3. 浏览器访问 `http://localhost:5173`。

前端会把 `/api` 和 WebSocket 请求代理到 `http://localhost:18090`。部署时建议使用同域反向代理；跨域时可在 `frontend/.env.production` 中设置 `VITE_API_ORIGIN=https://你的接口域名`，并在网关中放行 CORS 与 WebSocket Upgrade。

## 生产注意事项

- 文件识别要求 DashScope 能访问音频 URL。Demo 的本地文件服务只适合本机联调；生产中请实现 `FileStorageService`，返回 OSS、S3、COS 或 MinIO 的公网/预签名地址。
- 不要把 API Key 写进配置文件或提交到仓库。
- 麦克风需要 HTTPS 或 localhost；普通 HTTP 内网地址无法使用浏览器麦克风。
- 将 `gateway/gateway-route-example.yaml` 合并到网关后，保持 `/api/aliyun-asr-demo/**` 路径不变。
