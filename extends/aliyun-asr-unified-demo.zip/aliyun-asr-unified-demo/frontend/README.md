# Vue3 前端接入说明

本目录提供当前 Demo 的前端代码，依赖：

- Vue 3
- TypeScript
- Element Plus
- Iconify 或项目内 `Icon` 组件
- 项目内 axios 封装 `@/config/axios`
- 项目内消息封装 `useMessage`

如果你的项目没有以下全局组件或工具，需要替换：

| 当前代码 | 替换建议 |
| --- | --- |
| `ContentWrap` | 普通 `div` 或项目自己的卡片容器 |
| `Icon` | Element Plus Icons 或普通文本 |
| `useMessage()` | `ElMessage` |
| `@/config/axios` | 你项目里的 axios 实例 |

WebSocket 地址由页面里 `buildRealtimeWsUrl()` 组装：

```ts
const url = `${baseUrl}/api/aliyun-asr-demo/realtime`
```

如果你的网关前缀不是 `/api`，同步修改：

- `src/api/aliyunAsrDemo.ts`
- `src/views/AliyunAsrDemo.vue`



