<template>
  <AliyunAsrDemo />
</template>

<script setup lang="ts">
import AliyunAsrDemo from './views/AliyunAsrDemo.vue'
</script>
