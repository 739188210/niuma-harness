<template>
  <div class="aliyun-asr-demo">
    <ContentWrap>
      <div class="demo-toolbar">
        <div>
          <div class="toolbar-title">阿里云语音识别 Demo</div>
          <div class="toolbar-subtitle">上传音频使用 paraformer-v2，麦克风实时使用 fun-asr-realtime</div>
        </div>
        <el-segmented v-model="mode" :options="modeOptions" />
      </div>
    </ContentWrap>

    <div v-if="mode === 'file'" class="demo-grid">
      <ContentWrap>
        <el-form :model="form" label-width="104px" class="demo-form">
          <el-form-item label="音频文件">
            <el-upload
              drag
              action="#"
              :auto-upload="false"
              :limit="1"
              :accept="acceptTypes"
              :on-change="handleFileChange"
              :on-remove="handleFileRemove"
              :on-exceed="handleFileExceed"
            >
              <Icon icon="ep:upload-filled" class="upload-icon" />
              <div class="el-upload__text">拖入文件或点击选择</div>
            </el-upload>
          </el-form-item>
          <el-form-item label="文件模型">
            <el-input v-model="form.fileModel" clearable />
          </el-form-item>
          <el-form-item label="源语言">
            <el-select v-model="form.sourceLanguage" class="w-1/1">
              <el-option label="中文" value="zh" />
              <el-option label="英文" value="en" />
              <el-option label="日文" value="ja" />
              <el-option label="韩文" value="ko" />
              <el-option label="法文" value="fr" />
              <el-option label="俄文" value="ru" />
            </el-select>
          </el-form-item>
          <el-form-item class="file-action-form-item">
            <div class="file-actions">
              <el-button type="primary" :loading="loading" @click="handleRecognize">
                <Icon icon="ep:video-play" class="mr-5px" />识别
              </el-button>
              <el-button :disabled="loading" @click="resetFileResult">
                <Icon icon="ep:refresh" class="mr-5px" />清空
              </el-button>
            </div>
          </el-form-item>
        </el-form>
      </ContentWrap>

      <ContentWrap>
        <div v-if="result" class="result-header">
          <div>
            <div class="result-title">{{ result.fileName || selectedFile?.name || '-' }}</div>
            <div class="result-meta">{{ result.fileModel || '-' }}</div>
          </div>
          <el-tag type="success" effect="plain">{{ result.durationMs || 0 }} ms</el-tag>
        </div>

        <el-empty v-if="!result" description="暂无识别结果" />
        <el-tabs v-else v-model="activeTab">
          <el-tab-pane label="识别文本" name="transcription">
            <el-input
              :model-value="result.transcriptionText || ''"
              type="textarea"
              readonly
              :autosize="{ minRows: 10, maxRows: 18 }"
            />
          </el-tab-pane>
          <el-tab-pane label="AI提炼" name="minutes">
            <div class="minutes-actions">
              <el-button
                type="primary"
                :loading="fileMinutesLoading"
                :disabled="!result.transcriptionText"
                @click="handleGenerateFileMinutes"
              >
                <Icon icon="ep:document" class="mr-5px" />生成AI提炼
              </el-button>
            </div>
            <el-empty v-if="!fileMinutesResult" description="暂无AI提炼" />
            <AiMinutesPanel v-else :result="fileMinutesResult" />
          </el-tab-pane>
          <el-tab-pane label="调用信息" name="meta">
            <el-descriptions :column="1" border>
              <el-descriptions-item label="源语言">{{ result.sourceLanguage || '-' }}</el-descriptions-item>
              <el-descriptions-item label="任务编号">{{ result.taskId || '-' }}</el-descriptions-item>
              <el-descriptions-item label="文件地址">{{ result.fileUrl || '-' }}</el-descriptions-item>
            </el-descriptions>
          </el-tab-pane>
        </el-tabs>
      </ContentWrap>
    </div>

    <div v-else class="demo-grid">
      <ContentWrap>
        <el-form :model="streamForm" label-width="104px" class="demo-form">
          <el-form-item label="实时模型">
            <el-input v-model="streamForm.realtimeModel" clearable />
          </el-form-item>
          <el-form-item label="采样率">
            <el-input-number v-model="streamForm.sampleRate" :min="8000" :max="48000" :step="1000" class="w-1/1" />
          </el-form-item>
          <el-form-item label="音频格式">
            <el-input v-model="streamForm.format" clearable />
          </el-form-item>
          <el-form-item label="源语言">
            <el-select v-model="streamForm.sourceLanguage" class="w-1/1">
              <el-option label="中文" value="zh" />
              <el-option label="英文" value="en" />
              <el-option label="日文" value="ja" />
              <el-option label="韩文" value="ko" />
              <el-option label="法文" value="fr" />
              <el-option label="俄文" value="ru" />
            </el-select>
          </el-form-item>
          <el-form-item label="实时翻译">
            <el-switch v-model="streamForm.translationEnabled" />
          </el-form-item>
          <el-form-item label="目标语言">
            <el-select v-model="streamForm.targetLanguage" class="w-1/1" :disabled="!streamForm.translationEnabled">
              <el-option label="英文" value="en" />
              <el-option label="中文" value="zh" />
              <el-option label="日文" value="ja" />
              <el-option label="韩文" value="ko" />
              <el-option label="法文" value="fr" />
              <el-option label="德文" value="de" />
              <el-option label="西班牙文" value="es" />
              <el-option label="俄文" value="ru" />
            </el-select>
          </el-form-item>
          <el-form-item label="翻译模型">
            <el-input v-model="streamForm.translationModel" :disabled="!streamForm.translationEnabled" clearable />
          </el-form-item>
          <el-form-item label="连接状态">
            <div class="stream-status">
              <el-tag :type="streaming ? 'success' : 'info'" effect="plain">
                {{ streaming ? '识别中' : '未开始' }}
              </el-tag>
              <span class="stream-status-text">{{ streamStatusText }}</span>
            </div>
          </el-form-item>
          <el-form-item label="模拟音频">
            <el-upload
              action="#"
              :auto-upload="false"
              :limit="1"
              :accept="acceptTypes"
              :disabled="streaming"
              :on-change="handleSimulationFileChange"
              :on-remove="handleSimulationFileRemove"
              :on-exceed="handleSimulationFileExceed"
              class="simulation-upload"
            >
              <el-button :disabled="streaming">
                <Icon icon="ep:folder-opened" class="mr-5px" />选择
              </el-button>
              <template #tip>
                <div v-if="simulationFile" class="simulation-file-name">{{ simulationFile.name }}</div>
              </template>
            </el-upload>
          </el-form-item>
          <el-form-item class="stream-action-form-item">
            <div class="stream-actions">
              <el-button type="primary" :disabled="streaming" @click="startRealtime">
                <Icon icon="ep:microphone" class="mr-5px" />识别
              </el-button>
              <el-button type="success" plain :disabled="streaming || !simulationFile" @click="startRealtimeSimulation">
                <Icon icon="ep:video-play" class="mr-5px" />模拟
              </el-button>
              <el-button type="danger" plain :disabled="!streaming" @click="stopRealtime">
                <Icon icon="ep:video-pause" class="mr-5px" />停止
              </el-button>
              <el-button :disabled="streaming" @click="resetStreamResult">
                <Icon icon="ep:refresh" class="mr-5px" />清空
              </el-button>
            </div>
          </el-form-item>
        </el-form>
      </ContentWrap>

      <ContentWrap>
        <div class="result-header">
          <div>
            <div class="result-title">麦克风实时结果</div>
            <div class="result-meta">{{ streamForm.realtimeModel }} / {{ streamForm.sampleRate }}Hz PCM</div>
          </div>
          <el-tag :type="streaming ? 'success' : 'info'" effect="plain">
            {{ streaming ? 'Aliyun ASR' : '等待开始' }}
          </el-tag>
        </div>
        <div v-if="recordingAudioUrl" class="recording-player">
          <div class="recording-player__title">
            <Icon icon="ep:headset" class="mr-5px" />原音播放
          </div>
          <audio :src="recordingAudioUrl" controls class="recording-player__audio"></audio>
        </div>

        <el-tabs v-model="streamActiveTab">
          <el-tab-pane label="识别文本" name="transcription">
            <RealtimeSegmentPanel
              title="实时识别"
              :segments="streamRecognitionSegments"
              :partial-text="streamPartialText"
              :partial-time="streamPartialTime"
              empty-description="暂无实时识别内容"
            />
          </el-tab-pane>
          <el-tab-pane label="译文" name="translation">
            <RealtimeSegmentPanel
              title="实时译文"
              :segments="streamTranslationSegments"
              badge-text="译"
              default-speaker="译文"
              empty-description="暂无实时译文内容"
            />
          </el-tab-pane>
          <el-tab-pane label="AI提炼" name="minutes">
            <div class="minutes-actions">
              <el-button
                type="primary"
                :loading="streamMinutesLoading"
                :disabled="streamMinutesGenerateDisabled"
                @click="handleGenerateStreamMinutes"
              >
                <Icon icon="ep:document" class="mr-5px" />生成AI提炼
              </el-button>
            </div>
            <el-empty v-if="!streamMinutesResult" description="暂无AI提炼" />
            <AiMinutesPanel v-else :result="streamMinutesResult" />
          </el-tab-pane>
          <el-tab-pane label="事件" name="events">
            <el-table :data="streamEvents" border>
              <el-table-column label="时间" prop="time" width="150" />
              <el-table-column label="类型" prop="type" width="160" />
              <el-table-column label="内容" prop="text" min-width="260" />
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </ContentWrap>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, onBeforeUnmount, reactive, ref, shallowRef } from 'vue'
import type { UploadProps } from 'element-plus'
import * as AliyunAsrDemoApi from '@/api/aliyunAsrDemo'
import ContentWrap from '@/components/ContentWrap.vue'
import Icon from '@/components/Icon.vue'
import { useMessage } from '@/composables/useMessage'
import AiMinutesPanel from '../components/AiMinutesPanel.vue'
import RealtimeSegmentPanel from '../components/RealtimeSegmentPanel.vue'

defineOptions({ name: 'BusinessAliyunAsrDemo' })

type StreamEvent = {
  time: string
  type: string
  text: string
}

type RealtimeSegment = {
  time: string
  speaker: string
  text: string
}

type AliyunRealtimeEvent = {
  type?: string
  text?: string
  sentenceEnd?: boolean
  sourceText?: string
  sourceLanguage?: string
  targetLanguage?: string
  model?: string
}

const message = useMessage()
const mode = ref<'file' | 'stream'>('file')
const modeOptions = [
  { label: '上传文件', value: 'file' },
  { label: '麦克风实时', value: 'stream' }
]
const acceptTypes = '.wav,.mp3,.m4a,.aac,.opus,.flac,.webm,.mp4,.mpeg,.mpga'
const loading = ref(false)
const selectedFile = ref<File>()
const activeTab = ref('transcription')
const result = ref<AliyunAsrDemoApi.AliyunAsrDemoRespVO>()
const fileMinutesLoading = ref(false)
const fileMinutesResult = ref<AliyunAsrDemoApi.AliyunAsrMeetingMinutesRespVO>()

const form = reactive({
  fileModel: 'paraformer-v2',
  sourceLanguage: 'zh'
})

const streamForm = reactive({
  realtimeModel: 'fun-asr-realtime',
  sampleRate: 16000,
  format: 'pcm',
  sourceLanguage: 'zh',
  translationEnabled: true,
  targetLanguage: 'en',
  translationModel: 'qwen-plus'
})

const handleFileChange: UploadProps['onChange'] = (uploadFile) => {
  selectedFile.value = uploadFile.raw
}

const handleFileRemove: UploadProps['onRemove'] = () => {
  selectedFile.value = undefined
}

const handleFileExceed: UploadProps['onExceed'] = () => {
  message.warning('一次只支持上传一个音频文件')
}

const handleRecognize = async () => {
  if (!selectedFile.value) {
    message.warning('请先选择音频文件')
    return
  }
  loading.value = true
  try {
    result.value = await AliyunAsrDemoApi.recognizeAudioFile({
      file: selectedFile.value,
      fileModel: form.fileModel,
      sourceLanguage: form.sourceLanguage
    })
    fileMinutesResult.value = undefined
    activeTab.value = 'transcription'
  } finally {
    loading.value = false
  }
}

const resetFileResult = () => {
  result.value = undefined
  fileMinutesResult.value = undefined
}

const handleGenerateFileMinutes = async () => {
  const sourceText = result.value?.transcriptionText?.trim()
  if (!sourceText) {
    message.warning('请先完成语音识别')
    return
  }
  fileMinutesLoading.value = true
  try {
    fileMinutesResult.value = await AliyunAsrDemoApi.generateMeetingMinutes({
      sourceText,
      sourceLanguage: result.value?.sourceLanguage || form.sourceLanguage,
      minutesType: '上传音频',
      model: streamForm.translationModel
    })
    activeTab.value = 'minutes'
  } finally {
    fileMinutesLoading.value = false
  }
}

const streamActiveTab = ref('transcription')
const streaming = ref(false)
const streamStatusText = ref('等待开始')
const streamFinalText = ref('')
const streamPartialText = ref('')
const streamPartialTime = ref('')
const streamTranslationText = ref('')
const streamRecognitionSegments = ref<RealtimeSegment[]>([])
const streamTranslationSegments = ref<RealtimeSegment[]>([])
const streamMinutesLoading = ref(false)
const streamMinutesResult = ref<AliyunAsrDemoApi.AliyunAsrMeetingMinutesRespVO>()
const streamEvents = ref<StreamEvent[]>([])
const simulationFile = ref<File>()
const streamStartedAt = ref(Date.now())
const recordingAudioUrl = ref('')
const streamDisplayText = computed(() =>
  [streamFinalText.value, streamPartialText.value].filter(Boolean).join('\n')
)
const streamMinutesSourceText = computed(() =>
  streamForm.translationEnabled ? streamTranslationText.value.trim() : streamDisplayText.value.trim()
)
const streamMinutesSourceLanguage = computed(() =>
  streamForm.translationEnabled ? streamForm.targetLanguage : streamForm.sourceLanguage
)
const streamMinutesGenerateDisabled = computed(() => !streamMinutesSourceText.value)
const wsRef = shallowRef<WebSocket>()
const audioContextRef = shallowRef<AudioContext>()
const mediaStreamRef = shallowRef<MediaStream>()
const processorRef = shallowRef<ScriptProcessorNode>()
const sourceRef = shallowRef<MediaStreamAudioSourceNode>()
const mediaRecorderRef = shallowRef<MediaRecorder>()
const recorderChunks: Blob[] = []
let stopCloseTimer: number | undefined
let simulationSendTimer: number | undefined
let realtimeRunId = 0

const handleSimulationFileChange: UploadProps['onChange'] = (uploadFile) => {
  simulationFile.value = uploadFile.raw
  if (uploadFile.raw) {
    createRecordingAudioUrl(uploadFile.raw)
  }
}

const handleSimulationFileRemove: UploadProps['onRemove'] = () => {
  simulationFile.value = undefined
  clearRecordingAudioUrl()
}

const handleSimulationFileExceed: UploadProps['onExceed'] = () => {
  message.warning('一次只支持选择一个模拟音频')
}

const startRealtime = async () => {
  const runId = nextRealtimeRunId()
  clearStopCloseTimer()
  resetStreamResult()
  streaming.value = true
  streamStatusText.value = '正在请求麦克风权限'
  let pendingMediaStream: MediaStream | undefined
  try {
    pendingMediaStream = await requestMicrophoneStream()
    if (!isCurrentRealtimeRun(runId)) {
      stopMediaStream(pendingMediaStream)
      return
    }
    startAudioRecording(pendingMediaStream)
    streamStatusText.value = '麦克风已授权，正在连接阿里云实时识别'
    const ws = new WebSocket(buildRealtimeWsUrl())
    ws.binaryType = 'arraybuffer'
    wsRef.value = ws
    ws.onopen = async () => {
      if (!isCurrentRealtimeRun(runId)) {
        ws.close()
        return
      }
      try {
        await startMicrophone(ws, pendingMediaStream!)
        pendingMediaStream = undefined
        streamStatusText.value = '已连接，正在监听麦克风'
      } catch (error) {
        streamStatusText.value = '麦克风启动失败'
        message.error(parseMicrophoneError(error))
        stopMediaStream(pendingMediaStream)
        pendingMediaStream = undefined
        ws.close()
      }
    }
    ws.onmessage = (event) => handleRealtimeEvent(JSON.parse(event.data))
    ws.onerror = () => {
      stopMediaStream(pendingMediaStream)
      pendingMediaStream = undefined
      streamStatusText.value = '实时识别连接异常'
      message.error('阿里云实时识别连接异常')
    }
    ws.onclose = () => {
      clearStopCloseTimer()
      stopMediaStream(pendingMediaStream)
      pendingMediaStream = undefined
      stopLocalAudio()
      streaming.value = false
      streamStatusText.value = '连接已关闭'
      wsRef.value = undefined
    }
  } catch (error) {
    stopRealtime()
    streamStatusText.value = '启动失败'
    message.error(parseMicrophoneError(error))
    console.error(error)
  }
}

const startRealtimeSimulation = async () => {
  if (!simulationFile.value) {
    message.warning('请先选择模拟音频')
    return
  }
  const runId = nextRealtimeRunId()
  clearStopCloseTimer()
  stopSimulationPlayback()
  resetStreamResult()
  streaming.value = true
  streamStatusText.value = '正在解析模拟音频'
  try {
    const pcmBuffer = await decodeSimulationAudio(simulationFile.value)
    if (!isCurrentRealtimeRun(runId)) {
      return
    }
    createRecordingAudioUrl(simulationFile.value)
    streamStatusText.value = '模拟音频已解析，正在连接阿里云实时识别'
    const ws = new WebSocket(buildRealtimeWsUrl())
    ws.binaryType = 'arraybuffer'
    wsRef.value = ws
    ws.onopen = () => {
      if (!isCurrentRealtimeRun(runId)) {
        ws.close()
        return
      }
      streamStatusText.value = '正在发送模拟音频'
      sendPcmBufferAsRealtime(ws, pcmBuffer)
    }
    ws.onmessage = (event) => handleRealtimeEvent(JSON.parse(event.data))
    ws.onerror = () => {
      stopSimulationPlayback()
      streamStatusText.value = '实时识别连接异常'
      message.error('阿里云实时识别连接异常')
    }
    ws.onclose = () => {
      clearStopCloseTimer()
      stopSimulationPlayback()
      streaming.value = false
      streamStatusText.value = '连接已关闭'
      wsRef.value = undefined
    }
  } catch (error) {
    stopRealtime()
    streamStatusText.value = '模拟启动失败'
    message.error(error instanceof Error ? error.message : '模拟音频启动失败')
    console.error(error)
  }
}

const stopRealtime = () => {
  nextRealtimeRunId()
  stopSimulationPlayback()
  if (wsRef.value?.readyState === WebSocket.OPEN) {
    wsRef.value.send('stop')
    streamStatusText.value = '正在停止'
    stopCloseTimer = window.setTimeout(() => {
      wsRef.value?.close()
    }, 1500)
  } else {
    wsRef.value?.close()
  }
  stopLocalAudio()
  streaming.value = false
}

const resetStreamResult = () => {
  streamStartedAt.value = Date.now()
  stopAudioRecording()
  clearRecordingAudioUrl()
  streamFinalText.value = ''
  streamPartialText.value = ''
  streamPartialTime.value = ''
  streamTranslationText.value = ''
  streamRecognitionSegments.value = []
  streamTranslationSegments.value = []
  streamMinutesResult.value = undefined
  streamEvents.value = []
  streamActiveTab.value = 'transcription'
}

const handleGenerateStreamMinutes = async () => {
  const sourceText = streamMinutesSourceText.value
  if (!sourceText) {
    message.warning(streamForm.translationEnabled ? '请先等待实时译文生成' : '请先完成语音识别')
    return
  }
  streamMinutesLoading.value = true
  try {
    streamMinutesResult.value = await AliyunAsrDemoApi.generateMeetingMinutes({
      sourceText,
      sourceLanguage: streamMinutesSourceLanguage.value,
      minutesType: streamForm.translationEnabled ? '实时语音译文' : '实时语音',
      model: streamForm.translationModel
    })
    streamActiveTab.value = 'minutes'
  } finally {
    streamMinutesLoading.value = false
  }
}

const buildRealtimeWsUrl = () => {
  const apiOrigin = import.meta.env.VITE_API_ORIGIN || window.location.origin
  const url = `${apiOrigin}/api/aliyun-asr-demo/realtime`
  const wsUrl = url.replace(/^http/i, 'ws')
  const params = new URLSearchParams({
    model: streamForm.realtimeModel,
    sampleRate: String(streamForm.sampleRate),
    format: streamForm.format,
    sourceLanguage: streamForm.sourceLanguage,
    translationEnabled: String(streamForm.translationEnabled),
    targetLanguage: streamForm.targetLanguage,
    translationModel: streamForm.translationModel
  })
  return `${wsUrl}?${params.toString()}`
}

const requestMicrophoneStream = async () => {
  if (!window.isSecureContext && !['localhost', '127.0.0.1'].includes(window.location.hostname)) {
    throw new Error('浏览器只允许 HTTPS 或 localhost 页面使用麦克风，请改用 localhost 访问或配置 HTTPS')
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error('当前浏览器不支持麦克风采集，请使用新版 Chrome 或 Edge')
  }
  return await navigator.mediaDevices.getUserMedia({
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true
    }
  })
}

const startMicrophone = async (ws: WebSocket, mediaStream: MediaStream) => {
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext
  const audioContext = new AudioContextClass()
  if (audioContext.state === 'suspended') {
    await audioContext.resume()
  }
  const source = audioContext.createMediaStreamSource(mediaStream)
  const processor = audioContext.createScriptProcessor(4096, 1, 1)
  processor.onaudioprocess = (event) => {
    if (ws.readyState !== WebSocket.OPEN) {
      return
    }
    const input = event.inputBuffer.getChannelData(0)
    const pcm = toPcm16(input, audioContext.sampleRate, streamForm.sampleRate)
    if (pcm.byteLength > 0) {
      ws.send(pcm)
    }
  }
  source.connect(processor)
  processor.connect(audioContext.destination)
  audioContextRef.value = audioContext
  mediaStreamRef.value = mediaStream
  processorRef.value = processor
  sourceRef.value = source
}

const startAudioRecording = (mediaStream: MediaStream) => {
  if (!window.MediaRecorder) {
    message.warning('当前浏览器不支持原音录制播放')
    return
  }
  stopAudioRecording()
  recorderChunks.length = 0
  const recorderOptions = resolveMediaRecorderOptions()
  const recorder = recorderOptions ? new MediaRecorder(mediaStream, recorderOptions) : new MediaRecorder(mediaStream)
  recorder.ondataavailable = (event) => {
    if (event.data?.size > 0) {
      recorderChunks.push(event.data)
    }
  }
  recorder.onstop = () => {
    if (!recorderChunks.length) {
      return
    }
    const blob = new Blob(recorderChunks, { type: recorder.mimeType || 'audio/webm' })
    createRecordingAudioUrl(blob)
    recorderChunks.length = 0
  }
  recorder.start(1000)
  mediaRecorderRef.value = recorder
}

const resolveMediaRecorderOptions = () => {
  const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus']
  const mimeType = candidates.find((type) => MediaRecorder.isTypeSupported(type))
  return mimeType ? { mimeType } : undefined
}

const stopAudioRecording = () => {
  const recorder = mediaRecorderRef.value
  if (recorder && recorder.state !== 'inactive') {
    recorder.stop()
  }
  mediaRecorderRef.value = undefined
}

const createRecordingAudioUrl = (source: Blob | File) => {
  clearRecordingAudioUrl()
  recordingAudioUrl.value = URL.createObjectURL(source)
}

const clearRecordingAudioUrl = () => {
  if (!recordingAudioUrl.value) {
    return
  }
  URL.revokeObjectURL(recordingAudioUrl.value)
  recordingAudioUrl.value = ''
}

const parseMicrophoneError = (error: unknown) => {
  const name = error instanceof DOMException ? error.name : ''
  if (name === 'NotAllowedError') {
    return '麦克风权限被拒绝，请在浏览器地址栏左侧打开麦克风权限'
  }
  if (name === 'NotFoundError') {
    return '未检测到可用麦克风，请检查输入设备'
  }
  if (name === 'NotReadableError') {
    return '麦克风被其他程序占用，请关闭占用程序后重试'
  }
  return error instanceof Error ? error.message : '无法启动麦克风，请检查浏览器权限和访问地址'
}

const stopMediaStream = (mediaStream?: MediaStream) => {
  mediaStream?.getTracks().forEach((track) => track.stop())
}

const stopLocalAudio = () => {
  stopAudioRecording()
  processorRef.value?.disconnect()
  sourceRef.value?.disconnect()
  stopMediaStream(mediaStreamRef.value)
  audioContextRef.value?.close()
  processorRef.value = undefined
  sourceRef.value = undefined
  mediaStreamRef.value = undefined
  audioContextRef.value = undefined
}

const clearStopCloseTimer = () => {
  if (!stopCloseTimer) {
    return
  }
  window.clearTimeout(stopCloseTimer)
  stopCloseTimer = undefined
}

const nextRealtimeRunId = () => {
  realtimeRunId += 1
  return realtimeRunId
}

const isCurrentRealtimeRun = (runId: number) => runId === realtimeRunId

const stopSimulationPlayback = () => {
  if (!simulationSendTimer) {
    return
  }
  window.clearTimeout(simulationSendTimer)
  simulationSendTimer = undefined
}

const decodeSimulationAudio = async (file: File) => {
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext
  if (!AudioContextClass) {
    throw new Error('当前浏览器不支持音频解码，请使用新版 Chrome 或 Edge')
  }
  const audioContext = new AudioContextClass()
  try {
    const audioBuffer = await audioContext.decodeAudioData(await file.arrayBuffer())
    const mono = mixAudioBufferToMono(audioBuffer)
    return toPcm16(mono, audioBuffer.sampleRate, streamForm.sampleRate)
  } finally {
    await audioContext.close()
  }
}

const mixAudioBufferToMono = (audioBuffer: AudioBuffer) => {
  const output = new Float32Array(audioBuffer.length)
  for (let channel = 0; channel < audioBuffer.numberOfChannels; channel += 1) {
    const data = audioBuffer.getChannelData(channel)
    for (let i = 0; i < audioBuffer.length; i += 1) {
      output[i] += data[i] / audioBuffer.numberOfChannels
    }
  }
  return output
}

const sendPcmBufferAsRealtime = (ws: WebSocket, pcmBuffer: ArrayBuffer) => {
  const bytesPerSample = 2
  const chunkBytes = Math.max(streamForm.sampleRate * bytesPerSample / 10, 640)
  const alignedChunkBytes = Math.floor(chunkBytes / bytesPerSample) * bytesPerSample
  let offset = 0
  const sendNext = () => {
    if (ws.readyState !== WebSocket.OPEN) {
      return
    }
    if (offset >= pcmBuffer.byteLength) {
      streamStatusText.value = '模拟音频发送完成，等待识别结束'
      ws.send('stop')
      stopCloseTimer = window.setTimeout(() => {
        ws.close()
      }, 1500)
      return
    }
    const nextOffset = Math.min(offset + alignedChunkBytes, pcmBuffer.byteLength)
    ws.send(pcmBuffer.slice(offset, nextOffset))
    offset = nextOffset
    simulationSendTimer = window.setTimeout(sendNext, 100)
  }
  sendNext()
}

const handleRealtimeEvent = (event: AliyunRealtimeEvent) => {
  const type = String(event.type || '')
  const text = event.text || ''
  if (type === 'partial') {
    streamPartialText.value = text
    streamPartialTime.value = formatRealtimeElapsed()
  } else if (type === 'sentence_end') {
    appendFinalText(text)
    streamPartialText.value = ''
  } else if (type === 'translation') {
    appendTranslationText(text)
    streamActiveTab.value = 'translation'
  } else if (type === 'translation_error') {
    message.error(text || '实时翻译失败')
  } else if (type === 'error') {
    message.error(text || '阿里云实时识别返回异常')
    stopLocalAudio()
    streaming.value = false
    streamStatusText.value = text || '实时识别异常'
  } else if (type === 'listening') {
    streamStatusText.value = text || '正在监听麦克风'
  } else if (type === 'complete') {
    streamStatusText.value = '识别已结束'
  }
  pushStreamEvent(type, text)
}

const appendFinalText = (text: string) => {
  if (!text) {
    return
  }
  streamFinalText.value = [streamFinalText.value, text].filter(Boolean).join('\n')
  streamRecognitionSegments.value.push({
    time: formatRealtimeElapsed(),
    speaker: '说话人',
    text
  })
}

const appendTranslationText = (text: string) => {
  if (!text) {
    return
  }
  streamTranslationText.value = [streamTranslationText.value, text].filter(Boolean).join('\n')
  streamTranslationSegments.value.push({
    time: formatRealtimeElapsed(),
    speaker: '译文',
    text
  })
}

const formatRealtimeElapsed = () => {
  const elapsedSeconds = Math.max(0, Math.floor((Date.now() - streamStartedAt.value) / 1000))
  const minutes = String(Math.floor(elapsedSeconds / 60)).padStart(2, '0')
  const seconds = String(elapsedSeconds % 60).padStart(2, '0')
  return `${minutes}:${seconds}`
}

const pushStreamEvent = (type: string, text: string) => {
  streamEvents.value.unshift({
    time: new Date().toLocaleTimeString(),
    type,
    text
  })
  if (streamEvents.value.length > 80) {
    streamEvents.value.pop()
  }
}

const toPcm16 = (input: Float32Array, sourceRate: number, targetRate: number) => {
  const resampled = resample(input, sourceRate, targetRate)
  const output = new Int16Array(resampled.length)
  for (let i = 0; i < resampled.length; i += 1) {
    const sample = Math.max(-1, Math.min(1, resampled[i]))
    output[i] = sample < 0 ? sample * 0x8000 : sample * 0x7fff
  }
  return output.buffer
}

const resample = (input: Float32Array, sourceRate: number, targetRate: number) => {
  if (sourceRate === targetRate) {
    return input
  }
  const ratio = sourceRate / targetRate
  const length = Math.round(input.length / ratio)
  const output = new Float32Array(length)
  for (let i = 0; i < length; i += 1) {
    const index = i * ratio
    const before = Math.floor(index)
    const after = Math.min(before + 1, input.length - 1)
    const weight = index - before
    output[i] = input[before] + (input[after] - input[before]) * weight
  }
  return output
}

onBeforeUnmount(() => {
  stopRealtime()
  clearRecordingAudioUrl()
})
</script>

<style scoped>
.aliyun-asr-demo {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.demo-toolbar,
.result-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.toolbar-title,
.result-title {
  font-size: 16px;
  font-weight: 600;
  line-height: 24px;
}

.toolbar-subtitle,
.result-meta,
.stream-status-text {
  margin-top: 4px;
  color: var(--el-text-color-secondary);
  font-size: 13px;
  line-height: 20px;
}

.recording-player {
  padding: 12px 14px;
  margin: 12px 0;
  border: 1px solid var(--el-border-color-light);
  border-radius: 4px;
  background: var(--el-fill-color-lighter);
}

.recording-player__title {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
  color: var(--el-text-color-primary);
  font-size: 13px;
  font-weight: 600;
  line-height: 20px;
}

.recording-player__audio {
  display: block;
  width: 100%;
  height: 36px;
}

.demo-grid {
  display: grid;
  grid-template-columns: minmax(320px, 420px) minmax(0, 1fr);
  gap: 12px;
  align-items: start;
}

.demo-form {
  max-width: 100%;
}

.upload-icon {
  color: var(--el-color-primary);
  font-size: 32px;
}

.stream-status {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 12px;
  align-items: center;
}

.stream-status-text {
  margin-top: 0;
}

.simulation-upload {
  width: 100%;
}

.simulation-upload :deep(.el-upload) {
  display: inline-flex;
}

.simulation-file-name {
  max-width: 100%;
  margin-top: 6px;
  overflow: hidden;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  line-height: 18px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.minutes-actions {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 12px;
}

.file-action-form-item :deep(.el-form-item__content),
.stream-action-form-item :deep(.el-form-item__content) {
  min-width: 0;
}

.file-actions,
.stream-actions {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
  align-items: center;
  width: 100%;
}

.file-actions :deep(.el-button),
.stream-actions :deep(.el-button) {
  width: 100%;
  min-width: 0;
  padding: 8px 10px;
  font-size: 13px;
  margin-left: 0;
}

.file-actions :deep(.el-button--primary),
.stream-actions :deep(.el-button--primary) {
  min-width: 0;
}

@media (max-width: 960px) {
  .demo-grid {
    grid-template-columns: 1fr;
  }

  .demo-toolbar,
  .result-header {
    align-items: flex-start;
    flex-direction: column;
  }
}
</style>
