import { ElMessage } from 'element-plus'

export const useMessage = () => ({
  warning: ElMessage.warning,
  error: ElMessage.error,
  success: ElMessage.success
})
