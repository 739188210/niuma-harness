<template>
  <div class="realtime-segment-panel">
    <div v-if="title" class="realtime-segment-panel__title">{{ title }}</div>
    <div v-if="displaySegments.length" class="realtime-segment-panel__list">
      <div
        v-for="(item, index) in displaySegments"
        :key="`${item.time}-${item.text}-${index}`"
        :class="['realtime-segment-panel__item', { 'is-pending': item.pending }]"
      >
        <div class="realtime-segment-panel__header">
          <div class="realtime-segment-panel__speaker">
            <span class="realtime-segment-panel__badge">{{ badgeText }}</span>
            <span>{{ item.speaker || defaultSpeaker }}</span>
          </div>
          <span class="realtime-segment-panel__time">{{ item.time || '--:--' }}</span>
        </div>
        <div class="realtime-segment-panel__text">{{ item.text }}</div>
      </div>
    </div>
    <el-empty v-else :description="emptyDescription" />
  </div>
</template>

<script lang="ts" setup>
import { computed } from 'vue'

type RealtimeSegment = {
  time?: string
  speaker?: string
  text: string
  pending?: boolean
}

const props = withDefaults(
  defineProps<{
    title?: string
    segments: RealtimeSegment[]
    partialText?: string
    partialTime?: string
    badgeText?: string
    defaultSpeaker?: string
    emptyDescription?: string
  }>(),
  {
    title: '',
    partialText: '',
    partialTime: '',
    badgeText: '说',
    defaultSpeaker: '说话人',
    emptyDescription: '暂无内容'
  }
)

const displaySegments = computed(() => {
  const segments = [...props.segments]
  const partialText = props.partialText?.trim()
  if (partialText) {
    segments.push({
      time: props.partialTime || '--:--',
      speaker: props.defaultSpeaker,
      text: partialText,
      pending: true
    })
  }
  return segments
})
</script>

<style lang="scss" scoped>
.realtime-segment-panel {
  min-height: 220px;
}

.realtime-segment-panel__title {
  padding-bottom: 10px;
  margin-bottom: 14px;
  color: var(--el-text-color-regular);
  font-size: 13px;
  line-height: 20px;
  border-bottom: 1px solid var(--el-border-color-lighter);
}

.realtime-segment-panel__list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.realtime-segment-panel__item {
  padding: 14px 16px 14px 18px;
  border: 1px solid var(--el-border-color-light);
  border-left: 4px solid var(--el-color-primary);
  border-radius: 4px;
  background: linear-gradient(90deg, var(--el-color-primary-light-9), var(--el-fill-color-blank) 34%);
  box-shadow: 0 1px 5px rgb(15 23 42 / 8%);
}

.realtime-segment-panel__item.is-pending {
  border-left-color: var(--el-color-warning);
  background: linear-gradient(90deg, var(--el-color-warning-light-9), var(--el-fill-color-blank) 34%);
}

.realtime-segment-panel__header {
  display: flex;
  gap: 12px;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.realtime-segment-panel__speaker {
  display: inline-flex;
  gap: 5px;
  align-items: center;
  padding: 4px 9px 4px 5px;
  color: var(--el-color-primary);
  font-size: 13px;
  font-weight: 600;
  line-height: 18px;
  border-radius: 14px;
  background: var(--el-color-primary-light-9);
}

.realtime-segment-panel__badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  color: #fff;
  font-size: 11px;
  border-radius: 50%;
  background: var(--el-color-primary);
}

.realtime-segment-panel__time {
  color: var(--el-text-color-secondary);
  font-size: 12px;
  line-height: 18px;
}

.realtime-segment-panel__text {
  color: var(--el-text-color-primary);
  font-size: 14px;
  line-height: 24px;
  white-space: pre-wrap;
  word-break: break-word;
}
</style>

