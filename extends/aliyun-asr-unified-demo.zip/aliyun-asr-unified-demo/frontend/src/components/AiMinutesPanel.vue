<template>
  <div class="ai-minutes-panel">
    <div class="ai-minutes-block ai-minutes-keywords">
      <div class="ai-minutes-title">关键词</div>
      <div class="ai-minutes-tags">
        <el-tag v-for="item in keywords" :key="item" effect="plain" type="primary">
          {{ item }}
        </el-tag>
        <span v-if="!keywords.length" class="ai-minutes-empty">暂无关键词</span>
      </div>
    </div>

    <div class="ai-minutes-block ai-minutes-overview">
      <div class="ai-minutes-title">全文概要</div>
      <div :class="['ai-minutes-overview-text', { 'is-expanded': overviewExpanded }]">
        {{ overviewText }}
      </div>
      <el-button
        v-if="overviewText.length > overviewCollapseLength"
        link
        type="primary"
        class="ai-minutes-expand"
        @click="overviewExpanded = !overviewExpanded"
      >
        {{ overviewExpanded ? '收起' : '展开全部' }}
      </el-button>
    </div>

    <div class="ai-minutes-block ai-minutes-detail">
      <el-tabs v-model="activeTab" class="ai-minutes-tabs">
        <el-tab-pane label="章节速览" name="chapters">
          <div v-if="chapters.length" class="ai-minutes-timeline">
            <div
              v-for="(item, index) in chapters"
              :key="`${item.title || 'chapter'}-${index}`"
              class="ai-minutes-timeline-item"
            >
              <div class="ai-minutes-time">{{ item.time || '未明确' }}</div>
              <div class="ai-minutes-dot"></div>
              <div class="ai-minutes-card">
                <div class="ai-minutes-card-title">{{ item.title || '未命名章节' }}</div>
                <div v-if="item.content" class="ai-minutes-card-desc">{{ item.content }}</div>
              </div>
            </div>
          </div>
          <el-empty v-else description="暂无章节速览" />
        </el-tab-pane>

        <el-tab-pane label="发言总结" name="speaker">
          <div v-if="speakerSummaries.length" class="ai-minutes-speakers">
            <div
              v-for="(item, index) in speakerSummaries"
              :key="`${item.speaker || 'speaker'}-${index}`"
              class="ai-minutes-card"
            >
              <div class="ai-minutes-card-title">{{ item.speaker || '未明确' }}</div>
              <div class="ai-minutes-card-desc">{{ item.summary || '暂无总结' }}</div>
            </div>
          </div>
          <el-empty v-else description="暂无发言总结" />
        </el-tab-pane>

        <el-tab-pane label="要点回顾" name="review">
          <div v-if="reviews.length" class="ai-minutes-review">
            <div
              v-for="(group, index) in reviews"
              :key="`${group.title || 'review'}-${index}`"
              class="ai-minutes-review-group"
            >
              <div class="ai-minutes-card-title">{{ group.title || '要点回顾' }}</div>
              <ul v-if="group.items?.length" class="ai-minutes-list">
                <li v-for="item in group.items" :key="item">{{ item }}</li>
              </ul>
              <div v-else class="ai-minutes-card-desc">暂无内容</div>
            </div>
          </div>
          <el-empty v-else description="暂无要点回顾" />
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, ref } from 'vue'
import type { AliyunAsrMeetingMinutesRespVO } from '@/api/aliyunAsrDemo'

defineOptions({ name: 'AliyunAsrAiMinutesPanel' })

const props = defineProps<{
  result: AliyunAsrMeetingMinutesRespVO
}>()

const overviewCollapseLength = 120
const activeTab = ref('chapters')
const overviewExpanded = ref(false)

const normalizeItems = (items?: string[]) => items?.map((item) => item?.trim()).filter(Boolean) || []

const keywords = computed(() => normalizeItems(props.result.keywords))
const overviewText = computed(() => props.result.overview || '暂无概要')
const chapters = computed(() => props.result.chapters || [])
const speakerSummaries = computed(() => props.result.speakerSummaries || [])
const reviews = computed(() => props.result.reviews || [])
</script>

<style lang="scss" scoped>
.ai-minutes-panel {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ai-minutes-block {
  padding: 14px 16px;
  border: 1px solid var(--el-border-color-light);
  border-radius: 4px;
  background: var(--el-bg-color);
  box-shadow: 0 1px 6px rgb(15 23 42 / 6%);
}

.ai-minutes-title {
  position: relative;
  padding-left: 10px;
  margin-bottom: 10px;
  color: var(--el-text-color-primary);
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
}

.ai-minutes-title::before {
  position: absolute;
  top: 4px;
  left: 0;
  width: 3px;
  height: 12px;
  border-radius: 2px;
  background: var(--el-color-primary);
  content: '';
}

.ai-minutes-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.ai-minutes-empty,
.ai-minutes-card-desc,
.ai-minutes-overview-text,
.ai-minutes-list {
  color: var(--el-text-color-regular);
  font-size: 13px;
  line-height: 22px;
}

.ai-minutes-overview-text {
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.ai-minutes-overview-text.is-expanded {
  display: block;
  overflow: visible;
}

.ai-minutes-expand {
  height: 22px;
  padding: 0;
  margin-top: 6px;
}

.ai-minutes-detail {
  padding-top: 10px;
}

.ai-minutes-tabs :deep(.el-tabs__header) {
  margin-bottom: 14px;
}

.ai-minutes-timeline {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ai-minutes-speakers {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ai-minutes-timeline-item {
  display: grid;
  grid-template-columns: 58px 12px minmax(0, 1fr);
  gap: 10px;
  align-items: start;
}

.ai-minutes-time {
  color: var(--el-text-color-secondary);
  font-size: 12px;
  line-height: 20px;
}

.ai-minutes-dot {
  width: 8px;
  height: 8px;
  margin-top: 6px;
  border-radius: 50%;
  background: var(--el-color-primary);
}

.ai-minutes-card,
.ai-minutes-review-group {
  padding: 12px 14px;
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 4px;
  background: var(--el-fill-color-blank);
}

.ai-minutes-card-title {
  margin-bottom: 6px;
  color: var(--el-text-color-primary);
  font-size: 13px;
  font-weight: 600;
  line-height: 20px;
}

.ai-minutes-review {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
}

.ai-minutes-list {
  padding-left: 18px;
  margin: 0;
}

.ai-minutes-list li + li {
  margin-top: 4px;
}

@media (max-width: 900px) {
  .ai-minutes-review {
    grid-template-columns: 1fr;
  }
}
</style>

