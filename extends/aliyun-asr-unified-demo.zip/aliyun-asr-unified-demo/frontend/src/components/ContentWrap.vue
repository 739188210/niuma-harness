<template><section class="content-wrap"><slot /></section></template>

<style scoped>
.content-wrap { padding: 18px; background: #fff; border-radius: 8px; box-shadow: 0 1px 3px rgb(15 23 42 / 8%); }
</style>
