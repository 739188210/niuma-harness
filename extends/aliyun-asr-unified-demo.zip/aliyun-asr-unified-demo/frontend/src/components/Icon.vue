<template><IconifyIcon :icon="icon" /></template>

<script setup lang="ts">
import { Icon as IconifyIcon } from '@iconify/vue'
defineProps<{ icon: string }>()
</script>
