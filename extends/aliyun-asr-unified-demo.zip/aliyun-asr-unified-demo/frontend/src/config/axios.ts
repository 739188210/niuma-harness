import axios from 'axios'

const client = axios.create()

export default {
  post<T>(config: { url: string; data?: unknown; timeout?: number }) {
    return client.post<T>(config.url, config.data, { timeout: config.timeout }).then((response) => response.data)
  },
  upload<T>(config: { url: string; data: FormData; timeout?: number }) {
    return client.post<T>(config.url, config.data, {
      timeout: config.timeout,
      headers: { 'Content-Type': 'multipart/form-data' }
    }).then((response) => response.data)
  }
}
