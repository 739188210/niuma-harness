import request from '@/config/axios'

export interface AliyunAsrDemoRespVO {
  fileName?: string
  fileModel?: string
  sourceLanguage?: string
  transcriptionText?: string
  fileUrl?: string
  taskId?: string
  durationMs?: number
}

export interface AliyunAsrDemoRecognizeReq {
  file: File
  fileModel?: string
  sourceLanguage?: string
}

export interface AliyunAsrMeetingMinutesGenerateReq {
  sourceText: string
  sourceLanguage?: string
  minutesType?: string
  model?: string
}

export interface AliyunAsrMeetingMinutesRespVO {
  keywords?: string[]
  overview?: string
  chapters?: AliyunAsrMeetingMinutesChapterItem[]
  speakerSummaries?: AliyunAsrMeetingMinutesSpeakerSummaryItem[]
  reviews?: AliyunAsrMeetingMinutesReviewGroupItem[]
  rawMinutesText?: string
}

export interface AliyunAsrMeetingMinutesChapterItem {
  time?: string
  title?: string
  content?: string
}

export interface AliyunAsrMeetingMinutesSpeakerSummaryItem {
  speaker?: string
  summary?: string
}

export interface AliyunAsrMeetingMinutesReviewGroupItem {
  title?: string
  items?: string[]
}

export const recognizeAudioFile = async (
  params: AliyunAsrDemoRecognizeReq
): Promise<AliyunAsrDemoRespVO> => {
  const data = new FormData()
  data.append('file', params.file)
  appendIfPresent(data, 'fileModel', params.fileModel)
  appendIfPresent(data, 'sourceLanguage', params.sourceLanguage)

  const result = await request.upload<any>({
    url: '/api/aliyun-asr-demo/recognize',
    data,
    timeout: 300000
  })
  return result?.data ?? result
}

export const generateMeetingMinutes = async (
  data: AliyunAsrMeetingMinutesGenerateReq
): Promise<AliyunAsrMeetingMinutesRespVO> => {
  const result = await request.post<any>({
    url: '/api/aliyun-asr-demo/minutes/generate',
    data,
    timeout: 300000
  })
  return result?.data ?? result
}

const appendIfPresent = (data: FormData, key: string, value?: string | number | boolean) => {
  if (value === undefined || value === null || value === '') {
    return
  }
  data.append(key, String(value))
}


